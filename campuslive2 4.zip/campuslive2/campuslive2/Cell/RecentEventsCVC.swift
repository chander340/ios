import UIKit

class RecentEventsCVC: UICollectionViewCell {
    
    @IBOutlet weak var dateVw: UIView!
    @IBOutlet weak var imgVwBanner: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.imgVwBanner.layer.masksToBounds = true
        self.imgVwBanner.layer.cornerRadius = 10
        self.dateVw.layer.cornerRadius = 25
        self.dateVw.layer.masksToBounds = true
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
    }
    
}
