import UIKit

class DataTVC: UITableViewCell {

    @IBOutlet var imgVw: UIImageView!
    @IBOutlet var lblitem: UILabel!
    @IBOutlet var lblNotification: UILabel!

    
    override func awakeFromNib() {
        super.awakeFromNib()
 
      //  self.lblitem.textColor = .label
        
    //    self.imgVw.tintColor =
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
     
        
        
        self.lblitem.textColor = selected ? UIColor.systemRed : UIColor.systemYellow
       self.imgVw.tintColor = selected ? UIColor.systemRed : UIColor.systemYellow
 
    }

}
