import UIKit
import MSPeekCollectionViewDelegateImplementation
import Alamofire
class WhatsNewVC: BaseClass,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,UICollectionViewDelegate{
    var behavior: MSCollectionViewPeekingBehavior!
    var behavior1: MSCollectionViewPeekingBehavior!
    var behavior2: MSCollectionViewPeekingBehavior!
    var objModel: ResponseWhatsNew?
    let arrAnnou = ["1","2","3"]
    let arrLatest = ["1","2","3"]
    
    @IBOutlet weak var collVwAnnouncements: UICollectionView!
    @IBOutlet weak var announcementIcon: UILabel!
    @IBOutlet weak var latestNewsIcon: UILabel!
    @IBOutlet weak var recentEventsIcon: UILabel!
    @IBOutlet weak var collVwLatestNews: UICollectionView!
    @IBOutlet weak var CollVwRecentEvents: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("View Did Load")
     //   getData(auth_token: UserStoreSingleton.shared.authToken)
        getData(auth_token: UserStoreSingleton.shared.finalAuthToken)
        behavior1 = MSCollectionViewPeekingBehavior()
        behavior1.cellPeekWidth = 8
        behavior1.cellSpacing = 8
        collVwLatestNews.configureForPeekingBehavior(behavior: behavior1)
        
        behavior = MSCollectionViewPeekingBehavior()
        behavior.cellPeekWidth = 8
        behavior.cellSpacing = 8
        collVwAnnouncements.configureForPeekingBehavior(behavior: behavior)
        
        behavior2 = MSCollectionViewPeekingBehavior()
        behavior2.cellPeekWidth = 8
        behavior2.cellSpacing = 8
        CollVwRecentEvents.configureForPeekingBehavior(behavior: behavior2)
        
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.bull_horn, lbl: announcementIcon)
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.news_paper, lbl: latestNewsIcon)
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.star, lbl: recentEventsIcon)
    }
    
    func getData(){
        
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
       // collVwAnnouncements.reloadData()
        print("ViewDidLayoutSubView")
        collVwAnnouncements.selectItem(at: .init(row: 0, section: 0), animated: false, scrollPosition: .centeredHorizontally)
        collVwLatestNews.selectItem(at: .init(row: 0, section: 0), animated: false, scrollPosition: .centeredHorizontally)
        CollVwRecentEvents.selectItem(at: .init(row: 0, section: 0), animated: false, scrollPosition: .centeredHorizontally)
    }
    override func viewWillLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        print("ViewWillLayoutSubview")
        collVwAnnouncements.collectionViewLayout.invalidateLayout()
        collVwLatestNews.collectionViewLayout.invalidateLayout()
        CollVwRecentEvents.collectionViewLayout.invalidateLayout()
    }
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        behavior.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
        behavior1.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
        behavior2.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.collVwAnnouncements {
            return arrAnnou.count
        } else {
            return arrLatest.count
        }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == collVwAnnouncements {
            
            let cellAnnouncements = collVwAnnouncements.dequeueReusableCell(withReuseIdentifier: "AnnouncemetsCVC", for: indexPath) as? AnnouncemetsCVC
            return cellAnnouncements!
            
        } else if collectionView == collVwLatestNews {
            let cellLatestNews = collVwLatestNews.dequeueReusableCell(withReuseIdentifier: "LatestNewsCVC", for: indexPath) as? LatestNewsCVC
            return cellLatestNews!
        } else{
            let cellRecentEvent = CollVwRecentEvents.dequeueReusableCell(withReuseIdentifier: "RecentEventsCVC", for: indexPath) as? RecentEventsCVC
            return cellRecentEvent!
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = view.frame.size.width
        print("Setting Cell height and width:", width - 18)
        if collectionView == collVwAnnouncements {
            return CGSize(width: width , height: 180)
        } else if collectionView == collVwLatestNews {
            return CGSize(width:width  , height: 180)
        }else {
            return CGSize(width:width, height: 290)
        }
    }
    func getData(auth_token : String){
        if isConnectedToNetwork() {
            showLoader()
            let url = URL(string:  "https://campusdemo.stellarshell.com/api/mobile2/home/"+ModuleIds.WHATS_NEW_MODULE_ID)
            let parameters : Parameters = [:]
            let header: HTTPHeaders = ["Authorization": auth_token]
       //     print(auth_token)
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
              //  print(json)
                 
             //   print(data)
                do {
                    let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                    print("DOooooooooooo")
                    let decoder = JSONDecoder()
                    self.objModel = try decoder.decode(ResponseWhatsNew.self, from: data)
                      print((self.objModel?.response.data)!)
                //    print((self.objModel?.response.data)!)
                    DispatchQueue.main.async {
                        for value in (self.objModel?.response.data)! {
                           print((self.objModel?.response.data)!)
                          //    let long = Double ("\(value.longitude)")
                            let title = value.announcements
                            print(title)
//                              let subtitle = value.address
//                              self.makeAnnotations(lat: lat!, long: long!,title: title,subtitle: subtitle)
                        }
                        self.collVwAnnouncements.reloadData()
                      }
                  } catch{

                    print("catch")
                    // print("Nothing")
                }
              })
            
        }else{
            
            print("error")
        }
    }
    
    func getWhatsNewData(auth_token : String){
        if isConnectedToNetwork() {
            showLoader()
            // Internet available
            let url = URL(string: Urls.BASE_URL)
            let parameters:Parameters = [:]
            let header: HTTPHeaders = ["Authorization": auth_token]

            
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
              //  print(json)
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                
                do {
                    let jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonResult.object(forKey: Constants.STATUS) as! NSString
                    if status as String == Constants.OK {
                        //Welcome parent data retrive successfully
                        let data = jsonResult.object(forKey: Constants.DATA) as! NSObject
                        
                        let jsonData = try? JSONSerialization.data(withJSONObject: data, options: [])
                        UserStoreSingleton.shared.welcomeData = String(data: jsonData!, encoding: .utf8)

                       // print(UserStoreSingleton.shared.welcomeData!)
                        
//                        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
//                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "CollVwVC") as! CollVwVC
//                        self.navigationController?.pushViewController(nextViewController, animated: true)
                        
                    }
                    
                }catch{
                    print(error)
                }
            })
        } else {
            // No Internet Connection
            
            showTopAlert(message: Constants.no_internet)
        }
    }
}



