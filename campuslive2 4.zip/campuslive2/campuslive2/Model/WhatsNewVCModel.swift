import Foundation
import Alamofire

// https://campusdemo.stellarshell.com/app_assets/api/campuslivemobileapireference.html

struct ResponseWhatsNew : Decodable {
    
    var response : ResponseModel
    
}

struct ResponseModel : Decodable {
    
    var status : String
    var data : [DataModel]
    
}

struct DataModel : Decodable {
    
    var news : NewsModel
    var announcements : AnnouncementsModel
    var events : EventsModel
    
}

struct NewsModel : Decodable {
    var title : String
}

struct AnnouncementsModel : Decodable{
    var title : String
}

struct EventsModel : Decodable {
    var title : String
}
