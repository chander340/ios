import UIKit
import SideMenu

@available(iOS 13.0, *)
class SideMenuVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    var nameArr = ["Home","Photos","Movies","Notification","Settings","r4","f3f34","fr3","f3f3","f334f","f3433"]
    var imageArr = ["1","2","3","4","5"]
   // var dotArr = [ "","","","9",""]
  
    @IBOutlet var tblVw: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblVw.tableFooterView = UIView()
        tblVw.separatorStyle = .none
//        imgVwProfile.layer.cornerRadius = imgVwProfile.frame.size.width/2
//        imgVwProfile.clipsToBounds = true
    }
    
    
    @available(iOS 13.0, *)
    @IBAction func actionBtnLogout(_ sender: Any) {
        UserDefaults.standard.set(false, forKey: "aaa")
      //  Swicher.updateRootVC()
     //  let moveToNextVC = storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
      //  self.navigationController?.popToRootViewController(animated: false)
//        window?.rootViewController = moveToNextVC
//        self.navigationController?.popToRootViewController(animated: true)

      //  self.navigationController?.popToViewController(moveToNextVC, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArr.count
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DataTVC", for: indexPath) as! DataTVC
        cell.lblitem.text = nameArr[indexPath.row]
//        let img  = UIImage(named: imageArr[indexPath.row])
//             cell.imgVw.image = img
        cell.lblitem.text = nameArr[indexPath.row]
        if cell.lblitem.text == "Notification"
        {
            cell.lblNotification.isHidden = false
    }else{
            cell.lblNotification.isHidden = true
            
        }
//        let dot = UIImage(named: dotArr[indexPath.row])
//        cell.imgVwDot.image = dot
        return cell
    }
       
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }

    
  //  @available(iOS 13.0, *)
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //let cell = tableView.dequeueReusableCell(withIdentifier: "DataTVC", for: indexPath) as! DataTVC
       
        if indexPath.row == 1
              {
//                let moveToNextVC = storyboard?.instantiateViewController(identifier: "PhotosVC") as! PhotosVC
//                self.navigationController?.pushViewController(moveToNextVC, animated: false)
        }else if (indexPath.row == 4){
//            let moveToNextSettings = storyboard?.instantiateViewController(identifier: "SettingsVC") as! SettingsVC
//            self.navigationController?.pushViewController(moveToNextSettings, animated: false)
        }else if indexPath.row == 0 {
//            let moveToNextSettings = storyboard?.instantiateViewController(identifier: "TabBarVC") as! TabBarVC
//        self.navigationController?.pushViewController(moveToNextSettings, animated: false)
        }else{
            print(indexPath.row)
        }
    }
 
}
