import UIKit

class WellBeingVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}
