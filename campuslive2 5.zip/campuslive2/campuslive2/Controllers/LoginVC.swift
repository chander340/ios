import UIKit
import Alamofire
import BRYXBanner
import SideMenu

//@available(iOS 13.0, *)
class LoginVC: BaseClass,UITextFieldDelegate {
    
    // MARK:- variables and constants
    var iconClick = true
    let layer = CAGradientLayer()
    let btnlayer = CAGradientLayer()
    var titleee : String = "abcdheichi"
    var subtitle : String = "abcdheichi"
    var vSpinner : UIView?
    // MARK:- Outlets
    @IBOutlet weak var contentVw: UIView!
    @IBOutlet weak var scrollVw: UIScrollView!
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var passtxtFld: UITextField!
    @IBOutlet weak var emailtxtFld: UITextField!
    @IBOutlet weak var btnPassword: UIButton!
    // MARK:- Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
         passtxtFld.delegate = self
         initialData()
         UserDefaults.standard.set(false, forKey: "ISUSERLOGGEDIN")
    }
    
    // MARK:- Action Buttons
    @IBAction func actionBtnPassword(_ sender: Any) {
        passtxtFld.isSecureTextEntry.toggle()
    }
    
    @IBAction func actionBtnPrivacy(_ sender: Any) {
        if let url = URL(string: Urls.PRIVACY_POLICY_URL) {
            UIApplication.shared.open(url)
        }
    }
    
    // MARK:- Functions
    func initialData(){
        loginBtn.layer.cornerRadius = 20
        loginBtn.layer.masksToBounds = true
        passtxtFld.isSecureTextEntry = true
        scrollVw.layer.cornerRadius = 35
        loginBtn.setGradientBackgroundButton(gradientLayer: btnlayer , colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        view.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
    }
    
    func actionButtonData(){
        
        let activityIndicator = ActivityIndicator(view:view, navigationController:nil,tabBarController: nil)
        activityIndicator.showActivityIndicator(textlbl: "Registering your device...")
               
               DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                   activityIndicator.showActivityIndicator(textlbl: "Generating Token...")
                   if self.emailtxtFld.text == "" {
                       self.showTopAlert(message: "Please enter your Username/Email")
                    activityIndicator.stopActivityIndicator()
                   
                   } else if self.passtxtFld.text == ""  {
                       self.showTopAlert(message: "Please enter your Password")
                    activityIndicator.stopActivityIndicator()
                       } else{
                           // creating Json Object with parms for auth token
                           // First Object
                           let paraObj : NSMutableDictionary = NSMutableDictionary()
                       paraObj.setValue(self.emailtxtFld.text!, forKey: "u")
                       paraObj.setValue(HelperClass.encrypt(string: self.passtxtFld.text!, publicKey: Keys.ENCRYPTION_PUBLIC_KEY), forKey: "p")
                           paraObj.setValue("", forKey: "t")
                           // Second Object
                           let paraObj2 : NSMutableDictionary = NSMutableDictionary()
                           paraObj2.setValue(0, forKey: "r")
                           paraObj2.setValue("", forKey: "i")
                           
                           // creating string form json object
                           let jsonData = try? JSONSerialization.data(withJSONObject: paraObj, options: [])
                           let jsonString = String(data: jsonData!, encoding: .utf8)
                           let jsonData2 = try? JSONSerialization.data(withJSONObject: paraObj2, options: [])
                           let jsonString2 = String(data: jsonData2!, encoding: .utf8)
                           
                           // Login Authentication
                        
                       DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                           activityIndicator.showActivityIndicator(textlbl: "Getting things ready for first time use...")
                           DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                               activityIndicator.showActivityIndicator(textlbl: "Almost Done")
                               self.login(auth_token: Constants.BEARER + (jsonString?.toBase64())! + "." + (jsonString2?.toBase64())!, ip_address : "1234", device_id: "12345", device_name: "IPhone11", manufacturer: "apple", platform: Constants.IOS, fcmtoken: "abcd")
                         }
                       }
                     }
                   }
          }
  
     // MARK:- Override functions
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        // btnlayer.frame = btnlayer.bounds
        layer.frame = view.layer.bounds
        contentVw.frame = view.layer.bounds
        scrollVw.layer.cornerRadius = 35
    }
    
    override func viewDidLayoutSubviews() {
        btnlayer.frame = view.layer.bounds
    }
    
    // MARK:- Action Button
    
    @IBAction func actionBtnLogin(_ sender: UIButton) {
       // showSpinner(onView: self.view)
        if self.emailtxtFld.text == "" {
            self.showTopAlert(message: "Please enter your Username/Email")
        } else if self.passtxtFld.text == ""  {
            self.showTopAlert(message: "Please enter your Password")
        }else {
            actionButtonData()
        }
    }
//        if emailtxtFld.text == "" {
//            showTopAlert(message: "Please enter your Username/Email")
//        } else if passtxtFld.text == ""  {
//            showTopAlert(message: "Please enter your Password")
//        } else {
//            // creating Json Object with parms for auth token
//            // First Object
//            let paraObj : NSMutableDictionary = NSMutableDictionary()
//            paraObj.setValue(emailtxtFld.text!, forKey: "u")
//            paraObj.setValue(HelperClass.encrypt(string: passtxtFld.text!, publicKey: Keys.ENCRYPTION_PUBLIC_KEY), forKey: "p")
//            paraObj.setValue("", forKey: "t")
//            // Second Object
//            let paraObj2 : NSMutableDictionary = NSMutableDictionary()
//            paraObj2.setValue(0, forKey: "r")
//            paraObj2.setValue("", forKey: "i")
//
//            // creating string form json object
//            let jsonData = try? JSONSerialization.data(withJSONObject: paraObj, options: [])
//            let jsonString = String(data: jsonData!, encoding: .utf8)
//            let jsonData2 = try? JSONSerialization.data(withJSONObject: paraObj2, options: [])
//            let jsonString2 = String(data: jsonData2!, encoding: .utf8)
//
//            // Login Authentication
//            login(auth_token: Constants.BEARER + (jsonString?.toBase64())! + "." + (jsonString2?.toBase64())!, ip_address : "1234", device_id: "12345", device_name: "IPhone11", manufacturer: "apple", platform: Constants.IOS, fcmtoken: "abcd")
//        }
//    }
//
    // MARK:- Functions
    
    
    
    
    
    // MARK:- Login Func
    func login(auth_token : String,ip_address : String,device_id : String,device_name : String,manufacturer: String,platform : String,fcmtoken: String){
        print(auth_token)
        if isConnectedToNetwork() {
            showLoader()
            // Internet available
            let url = URL(string: Urls.login)
            let params:Parameters = ["ip": ip_address,"deviceId":device_id,"deviceName" : device_name, "manufacturer" : manufacturer,"platform" : platform, "fcmToken" : fcmtoken]
            let header: HTTPHeaders = ["Authorization": auth_token]
            
            AF.request(url!, method: .post, parameters: params, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
                
                print("Login API Response",json)
                
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonResult.object(forKey: "status") as! NSString
                    if status as String == Constants.OK {
                        //user has logged in sucessfully
                        let data = jsonResult.object(forKey: "data") as! NSDictionary
                        let role = data.object(forKey: "role") as! NSInteger
                        UserStoreSingleton.shared.userName = data.object(forKey: "personName") as? String
                        UserStoreSingleton.shared.userId = data.object(forKey: "userId") as? String
                        UserStoreSingleton.shared.personId = data.object(forKey: "personId") as? String
                        UserStoreSingleton.shared.userRole = data.object(forKey: "role") as? Int
                        UserStoreSingleton.shared.schoolId = data.object(forKey: "schoolId") as? String
                        UserStoreSingleton.shared.isNew = data.object(forKey: "isNew") as? Bool ?? false
                        UserStoreSingleton.shared.authToken = data.object(forKey: "authToken") as? String
                        UserStoreSingleton.shared.personCode = data.object(forKey: "personCode") as? String
                        // UserStoreSingleton.shared.userChildern = data.object(forKey: "students") as? String
                        if role as Int != 0{
                            let paraObj : NSMutableDictionary = NSMutableDictionary()
                            paraObj.setValue("", forKey: "u")
                            paraObj.setValue( "", forKey: "p")
                            paraObj.setValue(UserStoreSingleton.shared.authToken, forKey: "t")
                            
                            let paraObj2 : NSMutableDictionary = NSMutableDictionary()
                            paraObj2.setValue(UserStoreSingleton.shared.userRole, forKey: "r")
                            paraObj2.setValue(UserStoreSingleton.shared.userId, forKey: "i")
                            // creating string form json object
                            let jsonData = try? JSONSerialization.data(withJSONObject: paraObj, options: [])
                            let jsonString = String(data: jsonData!, encoding: .utf8)
                            let jsonData2 = try? JSONSerialization.data(withJSONObject: paraObj2, options: [])
                            let jsonString2 = String(data: jsonData2!, encoding: .utf8)
                            self.welcomeParent(auth_token: Constants.BEARER + (jsonString?.toBase64())! + "." + (jsonString2?.toBase64())!)
                            UserDefaults.standard.set(true, forKey: "ISUSERLOGGEDIN")
                        } else {
                            self.showTopAlert(message: (data.object(forKey: "message") as! NSString) as String)
                        }
                    }
                }catch{
                    print(error)
                }
            })
        } else {
            // No Internet Connection
            // HTTPURLResponse

            showTopAlert(message: Constants.no_internet)
        }
    }
    
    // MARK:- Welcome Parent API
    func welcomeParent(auth_token : String){
        if isConnectedToNetwork() {
            showLoader()
            // Internet available
            //  let url = URL(string: Urls.welcome_parent)
            let url = URL(string: Urls.welcome_Data)
            let parameters:Parameters = [:]
            let header: HTTPHeaders = ["Authorization": auth_token]
            UserStoreSingleton.shared.finalAuthToken = auth_token
            print(auth_token)
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
                // print("Welcome Data API",json)
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonResult.object(forKey: Constants.STATUS) as! NSString
                    if status as String == Constants.OK {
                        //Welcome parent data retrive successfully
                        let data = jsonResult.object(forKey: Constants.DATA) as! NSObject
                        let jsonData = try? JSONSerialization.data(withJSONObject: data, options: [])
                        UserStoreSingleton.shared.welcomeData = String(data: jsonData!, encoding: .utf8)
                        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "CollVwVC") as! CollVwVC
                        self.navigationController?.pushViewController(nextViewController, animated: true)
                    }
                }catch{
                    print(error)
                }
            })
        } else {
            // No Internet Connection
            showTopAlert(message: Constants.no_internet)
        }
    }
}
