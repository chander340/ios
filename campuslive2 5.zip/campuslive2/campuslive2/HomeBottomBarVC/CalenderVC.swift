import UIKit
import FSCalendar
import FloatingPanel
import Alamofire
class CalenderVC: BaseClass, FSCalendarDelegate, FSCalendarDataSource,FloatingPanelControllerDelegate{
    
    // MARK:- Variables
    var currentYear = Int()
    var calendarScreenData = NSArray()
    var formatterMonth = DateFormatter()
    var formatterYear = DateFormatter()
    let layer = CAGradientLayer()
    let calanderLayer = CAGradientLayer()
    let fpc = FloatingPanelController()
    private var currentPage: Date?
    let fpccc = FloatingPanelController()
    //let appearance = SurfaceAppearance()
    // MARK:- Outlets
    
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var previousButton: UIButton!
    @IBOutlet weak var nextbutton: UIButton!
    
    //MARK:- Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        print(currentYear,"View Did load")
        self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
        initialInit()
        // Must
        
    }
    //  MARK:- Override functions
    
    func initialInit(){
        fpc.delegate = self
        let fpc = FloatingPanelController(delegate: self)
        fpc.layout = MyFloatingPanelLayout()
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let contentVC = storyBoard.instantiateViewController(withIdentifier: "BottomSheetVC") as! BottomSheetVC
        fpc.set(contentViewController: contentVC)
        fpc.addPanel(toParent: self)
        calendar.delegate = self
        calendar.dataSource = self
        calendar.scrollEnabled = true
        calendar.calendarHeaderView.scrollEnabled = true
        //  calendar.appearance.subtitleDefaultColor = UIColor.clear
        calendar.appearance.headerMinimumDissolvedAlpha = 0
        calendar.calendarHeaderView.backgroundColor = UIColor.init(named: "131114")
        calendar.scrollDirection = .horizontal
        view.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        calendar.placeholderType =  FSCalendarPlaceholderType.none
        calendar.setGradientBackground(gradientLayer:calanderLayer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        let fpc = FloatingPanelController(delegate: self)
        fpc.layout = MyFloatingPanelLayout()
        layer.frame = view.layer.bounds
        // calendar.layer.frame = view.layer.bounds
        calanderLayer.frame = view.layer.bounds // This is working Fine
        calendar.pagingEnabled = true
        calendar.appearance.headerMinimumDissolvedAlpha = 0
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let fpc = FloatingPanelController(delegate: self)
        fpc.layout = MyFloatingPanelLayout()
        
        calanderLayer.frame = view.layer.bounds
        layer.frame = view.layer.bounds
        calendar.pagingEnabled = true
        calendar.appearance.headerMinimumDissolvedAlpha = 0
    }
    
    // MARK:- Delegates and Fuctions
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        print("Selected")
    }
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        //        formatter.dateFormat = "dd-MM-yyy"
        //        print("Date Selected = \(formatter.string(from: date))")
        cell.eventIndicator.numberOfEvents = 0
        cell.eventIndicator.isHidden = false
        cell.eventIndicator.color = UIColor.white
    }
    //    func calendar(calendar: FSCalendar!, hasEventForDate date: NSDate!) -> Bool {
    //        return shouldShowEventDot
    //    }
    
    // MARK:- Action Buttons
    @IBAction func actionBtnPreviousMonth(_ sender: Any) {
        calendar.setCurrentPage(getPreviousMonth(date: calendar.currentPage), animated: true)
//        let calandaarr = calendar.currentPage
//        formatterYear.dateFormat = "yyy"
//        let currentPage = formatterYear.string(from: calandaarr)
//        print(currentPage)
        self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
        
        
    }
    @IBAction func actionBtnNextMonth(_ sender: Any) {
        calendar.setCurrentPage(getNextMonth(date: calendar.currentPage), animated: true)
//        let calandaarr = calendar.currentPage
//        formatterYear.dateFormat = "yyy"
//        let currentPage = formatterYear.string(from: calandaarr)
//        print(currentPage)
        self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
    }
    
    
    // MARK:- Functions
    func getNextMonth(date:Date)->Date {
        return  Calendar.current.date(byAdding: .month, value: 1, to:date)!
    }
    
    func getPreviousMonth(date:Date)->Date {
        return  Calendar.current.date(byAdding: .month, value: -1, to:date)!
    }
    
    func getDataCalanderVC(auth_token : String){
        if isConnectedToNetwork() {
            showLoader()
        let currentPageDate = calendar.currentPage
            formatterMonth.dateFormat = "MM"
            formatterYear.dateFormat = "yyy"
            let currentYear = formatterYear.string(from: currentPageDate)
            let currentMonth = formatterMonth.string(from: currentPageDate)
          //  print(currentYear,"InsideGetDataFuction",currentMonth)
            
        let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/homecalendar/" + "\(currentMonth)" + "/\(currentYear)")
        
            
            let parameters : Parameters = [:]
            let header: HTTPHeaders = ["Authorization": auth_token]
            //     print(auth_token)
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
                // print(json)
                
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonObject.value(forKey: "status") as! String
                    
                    if status == Constants.OK{
                      let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "BottomSheetVC") as! BottomSheetVC
                        self.calendarScreenData = jsonObject.value(forKey: "data") as! NSArray
                        nextViewController.dataArr = self.calendarScreenData
                     //   nextViewController.tableViewww.reloadData()
                        
                        
//                        let event1 = data[1] as! NSObject
//                        let title1 = event1.value(forKey: "title") as!String
//                        let totalEvents = event1.value(forKey: Constants.DATA) as! NSArray
//                        print(totalEvents)
                     
                        
                        
                        
                       
                    }
                } catch{
                    
                    print("catch")
                    // print("Nothing")
                }
            })
            
        }else{
            
            print("error")
        }
    }
}

class MyFloatingPanelLayout: FloatingPanelLayout {
    let position: FloatingPanelPosition = .bottom
    let initialState: FloatingPanelState = .tip
    var anchors: [FloatingPanelState: FloatingPanelLayoutAnchoring] {
        return [
            .full: FloatingPanelLayoutAnchor(absoluteInset: 16.0, edge: .top, referenceGuide: .safeArea),
            .half: FloatingPanelLayoutAnchor(fractionalInset: 0.31, edge: .bottom, referenceGuide: .safeArea),
            .tip: FloatingPanelLayoutAnchor(absoluteInset: 28.0, edge: .bottom, referenceGuide: .safeArea),
        ]
    }
}

