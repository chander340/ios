import UIKit
class NotificationVC: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
