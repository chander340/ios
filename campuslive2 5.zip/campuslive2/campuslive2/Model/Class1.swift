

import UIKit
import SideMenu
class Class1: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    
    
    
    
    @IBAction func portraitButton(_ sender: Any) {
  print("Portrait")
    
    
    }
    
    
    @IBAction func LandScapeButton(_ sender: Any) {
    
    print("LandScape")
    }
    
    
    
    
    
//    
//    @IBAction func actionBtn(_ sender: Any) {
//  // Define the menu
//        
// // let menu = SideMenuNavigationController(rootViewController: SideMenuVC)
//  // SideMenuNavigationController is a subclass of UINavigationController, so do any additional configuration
//  // of it here like setting its viewControllers. If you're using storyboards, you'll want to do something like:
//   let menu = storyboard!.instantiateViewController(withIdentifier: "SideMenuNavigationController") as! SideMenuNavigationController
//        menu.leftSide = true
//        menu.menuWidth = view.layer.frame.width / 1.5
//        menu.presentationStyle = .viewSlideOutMenuIn
//  present(menu, animated: true, completion: nil)
//    
//    
//    }
}
