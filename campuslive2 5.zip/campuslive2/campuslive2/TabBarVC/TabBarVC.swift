import UIKit

class TabBarVC: UITabBarController {

   
    
    @IBOutlet weak var demo: UITabBar!
    override func viewWillAppear(_ animated: Bool) {
      //  demo.setValue("Name", forKey: "1")
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // whatsNewVC.whatsNew = UITabBarItem(title: "NewNEW", image: nil, selectedImage: nil)
        
       // whatsNewVC.item =  UITabBarItem(title: "Home", image: nil, selectedImage: nil)
    
       // whatsNewVC.tabBarItem = UITabBarItem(tabBarSystemItem: .topRated, tag: 1)
        
     
//        whatsNewVC.tabBarItem = UIBarButtonItem(title: "NewNewNew", style: .plain, target: self, action: .some(<#Selector#>))
        
        print("abcdedebeuwb")
        
        
    }

}
