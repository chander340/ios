import UIKit

class AnnouncemetsCVC: UICollectionViewCell {
   
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var yearLbl: UILabel!
    @IBOutlet weak var monthLbl: UILabel!
    @IBOutlet weak var dateVw: UIView!
    @IBOutlet weak var descLbl: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        self.dateVw.layer.cornerRadius = 25
        self.dateVw.layer.masksToBounds = true
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
    }
    
    
    
    
//    override func layoutSubviews() {
//        self.layer
//    }
}
