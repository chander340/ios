import Foundation
import UIKit

struct Urls {
    static let BASE_URL = "https://campusdemo.stellarshell.com/";
    static let SCHOOL_LOGO_BASE_URL = "https://campusdemo.stellarshell.com/api/mobile2/user/schoollogo?t=";
    static let PRIVACY_POLICY_URL = "https://campuslivecloud.com/privacy-policy"
    static let BASE_URL_API = BASE_URL + "api/"
    static let login = BASE_URL_API + "mobile2/login"
    static let welcome_parent = BASE_URL_API + "mobile2/welcome/parent"
    static let whats_new_data = BASE_URL_API + "mobile2/home/{id}"
    static let welcome_Data = "https://campusdemo.stellarshell.com/api/mobile2/welcome/parent"
}

struct IconCodeSideMenu {
    
    static let PROFILE_ICON_FONT = "f007";
    static let CHILDREN_ICON_FONT = "f0c0";
    static let CHANGE_PASSWORD_ICON_FONT = "f505";
    static let ABOUT_US_ICON_FONT = "f059";
    static let CONTACT_US_ICON_FONT = "f1fa";
    static let PRIVACY_POLICY_ICON_FONT = "f1c4";
    static let FEEDBACK_ICON_FONT = "f4a3";
    static let SHARE_ICON_FONT = "f1e0";
    static let SIGNOUT_ICON_FONT = "f2f5";
    
}
struct ModuleIds {
    
    static let HOME_MODULE_ID = "MQ==";
    static let SCHOOL_MODULE_ID = "Mg==";
    static let CLASS_MODULE_ID = "Mw==";
    static let ROUTINE_MODULE_ID = "NA==";
    static let WELL_BEING_MODULE_ID = "NQ==";
    
    static let WHATS_NEW_MODULE_ID = "Ng==";
    static let CALENDAR_MODULE_ID = "Nw==";
    static let MESSAGES_MODULE_ID = "OA==";
    static let NOTIFICATIONS_MODULE_ID = "OQ==";
    
    static let FRONT_OFFICE_MODULE_ID = "MTA=";
    static let RE_REGISTRATION_MODULE_ID = "MTI=";
    static let ADMISSION_MODULE_ID = "MTM=";
    static let APPOINTMENTS_MODULE_ID = "MTE=";
    
    static let CIRCULAR_MODULE_ID = "MjY=";
    static let NEWS_MODULE_ID = "Mjc=";
    static let EVENTS_MODULE_ID = "Mjg=";
    static let NEWS_LETTERS_MODULE_ID = "Mjk=";
    static let GATE_SECURITY_MODULE_ID = "MzA=";
    
    
    static let ATTENDANCE_MODULE_ID = "MTg=";
    static let FEES_MODULE_ID = "MTk=";
    static let TRANSPORT_MODULE_ID = "MjA=";
    static let LIBRARY_MODULE_ID = "MjE=";
    
    
    static let COURSES_MODULE_ID = "MTQ=";
    static let RESULT_MODULE_ID = "MTU=";
    static let E_LEARNING_MODULE_ID = "=";
    static let TEACHER_NOTES_MODULE_ID = "MTc=";
    
    
    static let WELL_BEING_HEALTH_MODULE_ID = "MjI=";
    static let WELL_BEING_BEHAVIOUR_MODULE_ID = "MjM=";
    static let WELL_BEING_CAFETERIA_MODULE_ID = "MjQ=";
    static let WELL_BEING_EXTRA_CURRICULAR_MODULE_ID = "MjU=";
    
    static let HEALTH_ISSUES_MODULE_ID = "NDQ=";
    static let PHYSICAL_STATS_MODULE_ID = "NDY=";
    static let OPD_VISITS_MODULE_ID = "NDc=";
    static let HEALTH_CHECK_UPS_MODULE_ID = "NDg=";
    static let VACCINATIONS_MODULE_ID = "NDk=";
    
    static let INCIDENTS_MODULE_ID = "NTA=";
    static let GOOD_NEWS_MODULE_ID = "NTE=";
    static let CHARACTER_TRAITS_MODULE_ID = "NTI=";
    
    static let MENU_MODULE_ID = "NTM=";
    static let PURCHASE_HISTORY_MODULE_ID = "NTQ=";
    static let PURCHASE_LIMIT_MODULE_ID = "NTU=";
    
    
    static let PICK_UP_ROUTE_MODULE_ID = "MzY=";
    static let DROP_OFF_ROUTE_MODULE_ID = "Mzc=";
    static let BUS_ATTENDANCE_MODULE_ID = "Mzg=";
    static let BUS_CHARGES_MODULE_ID = "Mzk=";
    
    
    static let BORROWED_MODULE_ID = "NDE=";
    static let RETURNED_MODULE_ID = "NDI=";
    static let BOOKS_LOST_MODULE_ID = "NDM=";
    
}

struct Colors {
    static let right_gradient = UIColor(red: 0.0/255.0, green: 170/255.0, blue: 136/255.0, alpha: 1.0)
    static let left_gradient  = UIColor(red: 0.0/255.0, green: 102.0/255.0, blue: 128.0/255.0, alpha: 1.0)
    static let banner_color  = UIColor(red: 255.0/255.0, green: 99.0/255.0, blue: 71.0/255.0, alpha: 1.0)
}

struct Constants {
    static let STATUS = "status"
    static let DATA = "data"
    static let OK  = "OK"
    static let app_name  = "CampusLIVE"
    static let no_internet  = "Please check your internet connection!"
    // Space is must in Bearer
    static let BEARER = "Bearer "
    static let IOS = "Ios"
    static let INVITATION_LINK = "Application Link will be here"
    static let SHARE_APP_TEXT = "I can easily track my children education on this app. Why don't you use this too? \n" + INVITATION_LINK
}

struct FaIcon {
   // static let bull_horn = "f762"
    static let bull_horn = "f0a1"
    static let news_paper = "f1ea"
    static let star = "f005"
    static let side_menu_icon = "f0c9"
}

struct Keys {
    
    static let ENCRYPTION_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgLR9plVk174WCsgPE9LAofcSbNxcUoJa5ewSFHtczysLS7ZYT7JrZgJ8CgkwB1r+KerD58O9RCzF7AZDKItID2ouK5FtaGYwc8ujhseYUO/C24yzJMdYpuBQyck41cCpyGYGshSwv3jbOObunknJFb1mGxBWLgDdAjy808e0qBZByz+gjUrCDByTX3BQ6//GXB4nOSeathoyzqoVwVcdNPE4aCnG8ztDvsC2PLLHBSZyXbyjkfyZH2rmH+yZds9kVoijknKoItekiDI/zECQCTz8+Uhl4u6D47EGL7uErsZZsMF/4+zdXuS9xZon68knYkZKCWW5BmRhgHrBYdDHuwIDAQAB"
    
    static let DECRYPTION_PRIVATE_KEY = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCAtH2mVWTXvhYKyA8T0sCh9xJs3FxSglrl7BIUe1zPKwtLtlhPsmtmAnwKCTAHWv4p6sPnw71ELMXsBkMoi0gPai4rkW1oZjBzy6OGx5hQ78LbjLMkx1im4FDJyTjVwKnIZgayFLC/eNs45u6eSckVvWYbEFYuAN0CPLzTx7SoFkHLP6CNSsIMHJNfcFDr/8ZcHic5J5q2GjLOqhXBVx008ThoKcbzO0O+wLY8sscFJnJdvKOR/JkfauYf7Jl2z2RWiKOScqgi16SIMj/MQJAJPPz5SGXi7oPjsQYvu4SuxlmwwX/j7N1e5L3FmifrySdiRkoJZbkGZGGAesFh0Me7AgMBAAECggEAcNpSZpvv/YBOoYuENPSSNjKHtG6QgUSN4ZdazxzQZ1Mt52hvDQq8Q0kgbEhcFccCn8yblMg8V+AOeAORtaZTPDj1XPx6e5VHHPHNZGv1MdrZ+Frp5fDp2gFMtXK8ZCk4dmCHtHSR+oJFbyKGzsKSEH7vXgG4H0Rghgqt4+DzloIWXZzOobh10/WFDuA4/A4PQMcd7IRg9LIGvSVLRr87MeVyVoO3jY/K2c4Ie1T37HPbSaYwuT0JTlnQ766vPYBj7PGBSOzuF9INOaJTNHv/6fVGb9nxkTXz3t820/JLc4xHQOnAyOGeG2jNPvPDsVXoe04ddKPGo7oPni0mi4cpEQKBgQDDnHTEkxg/5s1m9MqAxsgqFFt73RRuPOwgwCT5Tfh/BQ8yyprlQ7qLmXy2qgAsWCC4mLAL67Pvf4fk0Y0BiHx+OV6bKr2h0njbS0ac9o6mUMERyopM4t0qfI7AnRYAfiPSxfFcwSWmgVUDAUY/lLoulA3hpIvYvKMX84acxY9PSQKBgQCocE9FULFk+kzdpL9ARy9/Kxm6YzuIatuKtkpyg7Cmgz1naeq23AhFTy/FmZimHlwuyvjYvzN6KRVTgoq0KSXU09W5HXlzC6KbaFJrfzvP6wqtnZHL4YyrREGWJKemAx21vwM342ogBUynZMnKNhOHse8BdeBqJrWz/FTQtV+q4wKBgHLXTAaMhVQe4MBtPuZTzfhGc19I8FG4GrkvlYV4LUgFZGLhaAbpuH904S8sp2VhZ/R4UALvongdW18PV8VqqAxDCjP259Y1hxbYHuDQL/ecuX0EeCWjm0zyS6zxjJVFeSqpY4adLsmObKaS/PcfDh+CdJPg0umv9eB97K3lnrlhAoGAMDnXuHTeFZdEosEksPawtqxUdXUr+mb97L08m4Tw8vvofM9qkGh3RcDiYKUVe5p9sjgS/5ve1T8mB/78T5DocAMm0hWKTFIsgGpiDr0jFuio6gSPVdyCNhcY4DAmf/Wsb/j8pufJ3tkllVfaHrdU6Ckd0UE6u6nRpHK+pfMILRkCgYBvabqBBU1yoKwKyvlYLkyAOlKZe+OD9vIx3wx8u/Jkm+pDK4wwO+hl05Kcmsl9BtqF4jev5XP2OBDzUoFx7e7Ilof6UaHv6wDGxxKBNbwswAkxaEs1GM/8fJ4l2mkQxgZNptvgAF3amiGfqnyY9hX11lfINYrmns2GGDA/ftmSWQ=="
}
