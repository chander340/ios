import UIKit
import Alamofire
import FSCalendar
import FloatingPanel
class BottomSheetVC: BaseClass,UITableViewDelegate,UITableViewDataSource {
    
    let arr1 = ["1","2","3"]
   
    var calandar : FSCalendar!
    var dataArr = NSArray()
     var eventsArr = NSArray()
    let tableViewww = UITableView()
    
    @IBOutlet weak var outerTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //view.mask.bounds = true
 //       view.clipsToBounds = true
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 25
    //    view.isOpaque = false
    }
    
    public func setBottomSheetData(arr : NSArray) {
        self.dataArr = arr
        print("Inside Bottom Sheet",self.dataArr)
//        if outerTableView.tag == 100{
//            outerTableView.reloadData()
//        } else{
//            print("fdfdfefdf")
//        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        if outerTableView.tag == 100{
            return dataArr.count

        } else {
            return eventsArr.count
        }
    //    return arr1.count
    }
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if outerTableView.tag == 100 {
          
            let cell = tableView.dequeueReusableCell(withIdentifier: "BottomSheetTVC", for: indexPath) as! BottomSheetTVC
            let current = dataArr[indexPath.row] as? NSObject
            self.eventsArr = current?.value(forKey: "data") as! NSArray
            cell.tblVwInner.reloadData()
            
            let date = current?.value(forKey: "title") as? String
            cell.dateLbl.text = HelperClass.changeDateFormat(date: date!.components(separatedBy: "T")[0], sourceFormation: "yyyy-MM-dd", destinationFormat: "EEEE dd, MMMM")
               return cell
            
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "InnerBottomSheetTVC", for: indexPath) as! InnerBottomSheetTVC
             let current = eventsArr[indexPath.row] as? NSObject
            cell.holidayLbl.text = current?.value(forKey: "descTitle") as? String
                return cell
        }
       }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
