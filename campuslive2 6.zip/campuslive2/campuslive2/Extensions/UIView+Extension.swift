import Foundation
import UIKit

extension UIView {
    
    func setGradientBackground(gradientLayer: CAGradientLayer, colorOne: UIColor, colorTwo: UIColor) {
//        let view = UIView()
       // gradientLayer.frame = UIScreen.main.bounds
      //  gradientLayer.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        gradientLayer.frame = UIScreen.main.bounds
        gradientLayer.colors = [colorOne.cgColor, colorTwo.cgColor]
        gradientLayer.locations = [0.0, 1.0]
//        gradientLayer.startPoint = CGPoint(x: 1.0, y: 1.0)
//        gradientLayer.endPoint = CGPoint(x: 0.0, y: 0.0)
        
        gradientLayer.startPoint = CGPoint(x: 1.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 0.0, y: 0.5)
        layer.insertSublayer(gradientLayer, at: 0)
    }
}

extension UIButton {
    func setGradientBackgroundButton(gradientLayer : CAGradientLayer,colorOne: UIColor, colorTwo: UIColor) {
       // let gradientLayer = CAGradientLayer()
            //        let view = UIView()
           // gradientLayer.frame = UIScreen.main.bounds
          //  gradientLayer.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height:  UIScreen.main.bounds.height)
        gradientLayer.frame = bounds
            gradientLayer.colors = [colorOne.cgColor, colorTwo.cgColor]
            gradientLayer.locations = [0.0, 1.0]
    //        gradientLayer.startPoint = CGPoint(x: 1.0, y: 1.0)
    //        gradientLayer.endPoint = CGPoint(x: 0.0, y: 0.0)
            
        gradientLayer.startPoint = CGPoint(x: 1.0, y: 0.5)
            gradientLayer.endPoint = CGPoint(x: 0.0, y: 0.5)
            layer.insertSublayer(gradientLayer, at: 0)
        }
}

//extension UIViewController {
//    func showAlert(alertText : String, alertMessage : String) {
//        let alert = UIAlertController(title: alertText, message: alertMessage, preferredStyle: UIAlertController.Style.alert)
//        alert.addAction(UIAlertAction(title: "Got it", style: UIAlertAction.Style.default, handler: nil))
//    //Add more actions as you see fit
//    self.present(alert, animated: true, completion: nil)
//      }
//}
