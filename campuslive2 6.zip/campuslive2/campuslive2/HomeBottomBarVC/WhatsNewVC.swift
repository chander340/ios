import UIKit
import MSPeekCollectionViewDelegateImplementation
import Alamofire
import Kingfisher
class WhatsNewVC: BaseClass,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,UICollectionViewDelegate{
    var behavior: MSCollectionViewPeekingBehavior!
    var behavior1: MSCollectionViewPeekingBehavior!
    var behavior2: MSCollectionViewPeekingBehavior!
    var objModel: ResponseWhatsNew?
    var announcementsArr:NSArray? = nil
    var newsArr:NSArray?=nil
    var eventsArr:NSArray?=nil
    let layer = CAGradientLayer()
    @IBOutlet weak var collVwAnnouncements: UICollectionView!
    @IBOutlet weak var announcementIcon: UILabel!
    @IBOutlet weak var latestNewsIcon: UILabel!
    @IBOutlet weak var recentEventsIcon: UILabel!
    @IBOutlet weak var collVwLatestNews: UICollectionView!
    @IBOutlet weak var CollVwRecentEvents: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("View Did Load")
        
        view.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        getData(auth_token: UserStoreSingleton.shared.finalAuthToken)
        behavior1 = MSCollectionViewPeekingBehavior()
        behavior1.cellPeekWidth = 8
        behavior1.cellSpacing = 8
        collVwLatestNews.configureForPeekingBehavior(behavior: behavior1)
        
        behavior = MSCollectionViewPeekingBehavior()
        behavior.cellPeekWidth = 8
        behavior.cellSpacing = 8
        collVwAnnouncements.configureForPeekingBehavior(behavior: behavior)
        
        behavior2 = MSCollectionViewPeekingBehavior()
        behavior2.cellPeekWidth = 8
        behavior2.cellSpacing = 8
        CollVwRecentEvents.configureForPeekingBehavior(behavior: behavior2)
        
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.bull_horn, lbl: announcementIcon)
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.news_paper, lbl: latestNewsIcon)
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.star, lbl: recentEventsIcon)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // collVwAnnouncements.reloadData()
        print("ViewDidLayoutSubView")
        
        //        collVwAnnouncements.selectItem(at: .init(row: 0, section: 0), animated: false, scrollPosition: .centeredHorizontally)
        //        collVwLatestNews.selectItem(at: .init(row: 0, section: 0), animated: false, scrollPosition: .centeredHorizontally)
        //        CollVwRecentEvents.selectItem(at: .init(row: 0, section: 0), animated: false, scrollPosition: .centeredHorizontally)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
         layer.frame = view.layer.bounds
        print("ViewWillLayoutSubview")
        collVwAnnouncements.collectionViewLayout.invalidateLayout()
        collVwLatestNews.collectionViewLayout.invalidateLayout()
        CollVwRecentEvents.collectionViewLayout.invalidateLayout()
    }
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        behavior.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
        behavior1.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
        behavior2.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        var count = 0
        if collectionView == self.collVwAnnouncements {
            count =  self.announcementsArr?.count ?? 0
        } else if collectionView == self.collVwLatestNews{
            count = self.newsArr?.count ?? 0
        }else if collectionView == self.CollVwRecentEvents{
            count = self.eventsArr?.count ?? 0
        }
        return count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == collVwAnnouncements {
            
            let cellAnnouncements = collVwAnnouncements.dequeueReusableCell(withReuseIdentifier: "AnnouncemetsCVC", for: indexPath) as? AnnouncemetsCVC
            let current = self.announcementsArr![indexPath.row] as! NSObject
            cellAnnouncements?.dateLbl.text = current.value(forKey: "day") as? String
            cellAnnouncements?.descLbl.text = current.value(forKey: "desc") as? String
            cellAnnouncements?.monthLbl.text = current.value(forKey: "month") as? String
            cellAnnouncements?.yearLbl.text = current.value(forKey: "year") as? String
            //cellAnnouncements?.announcementReadmoreBtn.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
            return cellAnnouncements!
            
        } else if collectionView == collVwLatestNews {
            let cellLatestNews = collVwLatestNews.dequeueReusableCell(withReuseIdentifier: "LatestNewsCVC", for: indexPath) as? LatestNewsCVC
            cellLatestNews?.newsReadMoreBtn.tag = indexPath.row
            let current = self.newsArr![indexPath.row] as! NSObject
            cellLatestNews?.monthLbl.text = current.value(forKey: "month") as? String
            cellLatestNews?.dateLbl.text = current.value(forKey: "day") as? String
            cellLatestNews?.descLbl.text = current.value(forKey: "desc") as? String
            cellLatestNews?.yearLbl.text = current.value(forKey: "year") as? String
            cellLatestNews?.titleLbl.text = current.value(forKey: "title") as? String
            cellLatestNews?.newsReadMoreBtn.addTarget(self, action: #selector(buttonTappedNews), for: .touchUpInside)
            return cellLatestNews!
        } else{
            let cellRecentEvent = CollVwRecentEvents.dequeueReusableCell(withReuseIdentifier: "RecentEventsCVC", for: indexPath) as? RecentEventsCVC
            let current = self.eventsArr![indexPath.row] as! NSObject
            cellRecentEvent?.dateLbl.text = current.value(forKey: "day") as? String
            cellRecentEvent?.monthLbl.text = current.value(forKey: "month") as? String
            cellRecentEvent?.descLbl.text = current.value(forKey: "desc") as? String
            cellRecentEvent?.yearLbl.text = current.value(forKey: "year") as? String
            cellRecentEvent?.titleLbl.text = current.value(forKey: "title") as? String
            cellRecentEvent?.eventsReadmoreBtn.addTarget(self, action: #selector(buttonTappedEvents), for: .touchUpInside)
           
            let imageUrl = current.value(forKey: "imgPath") as? String
            let url = URL(string: imageUrl ?? "")
            //cellRecentEvent?.imgVwBanner.kf.setImage(with: url)
            cellRecentEvent?.imgVwBanner.kf.setImage(with: url, placeholder: UIImage(named: "CampusLIVELogoR"), options: nil, progressBlock: nil)
          //  fullImage.kf.setImage(with: url, placeholder: UIImage(named: "placeholder"), options: nil, progressBlock: nil, completionHandler: nil)
            return cellRecentEvent!
        }
    }
    @objc func buttonTappedNews(sender : UIButton){
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "WebViewVC") as? WebViewVC
        let currenObj = newsArr![sender.tag] as! NSObject
      //  print(sender.tag, ": \(currenObj)")
        let ti = currenObj.value(forKey: "title") as? String
        vc?.screenTitle = ti ?? ""
        vc?.htmlContent = currenObj.value(forKey: "text") as! String
        navigationController?.pushViewController(vc! , animated: true)
    }
    
    @objc func buttonTappedEvents(sender : UIButton){
        let vc = storyboard?.instantiateViewController(withIdentifier: "WebViewVC") as? WebViewVC
        let currenObj = eventsArr![sender.tag] as! NSObject
       // print(sender.tag, ": \(currenObj)")
        let ti = currenObj.value(forKey: "title") as? String
        vc?.screenTitle = ti ?? ""
        vc?.htmlContent = currenObj.value(forKey: "text") as! String
        navigationController?.pushViewController(vc! , animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = view.frame.size.width
     //   print("Setting Cell height and width:", width - 18)
        if collectionView == collVwAnnouncements {
            return CGSize(width: width , height: 180)
        } else if collectionView == collVwLatestNews {
            return CGSize(width:width  , height: 180)
        }else {
            return CGSize(width:width, height: 290)
        }
    }
    
    func getData(auth_token : String){
        if isConnectedToNetwork() {
            showLoader()
            let url = URL(string:  "https://campusdemo.stellarshell.com/api/mobile2/home/"+ModuleIds.WHATS_NEW_MODULE_ID)
            let parameters : Parameters = [:]
            let header: HTTPHeaders = ["Authorization": auth_token]
                 print(auth_token)
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
                //  print(json)
                
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonObject.value(forKey: "status") as! String
                    if status == Constants.OK{
                        let data = jsonObject.value(forKey: Constants.DATA) as! NSObject
                        let annoucements = data.value(forKey: "announcements") as! NSArray
                        let news = data.value(forKey: "news") as! NSArray
                        let events = data.value(forKey: "events") as! NSArray
                        self.announcementsArr = annoucements
                        self.newsArr = news
                        self.eventsArr = events
                       // self.collVwAnnouncements.reloadData()
                        self.collVwAnnouncements.reloadData()
                        self.collVwLatestNews.reloadData()
                        self.CollVwRecentEvents.reloadData()
                     //   print(annoucements)
                        
                    }
                } catch{
                    
                    print("catch")
                    // print("Nothing")
                }
            })
            
        }else{
            
            print("error")
        }
    }
    
//    func getWhatsNewData(auth_token : String){
//        if isConnectedToNetwork() {
//            showLoader()
//            // Internet available
//            let url = URL(string: Urls.BASE_URL)
//            let parameters:Parameters = [:]
//            let header: HTTPHeaders = ["Authorization": auth_token]
//
//
//            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
//                //  print(json)
//                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
//
//                do {
//                    let jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
//                    let status = jsonResult.object(forKey: Constants.STATUS) as! NSString
//                    if status as String == Constants.OK {
//                        //Welcome parent data retrive successfully
//                        let data = jsonResult.object(forKey: Constants.DATA) as! NSObject
//
//                        let jsonData = try? JSONSerialization.data(withJSONObject: data, options: [])
//                        UserStoreSingleton.shared.welcomeData = String(data: jsonData!, encoding: .utf8)
//
//                        // print(UserStoreSingleton.shared.welcomeData!)
//
//                        //                        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
//                        //                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "CollVwVC") as! CollVwVC
//                        //                        self.navigationController?.pushViewController(nextViewController, animated: true)
//
//                    }
//
//                }catch{
//                    print(error)
//                }
//            })
//        } else {
//            // No Internet Connection
//
//            showTopAlert(message: Constants.no_internet)
//        }
//    }
}



