import UIKit
class NotificationsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

}
