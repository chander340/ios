import UIKit
class BottomSheetTVC: UITableViewCell {

    @IBOutlet weak var dateLbl: UILabel!
    
    @IBOutlet weak var tblVwInner: UITableView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
//        greenDotView.layer.masksToBounds = true
//        greenDotView.layer.cornerRadius = 1.5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
extension BottomSheetTVC {

    func setTableViewDataSourceDelegate < D : UITableViewDelegate & UITableViewDataSource>(_ dataSourceDelegate: D, forRow row : Int ) {
        
        tblVwInner.dataSource = dataSourceDelegate
        tblVwInner.delegate = dataSourceDelegate
        tblVwInner.reloadData()
    }
    
    
}
    
    

