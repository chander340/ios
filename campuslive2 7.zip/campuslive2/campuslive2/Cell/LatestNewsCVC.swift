import UIKit

class LatestNewsCVC: UICollectionViewCell {
    
    @IBOutlet weak var dateVw: UIView!
    
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var monthLbl: UILabel!
    @IBOutlet weak var yearLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var newsReadMoreBtn: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.dateVw.layer.cornerRadius = 25
        self.dateVw.layer.masksToBounds = true
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
    }
}
