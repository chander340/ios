import UIKit

class RecentEventsCVC: UICollectionViewCell {
    
    @IBOutlet weak var dateVw: UIView!
    @IBOutlet weak var imgVwBanner: UIImageView!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var monthLbl: UILabel!
    @IBOutlet weak var yearLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    
    @IBOutlet weak var eventsReadmoreBtn: UIButton!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        self.imgVwBanner.layer.masksToBounds = true
        self.imgVwBanner.layer.cornerRadius = 10
        self.dateVw.layer.cornerRadius = 25
        self.dateVw.layer.masksToBounds = true
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
    }
    
}
