import Foundation
import UIKit
import SystemConfiguration
import BRYXBanner

class BaseClass : UIViewController {
    
    func showLoader(){
    
    }
    
    func hideLoader(){
        
    
    }
    func showAlert(message : String) {

    }
    
    func showTopAlert(message : String) {
        let banner = Banner(title: Constants.app_name, subtitle: message, image: UIImage(named: "hide"),backgroundColor: Colors.banner_color)
        banner.dismissesOnTap = true
        banner.imageView.tintColor = .white
        banner.show(duration: 5.0)

    }
    
    func showBottomAlert(message : String) {
           let banner = Banner(title: Constants.app_name, subtitle: message, image: UIImage(named: "hide"),backgroundColor: Colors.banner_color)
           banner.dismissesOnTap = true
           banner.imageView.tintColor = .white
           banner.show(duration: 5.0)

       }
    
    
    
    func isConnectedToNetwork() -> Bool {

        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)

        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
            return false
        }

        /* Only Working for WIFI
        let isReachable = flags == .reachable
        let needsConnection = flags == .connectionRequired

        return isReachable && !needsConnection
        */

        // Working for Cellular and WIFI
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        let ret = (isReachable && !needsConnection)

        return ret
    }
    struct ActivityIndicator {
     
     let viewForActivityIndicator = UIView()
     let view: UIView
     let navigationController: UINavigationController?
     let tabBarController: UITabBarController?
     let activityIndicatorView = UIActivityIndicatorView()
     let loadingTextLabel = UILabel()
     
     var navigationBarHeight: CGFloat { return navigationController?.navigationBar.frame.size.height ?? 0.0 }
     var tabBarHeight: CGFloat { return tabBarController?.tabBar.frame.height ?? 0.0 }
     
        func showActivityIndicator(textlbl : String) {
            viewForActivityIndicator.frame = CGRect(x: 0.0, y: 0.0, width: self.view.frame.size.width, height: self.view.frame.size.height)
            viewForActivityIndicator.backgroundColor = UIColor.lightText
            view.addSubview(viewForActivityIndicator)
            
            activityIndicatorView.center = CGPoint(x: self.view.frame.size.width / 2.0, y: (self.view.frame.size.height - tabBarHeight - navigationBarHeight) / 2.0)
            
            loadingTextLabel.textColor = UIColor.black
            loadingTextLabel.text = textlbl
            loadingTextLabel.font = UIFont(name: "Avenir Light", size: 15)
            loadingTextLabel.sizeToFit()
            loadingTextLabel.center = CGPoint(x: activityIndicatorView.center.x, y: activityIndicatorView.center.y + 30)
            viewForActivityIndicator.addSubview(loadingTextLabel)
            
            activityIndicatorView.hidesWhenStopped = true
        activityIndicatorView.style = .whiteLarge
        activityIndicatorView.color = UIColor.gray
      //  activityIndicatorView
            viewForActivityIndicator.addSubview(activityIndicatorView)
            activityIndicatorView.startAnimating()
        }
        
        func stopActivityIndicator() {
            viewForActivityIndicator.removeFromSuperview()
            activityIndicatorView.stopAnimating()
            activityIndicatorView.removeFromSuperview()
        }
    }
}
    
    
    

