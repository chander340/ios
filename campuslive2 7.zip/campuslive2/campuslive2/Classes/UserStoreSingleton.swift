import Foundation
import UIKit
class UserStoreSingleton: NSObject {

static let shared = UserStoreSingleton()
private override init() {}
    
    var finalAuthToken : String! {
        get {
            return UserDefaults().object(forKey: "finalAuthToken") as? String
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: "finalAuthToken")
        }
    }
    
    
    var welcomeData : String! {
                    get {
                        return UserDefaults().object(forKey: "welcomeData") as? String
                    }
                    set {
                        UserDefaults.standard.setValue(newValue, forKey: "welcomeData")
                    }
                }
    var userName : String! {
           get {
               return UserDefaults().object(forKey: "userName") as? String
           }
           set {
               UserDefaults.standard.setValue(newValue, forKey: "userName")
           }
       }
    
    var userRole : Int! {
              get {
                  return UserDefaults().object(forKey: "userRole") as? Int
              }
              set {
                  UserDefaults.standard.setValue(newValue, forKey: "userRole")
              }
          }
    
    var userId : String! {
              get {
                  return UserDefaults().object(forKey: "userId") as? String
              }
              set {
                  UserDefaults.standard.setValue(newValue, forKey: "userId")
              }
          }
    var personId : String! {
              get {
                  return UserDefaults().object(forKey: "personId") as? String
              }
              set {
                  UserDefaults.standard.setValue(newValue, forKey: "personId")
              }
          }
    
    var schoolId : String! {
        get {
            return UserDefaults().object(forKey: "schoolId") as? String
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: "SchoolId")
        }
    }
    
    var isNew : Bool {
           get {
            return UserDefaults().object(forKey: "isNew") as? Bool ?? false
           }
           set {
               UserDefaults.standard.setValue(newValue, forKey: "isNew")
           }
       }
 
    var authToken : String! {
           get {
               return UserDefaults().object(forKey: "authToken") as? String
           }
           set {
               UserDefaults.standard.setValue(newValue, forKey: "authToken")
           }
       }
    
    var personCode : String! {
              get {
                  return UserDefaults().object(forKey: "personCode") as? String
              }
              set {
                  UserDefaults.standard.setValue(newValue, forKey: "personCode")
              }
          }
    
    var userChildern : String! {
                 get {
                     return UserDefaults().object(forKey: "userChildern") as? String
                 }
                 set {
                     UserDefaults.standard.setValue(newValue, forKey: "userChildern")
                 }
             }
}


