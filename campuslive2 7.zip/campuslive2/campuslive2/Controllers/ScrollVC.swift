import UIKit

class ScrollVC: UIViewController {

    @IBOutlet weak var textLabel: UILabel!
    @IBOutlet weak var btnLabel: UIButton!
    override func viewDidLoad() {
       
        super.viewDidLoad()
        view.backgroundColor = .systemPink
    }
}
