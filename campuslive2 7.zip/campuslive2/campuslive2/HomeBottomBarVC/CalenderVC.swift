import UIKit
import FSCalendar
import FloatingPanel
import Alamofire
class CalenderVC: BaseClass, FSCalendarDelegate, FSCalendarDataSource,FloatingPanelControllerDelegate,UITableViewDelegate,UITableViewDataSource{
    
    // MARK:- Variables
    var titleDateArr = [String]()
    var currentYear = Int()
    @IBOutlet var ContentView: UIView!
    var calendarScreenData = NSArray()
    var formatterMonth = DateFormatter()
    var formatterYear = DateFormatter()
    let layer = CAGradientLayer()
    let calanderLayer = CAGradientLayer()
    let fpc = FloatingPanelController()
    private var currentPage: Date?
    let fpccc = FloatingPanelController()
    // lazy var BottomBarVC = storyboard?.instantiateViewController(withIdentifier: "DemoTableView") as! MainTableView
    
    var dataArr = NSArray()
    var eventArr = NSArray()
    var arr1 = ["1","2","3"]
    
    //MARK:- Constraint Layout
    
    @IBOutlet weak var trailingConstraintButtonView: NSLayoutConstraint!
    @IBOutlet weak var trailingConstraintCalendar: NSLayoutConstraint!
    @IBOutlet weak var landscapeView: UIView!
    @IBOutlet weak var leadingViewSheet: NSLayoutConstraint!
    @IBOutlet weak var bottomConstraintView: NSLayoutConstraint!
    @IBOutlet weak var ViewHeightConstraint: NSLayoutConstraint!
    
    //let appearance = SurfaceAppearance()
    // MARK:- Outlets
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var previousButton: UIButton!
    @IBOutlet weak var nextbutton: UIButton!
    @IBOutlet weak var landscapeTableView: UITableView!
    
    //MARK:- Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.initialApiCall()
        }
        self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
        initialInit()
        // Must
    }
    //  MARK:- Override functions
    
    
    // Functions of NotificationCentre
    
    func initialApiCall(){
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        var dictCurrentMonth : Dictionary<String,String> = Dictionary()
        dictCurrentMonth.updateValue(currentYear, forKey: "currentyear")
        dictCurrentMonth.updateValue(currentMonth , forKey: "currentmonth")
        NotificationCenter.default.post(name: .twitterName, object: nil,userInfo: dictCurrentMonth)
        print(dictCurrentMonth)
    }
    func initialInit(){
        landscapeView.layer.cornerRadius = 10 
        fpc.delegate = self
        //  let fpc = FloatingPanelController(delegate: self)
        fpc.contentMode = .fitToBounds
        fpc.layout = MyFloatingPanelLayout()
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let contentVC = storyBoard.instantiateViewController(withIdentifier: "FloatingPanelVC") as! FloatingPanelVC
        fpc.set(contentViewController: contentVC)
        fpc.addPanel(toParent: self)
        ContentView.clipsToBounds = true
        calendar.delegate = self
        calendar.dataSource = self
        calendar.scrollEnabled = true
        calendar.calendarHeaderView.scrollEnabled = true
        //  calendar.appearance.subtitleDefaultColor = UIColor.clear
        calendar.appearance.headerMinimumDissolvedAlpha = 0
        calendar.calendarHeaderView.backgroundColor = UIColor.init(named: "131114")
        calendar.scrollDirection = .horizontal
        view.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        calendar.placeholderType =  FSCalendarPlaceholderType.none
        calendar.setGradientBackground(gradientLayer:calanderLayer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        fpc.layout = MyFloatingPanelLayout()
        layer.frame = view.layer.bounds
        calendar.layer.frame = view.layer.bounds
        calanderLayer.frame = view.layer.bounds // This is working Fine
        calendar.pagingEnabled = true
        calendar.appearance.headerMinimumDissolvedAlpha = 0
        let width : CGFloat = self.ContentView.bounds.width / 2
        let height : CGFloat = 500
        if UIDevice.current.orientation.isLandscape  {
            fpc.hide()
            
            //  landscapeView.isHidden = false
            self.trailingConstraintButtonView.constant = width
            self.trailingConstraintCalendar.constant = width
            self.ViewHeightConstraint.constant = height
            self.leadingViewSheet.constant = width
        } else {
            landscapeView.isHidden = true
            self.trailingConstraintCalendar.constant = 0
            self.ViewHeightConstraint.constant = 350
            trailingConstraintButtonView.constant = 0
            fpc.show()
            //        }else if UIDevice.current.orientation.isFlat  {
            //            landscapeView.isHidden = true
            //            self.trailingConstraintCalendar.constant = width
            //            fpc.hide()
            //            self.ViewHeightConstraint.constant = height
            //        }  else {
            //            self.trailingConstraintCalendar.constant = 0
            //            self.ViewHeightConstraint.constant = 350
            //            fpc.show()
            //        }
        }
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let fpc = FloatingPanelController(delegate: self)
        fpc.layout = MyFloatingPanelLayout()
        
        calanderLayer.frame = view.layer.bounds
        layer.frame = view.layer.bounds
        calendar.pagingEnabled = true
        calendar.appearance.headerMinimumDissolvedAlpha = 0
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        let width : CGFloat = self.ContentView.bounds.width / 2
        let height : CGFloat = 500
        if UIDevice.current.orientation.isLandscape {
            fpc.hide()
            landscapeView.isHidden = false
            self.trailingConstraintButtonView.constant = width
            self.trailingConstraintCalendar.constant = width
            self.ViewHeightConstraint.constant = height
            self.leadingViewSheet.constant = width
        }
        if UIDevice.current.orientation.isPortrait {
            self.trailingConstraintCalendar.constant = 0
            fpc.layout = MyFloatingPanelLayout()
            fpc.show()
            calendar.isHidden = false
            print("portrait")
        } else {
            print("No Orientations")
        }
    }
    // MARK:- Delegates and Fuctions
    
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        print("Selected")
    }
    
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {
        cell.eventIndicator.numberOfEvents = 0
        cell.eventIndicator.isHidden = false
        cell.eventIndicator.color = UIColor.white
    }
    //   func calendar(calendar: FSCalendar!, hasEventForDate date: NSDate!) -> Bool {
    //let formatter = DateFormatter()
    // formatter.dateFormat = "EEEE dd, MMMM"
    //  let date1 = formatter.stringFromDate(d)
    // let date2 = formatter.stringFromDate(date)
    //  return date1 == date2 ? 1 : 0
    //    }
    
    // MARK:- Action Buttons
    @IBAction func actionBtnPreviousMonth(_ sender: Any) {
        calendar.setCurrentPage(getPreviousMonth(date: calendar.currentPage), animated: true)
        //        let calandaarr = calendar.currentPage
        //        formatterYear.dateFormat = "yyy"
        //        let currentPage = formatterYear.string(from: calandaarr)
        //        print(currentPage)
        self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        
        var dictmonthPrevious : Dictionary<String,String> = Dictionary()
        dictmonthPrevious.updateValue(currentYear, forKey: "previousY")
        dictmonthPrevious.updateValue(currentMonth , forKey: "previousM")
        NotificationCenter.default.post(name: .fbName, object: nil,userInfo: dictmonthPrevious)
        
    }
    @IBAction func actionBtnNextMonth(_ sender: Any) {
        calendar.setCurrentPage(getNextMonth(date: calendar.currentPage), animated: true)
        self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        
        var dictmonthNext : Dictionary<String,String> = Dictionary()
        dictmonthNext.updateValue(currentYear, forKey: "nextY")
        dictmonthNext.updateValue(currentMonth , forKey: "nextM")
        NotificationCenter.default.post(name:.yearName, object: nil,userInfo: dictmonthNext)
        
    }
    
    
    // MARK:- Functions
    func getNextMonth(date:Date)->Date {
        return  Calendar.current.date(byAdding: .month, value: 1, to:date)!
    }
    
    func getPreviousMonth(date:Date)->Date {
        return  Calendar.current.date(byAdding: .month, value: -1, to:date)!
    }
    
    
    //    override func viewDidLayoutSubviews() {
    //        super.viewDidLayoutSubviews()
    //        if #available(iOS 10, *) {
    //            fpc.layer.cornerRadius = 9.0
    //            visualEffectView.clipsToBounds = true
    //        }
    //    }
    
    
    //MARK:- HIT API
    
    
    func getDataCalanderVC(auth_token : String){
        if isConnectedToNetwork() {
            showLoader()
            let currentPageDate = calendar.currentPage
            formatterMonth.dateFormat = "MM"
            formatterYear.dateFormat = "yyy"
            let currentYear = formatterYear.string(from: currentPageDate)
            let currentMonth = formatterMonth.string(from: currentPageDate)
            //  print(currentYear,"InsideGetDataFuction",currentMonth)
            let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/homecalendar/" + "\(currentMonth)" + "/\(currentYear)")
            let parameters : Parameters = [:]
            let header: HTTPHeaders = ["Authorization": auth_token]
            //     print(auth_token)
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
                //    print(json)
                
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonObject.value(forKey: "status") as! String
                    
                    if status == Constants.OK{
                        
                        self.dataArr = jsonObject.value(forKey: "data") as! NSArray
                        print("API DATA FROM JSON",self.dataArr)
                        self.landscapeTableView.reloadData()
                        
                        
                        //                    let finalDate = HelperClass.changeDateFormat(date: titleofEvent.components(separatedBy: "T")[0], sourceFormation: "yyyy-MM-dd", destinationFormat: "EEEE dd, MMMM")
                        //
                        //                        self.titleDateArr.append(finalDate)
                        //
                        //                        print(self.titleDateArr)
                        //  nextViewController.dataArr = self.calendarScreenData
                        
                        //     nextViewController.tableViewww.reloadData()
                        //                        let event1 = data[1] as! NSObject
                        //                        let title1 = event1.value(forKey: "title") as!String
                        //                        let totalEvents = event1.value(forKey: Constants.DATA) as! NSArray
                        //                        print(totalEvents)
                        
                    }
                } catch{
                    
                    print("catch")
                    // print("Nothing")
                }
            })
            
        }else{
            
            print("error")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        if tableView == landscapeTableView {
            return dataArr.count
        }else{
            return eventArr.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == landscapeTableView {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "MainTableView2Cell", for: indexPath) as! MainTableView2Cell
            let current = dataArr[indexPath.row] as? NSObject
            self.eventArr = current?.value(forKey: "data") as! NSArray
            let date = current?.value(forKey: "title") as? String
            cell.titleLbl.text = HelperClass.changeDateFormat(date: date!.components(separatedBy: "T")[0], sourceFormation: "yyyy-MM-dd", destinationFormat: "EEEE dd, MMMM")
            //   cell.titleLbl.text = arr1[indexPath.row]
            return cell
            
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "InsideTableView2Cell", for: indexPath) as! InsideTableView2Cell
            let current = eventArr[indexPath.row] as? NSObject
            cell.holidayLbl.text = current?.value(forKey: "descTitle") as? String
            //   cell.holidayLbl.text = arr1[indexPath.row]
            return cell
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if tableView == landscapeTableView {
            return 100
        } else{
            
            return 25
        }
        
    }
}

class MyFloatingPanelLayout: FloatingPanelLayout {
    let position: FloatingPanelPosition = .bottom
    let initialState: FloatingPanelState = .tip
    var anchors: [FloatingPanelState: FloatingPanelLayoutAnchoring] {
        return [
            .full: FloatingPanelLayoutAnchor(absoluteInset: 16.0, edge: .top, referenceGuide: .safeArea),
            .half: FloatingPanelLayoutAnchor(fractionalInset: 0.31, edge: .bottom, referenceGuide: .safeArea),
            .tip: FloatingPanelLayoutAnchor(absoluteInset: 28.0, edge: .bottom, referenceGuide: .safeArea),
        ]
    }
}

