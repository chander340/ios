import UIKit

class WhatsNewVC: UIViewController {

//    var whatsNew = UITabBarItem()
//    let calenderVC = CalenderVC()
//    let notificationsVC = NotificationsVC()
    
    
    
    @IBOutlet weak var customView: UIView!
    override func viewDidLoad() {
  
        super.viewDidLoad()
//        let tabBarController = UITabBarController()
//        tabBarController.viewControllers = [calenderVC, notificationsVC]
            
      
    }
}
