import UIKit
import Alamofire
import FloatingPanel
import FSCalendar
class FloatingPanelVC: BaseClass,UITableViewDelegate,UITableViewDataSource{
 
     var dataArr = NSArray()
     var eventsArr = NSArray()
     let arr1 = ["1","2","3","4","5"]
     var arr2 = NSArray()
    
    @IBOutlet weak var tableViewMain: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(facebook(notification:)), name: .fbName , object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(twitter(notification:)), name: .twitterName , object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(year(notification:)), name: .yearName , object: nil)
       // self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
    }
    @objc func year(notification: Notification){
        let userInfo = notification.userInfo as! Dictionary<String, String>
        let year = userInfo["nextY"]
        if let month = userInfo["nextM"] {
            print(month)
            print(year ?? "")
           self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken, monthUrl: month , yearUrl: year!)
        }
        
    }
    
    @objc func facebook(notification: Notification){
           let userInfo = notification.userInfo as! Dictionary<String, String>
           let year = userInfo["previousY"]
           if let month = userInfo["previousM"] {
               print(month)
               print(year ?? "")
              self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken, monthUrl: month , yearUrl: year!)
           }
           
       }
  @objc func twitter(notification: Notification){
    let userInfo = notification.userInfo as! Dictionary<String, String>
       let year = userInfo["currentyear"]
       if let month = userInfo["currentmonth"] {
           print(month)
           print(year ?? "")
          self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken, monthUrl: month , yearUrl: year!)
       }

    }
    
    public func setBottomSheetData(arr : NSArray) {
    self.dataArr = arr2
      print("Set Bottom Sheet Data",dataArr.count)
    }
    func getDataCalanderVC(auth_token : String, monthUrl : String, yearUrl: String){
        if isConnectedToNetwork() {
            showLoader()
            let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/homecalendar/" + "\(monthUrl)/" + yearUrl)
            let parameters : Parameters = [:]
            let header: HTTPHeaders = ["Authorization": auth_token]
            //     print(auth_token)
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
               //  print(json)
                
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonObject.value(forKey: "status") as! String
                    
                    if status == Constants.OK{
                        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "FloatingPanelVC") as! FloatingPanelVC
                        self.dataArr = jsonObject.value(forKey: "data") as! NSArray
                        self.tableViewMain.reloadData()
                
                    }
                } catch{
                    print("catch")
                }
            })
            
        }else{
            print("error")
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tableViewMain {
        return dataArr.count
    } else{
            print("returning",eventsArr)
            return eventsArr.count
    }
        
}
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == tableViewMain {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "MainTableView", for: indexPath) as! MainTableView
            let current = dataArr[indexPath.row] as? NSObject
         //   self.eventsArr
            self.eventsArr = current?.value(forKey: "data") as! NSArray
            let tag = indexPath.row
            cell.InsideTableView.tag = tag
            let date = current?.value(forKey: "title") as? String
            cell.tiitleLbl.text = HelperClass.changeDateFormat(date: date!.components(separatedBy: "T")[0], sourceFormation: "yyyy-MM-dd", destinationFormat: "EEEE dd, MMMM")
            return cell
            
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "InsideTableView", for: indexPath) as! InsideTableView
            let current = eventsArr[indexPath.row] as? NSObject
            print("Event Arrray",eventsArr)
            cell.InnerLbl.text = current?.value(forKey: "descTitle") as? String
                return cell
        }
     }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
extension Notification.Name{
    static let fbName = Notification.Name("Facebook")
    static let twitterName = Notification.Name("Twitter")
    static let yearName = Notification.Name("Year")
}

