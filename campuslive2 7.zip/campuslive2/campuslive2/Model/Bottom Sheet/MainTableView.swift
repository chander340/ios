import UIKit
class MainTableView: UITableViewCell {
    
    @IBOutlet weak var tiitleLbl: UILabel!
    @IBOutlet weak var InsideTableView: UITableView!
  
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
extension MainTableView {

    func setTableViewDataSourceDelegate < D : UITableViewDelegate & UITableViewDataSource>(_ dataSourceDelegate: D, forRow row : Int ) {
        
        InsideTableView.dataSource = dataSourceDelegate
        InsideTableView.delegate = dataSourceDelegate
        InsideTableView.reloadData()
    }
    
    
}
