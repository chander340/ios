//
//  InsideTableView2Cell.swift
//  campuslive2
//
//  Created by Appcrunk Mac Mini on 13/10/20.
//  Copyright © 2020 Appcrunk Mac Mini. All rights reserved.
//

import UIKit

class InsideTableView2Cell: UITableViewCell {

    @IBOutlet weak var holidayLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
