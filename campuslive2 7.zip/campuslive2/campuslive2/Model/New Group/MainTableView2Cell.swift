import UIKit

class MainTableView2Cell: UITableViewCell {

    @IBOutlet weak var insideTableView2: UITableView!
    @IBOutlet weak var titleLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
extension MainTableView2Cell {

    func setTableViewDataSourceDelegate < D : UITableViewDelegate & UITableViewDataSource>(_ dataSourceDelegate: D, forRow row : Int ) {
        
        insideTableView2.dataSource = dataSourceDelegate
        insideTableView2.delegate = dataSourceDelegate
        insideTableView2.reloadData()
    }
    
    
}
