import UIKit

class CollVwCell: UICollectionViewCell {
    
    @IBOutlet weak var lblData: UILabel!
    
    @IBOutlet weak var bottomView: UIView!
    
    override func awakeFromNib() {
               super.awakeFromNib()
        
     //   self.lblData.text?.capitalized(with: nil)
//               imgVwRestaurants.layer.cornerRadius = 10
//       //        imgVwRestaurant.layer.borderColor = UIColor.red as! CGColor
//               imgVwRestaurants.layer.borderWidth = 2
//            self.imgVwRestaurants.layer.borderColor = CGColor(srgbRed: 24/255, green: 66/255, blue: 85/255, alpha: 1)
                 }
    
//    override func didMoveToWindow() {
//        self.setTitle(self.title(for: .normal)?.uppercased(), for: .normal)
//
//        self.lblData.
//    }
           }
