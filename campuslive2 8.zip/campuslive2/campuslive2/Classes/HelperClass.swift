import Foundation
import UIKit

struct HelperClass {
    static func changeDateFormat(date:String, sourceFormation:String, destinationFormat:String)->String{
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = sourceFormation
        let showDate = inputFormatter.date(from: date)
        inputFormatter.dateFormat = destinationFormat
        let resultString = inputFormatter.string(from: showDate!)
        return resultString
    }
    static func setFontAwesomeIcon(iconCode : String,lbl: UILabel){
        let iconDecimal = Int(iconCode, radix: 16)!
        let unicodeIcon = Character(UnicodeScalar(iconDecimal)!)
        lbl.text = "\(unicodeIcon)"
    }
    
    static func decryptRsaBase64Encrypted(_ string: String, withPublicKeyBase64: String) -> String? {
        if let encrypted = Data(base64Encoded: string, options: Data.Base64DecodingOptions.init(rawValue: 0)) {
            if let data = RSAUtils.decryptWithRSAPublicKey(encrypted, pubkeyBase64: withPublicKeyBase64, keychainTag: "") {
                return String(data: data, encoding: .utf8)
            }
        }
        return nil
    }
    
    
    static func encryptRsaBase64(_ string: String, withPublickKeyBase64: String) -> String? {
        if let data = string.data(using: .utf8) {
            if let encrypted = RSAUtils.encryptWithRSAPublicKey(data, pubkeyBase64: withPublickKeyBase64, keychainTag: "") {
                return encrypted.base64EncodedString()
            }
        }
        return nil
    }
    static func encrypt(string: String, publicKey: String?) -> String? {
        guard let publicKey = publicKey else { return nil }
        
        let keyString = publicKey.replacingOccurrences(of: "-----BEGIN RSA PUBLIC KEY-----\n", with: "").replacingOccurrences(of: "\n-----END RSA PUBLIC KEY-----", with: "")
        guard let data = Data(base64Encoded: keyString) else { return nil }
        
        var attributes: CFDictionary {
            return [kSecAttrKeyType         : kSecAttrKeyTypeRSA,
                    kSecAttrKeyClass        : kSecAttrKeyClassPublic,
                    kSecAttrKeySizeInBits   : 2048,
                    kSecReturnPersistentRef : true] as CFDictionary
        }
        
        var error: Unmanaged<CFError>? = nil
        guard let secKey = SecKeyCreateWithData(data as CFData, attributes, &error) else {
            print(error.debugDescription)
            return nil
        }
        return encrypt(string: string, publicKey: secKey)
    }
    
    static func encrypt(string: String, publicKey: SecKey) -> String? {
        let buffer = [UInt8](string.utf8)
        
        var keySize   = SecKeyGetBlockSize(publicKey)
        var keyBuffer = [UInt8](repeating: 0, count: keySize)
        
        // Encrypto  should less than key length
        guard SecKeyEncrypt(publicKey, SecPadding.PKCS1, buffer, buffer.count, &keyBuffer, &keySize) == errSecSuccess else { return nil }
        return Data(bytes: keyBuffer, count: keySize).base64EncodedString()
    }
    
    
    
    
 
 
}
struct AppUtility {

    static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {

        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.orientationLock = orientation
        }
    }

    /// OPTIONAL Added method to adjust lock and rotate to the desired orientation
    static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {

        self.lockOrientation(orientation)

        UIDevice.current.setValue(rotateOrientation.isPortrait, forKey: "orientation")
    }

}








//struct HelperClass {
//
//    func createGredientBackground(layer : CAGradientLayer,view : UIView) {
//
//          let end = UIColor(red: 247 / 255, green: 93 / 255, blue: 89 / 255, alpha: 1).cgColor
//          let start = UIColor(red: 255 / 255, green: 229 / 255, blue: 180 / 255, alpha: 1).cgColor
//          layer.frame = view.layer.bounds
//          layer.colors = [start,end]
//          layer.frame = view.bounds //self.view.frame
//          print(layer.frame)
//          layer.startPoint = CGPoint(x: 0.0, y: 0.5)
//          layer.endPoint = CGPoint(x: 1.0, y: 0.5)
//          view.layer.insertSublayer(layer, at: 0)
//      }
//
//}
