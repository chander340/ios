import UIKit
import SideMenu
import Alamofire
class CollVwVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
// MARK:- Variables
    var selectedCell: CollVwCell? = nil
    var arr = [String]()
    let array = ["Boy","Girl","man"]
    let layer = CAGradientLayer()
    var totalModuleArr = NSArray()
 // MARK:- Outlets
    @IBOutlet weak var sideMenuIcon: UILabel!
    @IBOutlet weak var containerVw: UIView!
    @IBOutlet weak var collVw: UICollectionView!
    
    var vc1:UIViewController?=nil
    var vc2:UIViewController?=nil
    var vc3:UIViewController?=nil
    var vc4:UIViewController?=nil
    
    // MARK:- Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let welcomeDataString = UserStoreSingleton.shared.welcomeData
        let data = welcomeDataString!.data(using: .utf8)!
        do {
            if let jsonArray = try JSONSerialization.jsonObject(with: data, options : .allowFragments) as? [Dictionary<String,Any>]
            {
                self.totalModuleArr = jsonArray as NSArray
                for i in 0...totalModuleArr.count - 1 {
                    let current = totalModuleArr[i] as? NSObject
                    let name = current?.value(forKey: "name") as? String
                    arr.append(name!)
                   // print("\(i): ", name!)
                }
                self.collVw.reloadData()
                //print("Showing data inside COllVWCHIH",totalModuleArr) // use the json here
            } else {
                print("bad json")
            }
        } catch let error as NSError {
            print(error)
        }
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.side_menu_icon, lbl: sideMenuIcon)
        view.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        // setup()
    }
   // MARK:- Override Methods
    
    override func viewDidLayoutSubviews() {
        layer.frame = view.layer.bounds
    }
    // collectionViewDelegateDatasource
    
    // MARK:- Action Button
    @IBAction func showSideMenuBtn(_ sender: Any) {
 
        let menu = storyboard!.instantiateViewController(withIdentifier: "SideMenuNavigationControllerr") as! SideMenuNavigationController
        menu.leftSide = true
        menu.menuWidth = view.layer.frame.width / 1.3
        menu.presentationStyle = .menuSlideIn
        present(menu, animated: true, completion: nil)
   print("SideMenuButton is Working")
    }
    // MARK:- DataSource and Delegates
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       // return arr.count
        return arr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collVw.dequeueReusableCell(withReuseIdentifier: "CollVwCell", for: indexPath) as? CollVwCell
        let capitalizedArray = arr.map { $0.uppercased()}
        if indexPath.row == 0 && self.selectedCell == nil {
            self.selectedCell = cell
            cell?.bottomView.isHidden = false
        }
        //TOP BAR MENUCONTROLLER
        if indexPath.row == 0 {
            //Return first module view according to the module ID
            setContainerView(position: 0)
        }
       // cell?.lblData.text = arr[indexPath.row]
        cell?.lblData.text = capitalizedArray[indexPath.row]
        return cell!
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collVw.cellForItem(at: indexPath) as! CollVwCell
        if self.selectedCell != nil{
            print("selected cell is not nil: ", indexPath.row)
            self.selectedCell?.bottomView.isHidden = true
            cell.bottomView.isHidden = false
            self.selectedCell = cell
        }else{
            print("selected cell is nil")
            cell.bottomView.isHidden = false
            self.selectedCell = cell
        }
        
        if indexPath.row != 0 {
            containerVw.subviews.forEach ({
                $0.removeFromSuperview()
            })
        }
        setContainerView(position: indexPath.row)
    }
    
    // MARK:- Functions
    private func setContainerView(position:Int){
        let currentObj = self.totalModuleArr[position] as? NSObject
        let moduleId = currentObj?.value(forKey: "id") as? String
        if  moduleId == ModuleIds.HOME_MODULE_ID{
            //MARK:- This is Pending
            if vc1 == nil {
                let vc = storyboard?.instantiateViewController(withIdentifier: "HomeVC") as? HomeVC
                let currentObj = self.totalModuleArr[position] as? NSObject
                vc?.homeData = currentObj?.value(forKey: "children") as! NSArray
                self.addChild(vc!)
                vc!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc!.view)
                vc!.didMove(toParent: self)
                vc1 = vc
            }else{
                self.addChild(vc1!)
                vc1!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc1!.view)
                vc1!.didMove(toParent: self)
            }
            
            
        }else if moduleId == ModuleIds.SCHOOL_MODULE_ID{
            
            //return School view
            let vc = storyboard?.instantiateViewController(withIdentifier: "SchoolVC") as? SchoolVC
            self.addChild(vc!)
            vc!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
            self.containerVw.addSubview(vc!.view)
            vc!.didMove(toParent: self)
        
        
        
        
        }else if moduleId == ModuleIds.CLASS_MODULE_ID{
            //return Class view
            let vc = storyboard?.instantiateViewController(withIdentifier: "ClassVC") as? ClassVC
            self.addChild(vc!)
            vc!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
            self.containerVw.addSubview(vc!.view)
            vc!.didMove(toParent: self)
        }else if moduleId == ModuleIds.ROUTINE_MODULE_ID{
            //return Routine view
            let vc = storyboard?.instantiateViewController(withIdentifier: "RoutinesVC") as? RoutinesVC
            self.addChild(vc!)
            vc!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
            self.containerVw.addSubview(vc!.view)
            vc!.didMove(toParent: self)
        }else if moduleId == ModuleIds.WELL_BEING_MODULE_ID{
            //return Well Being view
            let vc = storyboard?.instantiateViewController(withIdentifier: "WellBeingVC") as? WellBeingVC
            self.addChild(vc!)
            vc!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
            self.containerVw.addSubview(vc!.view)
            vc!.didMove(toParent: self)
        }
    }
}
