import UIKit
import Kingfisher
class SideMenuViewController: UIViewController {
    
    //MARK:- Outlets
    @IBOutlet weak var profileIcon: UILabel!
    @IBOutlet weak var changePasswordIcon: UILabel!
    @IBOutlet weak var childrenIcon: UILabel!
    @IBOutlet weak var aboutUSIcon: UILabel!
    @IBOutlet weak var contactUsIcon: UILabel!
    @IBOutlet weak var privacyPolicyIcon: UILabel!
    @IBOutlet weak var feedbackIcon: UILabel!
    @IBOutlet weak var shareIcon: UILabel!
    @IBOutlet weak var stellerLogoIcon: UIImageView!
    
    //MARK:- View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setIcon()
        let imageUrl = Urls.SCHOOL_LOGO_BASE_URL + UserStoreSingleton.shared.authToken
        let url = URL(string: imageUrl)
        stellerLogoIcon.kf.setImage(with: url, placeholder: UIImage(named: "placeholder"), options: nil, progressBlock: nil)
        
    }
    //MARK:- Functions
    func setIcon(){
        HelperClass.setFontAwesomeIcon(iconCode: IconCodeSideMenu.PROFILE_ICON_FONT, lbl: profileIcon)
        HelperClass.setFontAwesomeIcon(iconCode: IconCodeSideMenu.CHILDREN_ICON_FONT, lbl: childrenIcon)
        HelperClass.setFontAwesomeIcon(iconCode: IconCodeSideMenu.CHANGE_PASSWORD_ICON_FONT, lbl: changePasswordIcon)
        HelperClass.setFontAwesomeIcon(iconCode: IconCodeSideMenu.ABOUT_US_ICON_FONT, lbl: aboutUSIcon)
        HelperClass.setFontAwesomeIcon(iconCode: IconCodeSideMenu.CONTACT_US_ICON_FONT, lbl: contactUsIcon)
        HelperClass.setFontAwesomeIcon(iconCode: IconCodeSideMenu.PRIVACY_POLICY_ICON_FONT, lbl: privacyPolicyIcon)
        HelperClass.setFontAwesomeIcon(iconCode: IconCodeSideMenu.FEEDBACK_ICON_FONT, lbl: feedbackIcon)
        HelperClass.setFontAwesomeIcon(iconCode: IconCodeSideMenu.SHARE_ICON_FONT, lbl: shareIcon)
    }
    //MARK:- Action Buttons
    
    @IBAction func signOutButton(_ sender: Any) {
        showSimpleAlert()
    }
    func showSimpleAlert() {
        let alert = UIAlertController(title: "Sign out?", message: "Do you want to logout?",         preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
            //Cancel Action
        }))
        alert.addAction(UIAlertAction(title: "Logout",
                                      style: UIAlertAction.Style.destructive,
                                      handler: {(_: UIAlertAction!) in
                                        
                                        UserDefaults.standard.set(false, forKey: "ISUSERLOGGEDIN")
                                        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                                        self.navigationController?.pushViewController(nextViewController, animated: false)
                                        //Sign out action
        }))
        self.present(alert, animated: true, completion: nil)
    }
}
