import UIKit
import WebKit

class WebViewVC: UIViewController {
    
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var titleLbl: UILabel!
     
    var htmlContent = String()
    var screenTitle = String()
    
    let layer = CAGradientLayer()
    @IBOutlet weak var webViewShow: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
      
        view.setGradientBackground(gradientLayer: self.layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        self.titleLbl.text = self.screenTitle
        self.webViewShow.loadHTMLString(htmlContent, baseURL: nil)
        
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        // loginBtn.frame = view.layer.bounds
        layer.frame = view.layer.bounds
    }
    @IBAction func actionBtnBack(_ sender: Any) {
 // let vc = storyboard?.instantiateViewController(withIdentifier: "WhatsNewVC") as? WhatsNewVC
        navigationController?.popViewController(animated: true)
    }
    

}

