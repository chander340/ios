import UIKit
import FSCalendar
import FloatingPanel
import Alamofire
class CalenderVC: BaseClass, FSCalendarDelegate, FSCalendarDataSource,FloatingPanelControllerDelegate{
    
    // MARK:- Variables
    var titleDateArr = [String]()
    var currentYear = Int()
    @IBOutlet var ContentView: UIView!
    var calendarScreenData = NSArray()
    var formatterMonth = DateFormatter()
    var formatterYear = DateFormatter()
    let layer = CAGradientLayer()
    let calanderLayer = CAGradientLayer()
    let fpc = FloatingPanelController()
    private var currentPage: Date?
    let fpccc = FloatingPanelController()
    
    var formatter = DateFormatter()
    
    
    
    // New New New
//    var datesWithEvent = ["2020-10-03", "2020-10-06", "2020-10-12", "2020-10-25"]
//    var datesWithMultipleEvents = ["2020-10-08", "2020-10-16", "2020-10-20", "2020-10-28"]
//    fileprivate lazy var dateFormatter2: DateFormatter = {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "yyyy-MM-dd"
//        return formatter
//    }()
    
    
    // MARK:- here is formatter
    //let formatter = DateFormatter()
    var dataArr = NSArray()
    var eventArr = NSArray()
    //let appearance = SurfaceAppearance()
    // MARK:- Outlets
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var previousButton: UIButton!
    @IBOutlet weak var nextbutton: UIButton!
 
    
    //MARK:- Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.initialApiCall()
        }
       // self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
        initialInit()
        // Must
    }
    //  MARK:- Override functions
    // Functions of NotificationCentre
    func initialApiCall(){
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        var dictCurrentMonth : Dictionary<String,String> = Dictionary()
        dictCurrentMonth.updateValue(currentYear, forKey: "currentyear")
        dictCurrentMonth.updateValue(currentMonth , forKey: "currentmonth")
        NotificationCenter.default.post(name: .currentMonthYear, object: nil,userInfo: dictCurrentMonth)
        print(dictCurrentMonth)
    }
    func initialInit(){
       // landscapeView.layer.cornerRadius = 10
        fpc.delegate = self
        //  let fpc = FloatingPanelController(delegate: self)
        fpc.contentMode = .fitToBounds
        fpc.layout = MyFloatingPanelLayout()
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let contentVC = storyBoard.instantiateViewController(withIdentifier: "FloatingPanelVC") as! FloatingPanelVC
        //let contentVC = storyBoard.instantiateViewController(withIdentifier: "Floa) as! BottomSheetVC
        fpc.set(contentViewController: contentVC)
        fpc.addPanel(toParent: self)
        ContentView.clipsToBounds = true
        calendar.delegate = self
        calendar.dataSource = self
        calendar.scrollEnabled = true
        calendar.calendarHeaderView.scrollEnabled = true
        //  calendar.appearance.subtitleDefaultColor = UIColor.clear
        calendar.appearance.headerMinimumDissolvedAlpha = 0
        calendar.calendarHeaderView.backgroundColor = UIColor.init(named: "131114")
        calendar.scrollDirection = .horizontal
        view.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        calendar.placeholderType =  FSCalendarPlaceholderType.none
        calendar.setGradientBackground(gradientLayer:calanderLayer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        fpc.layout = MyFloatingPanelLayout()
        // This is working Fine
        calendar.pagingEnabled = true
        calendar.appearance.headerMinimumDissolvedAlpha = 0
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let fpc = FloatingPanelController(delegate: self)
        fpc.layout = MyFloatingPanelLayout()
        calendar.appearance.headerMinimumDissolvedAlpha = 0
    }
    
    // MARK:- Delegates and Fuctions
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
       // print("Selected")
    }
    
    func calendarCurrentPageDidChange(_ calendar: FSCalendar) {
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        print("Did Select Row",currentYear,currentMonth)
        var dictmonthPreviouss : Dictionary<String,String> = Dictionary()
        dictmonthPreviouss.updateValue(currentYear, forKey: "scrollYear")
        dictmonthPreviouss.updateValue(currentMonth , forKey: "scrollMonth")
        NotificationCenter.default.post(name: .scrollNotification, object: nil,userInfo: dictmonthPreviouss)
        
    }
    
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {
       
        cell.eventIndicator.numberOfEvents = 0
        cell.eventIndicator.isHidden = false
        cell.eventIndicator.color = UIColor.white
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        
        formatter.dateFormat = "dd-MM-yyyy"
        guard let eventDate = formatter.date(from: "22-11-2020") else {return 0}
        if date.compare(eventDate) == .orderedSame {
            return 2
        }
        return 1
        
    }
//    func calendar(calendar: FSCalendar!, hasEventForDate date: NSDate!) -> Bool {
//
//       // formatter.dateFormat = "EEEE dd, MMMM"
//
//        //        let date1 = formatter.stringFromDate(d)
////        let date2 = formatter.stringFromDate(date)
////        return date1 == date2 ? 1 : 0
//
//        return
//    }
    
    // MARK:- Action Buttons
    @IBAction func actionBtnPreviousMonth(_ sender: Any) {
        calendar.setCurrentPage(getPreviousMonth(date: calendar.currentPage), animated: true)
        //        let calandaarr = calendar.currentPage
        //        formatterYear.dateFormat = "yyy"
        //        let currentPage = formatterYear.string(from: calandaarr)
        //        print(currentPage)
   //     self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        
        var dictmonthPrevious : Dictionary<String,String> = Dictionary()
        dictmonthPrevious.updateValue(currentYear, forKey: "previousY")
        dictmonthPrevious.updateValue(currentMonth , forKey: "previousM")
        NotificationCenter.default.post(name: .previousMonthYear, object: nil,userInfo: dictmonthPrevious)
        
    }
    @IBAction func actionBtnNextMonth(_ sender: Any) {
        calendar.setCurrentPage(getNextMonth(date: calendar.currentPage), animated: true)
      //  self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        
        var dictmonthNext : Dictionary<String,String> = Dictionary()
        dictmonthNext.updateValue(currentYear, forKey: "nextY")
        dictmonthNext.updateValue(currentMonth , forKey: "nextM")
        NotificationCenter.default.post(name:.nextYearMonth, object: nil,userInfo: dictmonthNext)
    }
    
    
    // MARK:- Functions
    func getNextMonth(date:Date)->Date {
        return  Calendar.current.date(byAdding: .month, value: 1, to:date)!
    }
    
    func getPreviousMonth(date:Date)->Date {
        return  Calendar.current.date(byAdding: .month, value: -1, to:date)!
    }

    //MARK:- HIT API
}

class MyFloatingPanelLayout: FloatingPanelLayout {
    let position: FloatingPanelPosition = .bottom
    let initialState: FloatingPanelState = .tip
    var anchors: [FloatingPanelState: FloatingPanelLayoutAnchoring] {
        return [
            .full: FloatingPanelLayoutAnchor(absoluteInset: 16.0, edge: .top, referenceGuide: .safeArea),
            .half: FloatingPanelLayoutAnchor(fractionalInset: 0.31, edge: .bottom, referenceGuide: .safeArea),
            .tip: FloatingPanelLayoutAnchor(absoluteInset: 28.0, edge: .bottom, referenceGuide: .safeArea),
        ]
    }
}

