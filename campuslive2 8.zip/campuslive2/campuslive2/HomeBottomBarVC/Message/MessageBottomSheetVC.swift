import UIKit
import Alamofire
import SwiftyJSON
import Kingfisher
class MessageBottomSheetVC: UIViewController,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,UICollectionViewDelegate {
    
    var currentId = String()
    var currentClass = String()
    var teacherArr = NSArray()
    var dataArr = NSArray()
    var jsonData = JSON()
    var modelViewArr = [ModelView]()
    
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var lblNoTeachers: UILabel!
    @IBOutlet weak var lblClass: UILabel!
    @IBOutlet weak var collVwTeacher: UICollectionView!
    @IBOutlet weak var containerView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        lblNoTeachers.isHidden = true
        lblClass.text = currentClass as String
        collVwTeacher.dataSource = self
        collVwTeacher.delegate = self
        containerView.layer.masksToBounds = true
        containerView.layer.cornerRadius =  5
        getMessageData(auth_token : UserStoreSingleton.shared.finalAuthToken)
        NotificationCenter.default.addObserver(self, selector: #selector(getIndex(notification:)), name: .currentIndexId , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(getZeroIndex(notification:)), name: .firstIndexData , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(hideArrData(notification:)), name: .hideData , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(showArrData(notification:)), name: .ShowData , object: nil)
        
    }
    @objc func hideArrData(notification: Notification){
        lblNoTeachers.isHidden = false
        viewContainer.isHidden = true
    }
    
    @objc func showArrData(notification: Notification){
        lblNoTeachers.isHidden = true
        viewContainer.isHidden = false
    }
    @objc func getIndex(notification: Notification){
        let userInfo = notification.userInfo as! Dictionary<String, String>
        let currentClass = userInfo["CurrentClass"] as! String
        if let curentId = userInfo["CurrentId"] {
            self.currentId = curentId
            getTeachersId(sId : currentId)
            
            self.lblClass.text = currentClass
            // collVwTeacher.reloadData()
            print("Hi there is am current Class",currentClass)
        }
    }
    @objc func getZeroIndex(notification: Notification){
        let userInfo = notification.userInfo as! Dictionary<String, String>
        let currenntID = userInfo["ZeroIndexId"] as? String
        if let curentClass = userInfo["ZeroIndexClass"] {
            lblClass.text = curentClass
        }
    }
    
    func getMessageData(auth_token : String){
        let url = URL(string: Urls.message_Directory)
        let parameters : Parameters = [:]
        let header: HTTPHeaders = ["Authorization": auth_token]
        //     print(auth_token)
        AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
            //  print("Message Directory",json)
            let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
            do {
                let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                let status = jsonObject.value(forKey: "status") as! String
                
                if status == Constants.OK{
                    let data = jsonObject.value(forKey: "data") as! NSArray
                    self.dataArr = data
                    self.getTeachersId(sId : self.currentId)
                    self.collVwTeacher.reloadData()
                }
            } catch{
                print("catch")
            }
        })
    }
    
    func getTeachersId(sId : String){
        for i in 0...self.dataArr.count-1 {
            // print("Hi I am I",i)
            let idDict = self.dataArr[i] as! NSObject
            let id = idDict.value(forKey: "sId") as! String
            
            if id == sId {
                let teachersArr = idDict.value(forKey: "teachers") as! NSArray
                
             //   print("Hi there i am teachers",teachersArr)
                self.teacherArr = teachersArr
                collVwTeacher.reloadData()
            }
        }
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return teacherArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collVwTeacher.dequeueReusableCell(withReuseIdentifier: "MessageBottomSheetCVC", for: indexPath) as! MessageBottomSheetCVC
        let current = teacherArr[indexPath.row] as! NSObject
        cell.lblSubject.text = current.value(forKey: "subject") as? String
        let url = current.value(forKey: "pImg") as! String
        let imageUrl = URL(string: url )
        cell.imgVwTeacher.kf.setImage(with: imageUrl, placeholder: UIImage(named: "placeholder"), options: nil, progressBlock: nil)
        cell.lblTeacherName.text = current.value(forKey: "name") as? String
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let current = teacherArr[indexPath.row] as! NSObject
        let viewC = storyboard?.instantiateViewController(withIdentifier: "ChatVC") as! ChatVC
        viewC.name = (current.value(forKey: "name") as? String)!
        viewC.language = (current.value(forKey: "subject") as? String)!
        viewC.imageProfile = (current.value(forKey: "pImg") as? String)!
        viewC.tId = (current.value(forKey: "tId") as! String)
        viewC.teacherId = (current.value(forKey: "uId") as! String)
        self.navigationController?.pushViewController( viewC, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = view.frame.size.width / 2.5
        return CGSize(width: width , height: 183)
    }
}

extension Notification.Name{
    static let currentIndexId = Notification.Name("CurrentId")
    static let firstIndexData = Notification.Name("FirstIndexData")
    static let hideData = Notification.Name("HideData")
    static let ShowData = Notification.Name("ShowData")
}
