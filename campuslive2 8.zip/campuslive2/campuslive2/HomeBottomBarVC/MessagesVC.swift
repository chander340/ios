import UIKit
import NVActivityIndicatorView
import Alamofire
import FloatingPanel
import MSPeekCollectionViewDelegateImplementation
import Kingfisher
class MessagesVC: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout, FloatingPanelControllerDelegate{
   
    let fpc = FloatingPanelController()
    var behaviourColl :  MSCollectionViewPeekingBehavior!
    var messageArr = NSArray()
    var studentArr = NSArray()
    var indexPath : Int? = nil
    var currentId = String()
    
    @IBOutlet weak var lblNoMessages: UILabel!
    @IBOutlet weak var activityIndicator: NVActivityIndicatorView!
    @IBOutlet weak var collvwStudents: UICollectionView!
    @IBOutlet weak var tblVwMessage: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblNoMessages.isHidden = true
        activityIndicator.color = Colors.right_gradient
        activityIndicator.type = .ballSpinFadeLoader
        getStudentData()
        behaviourColl = MSCollectionViewPeekingBehavior()
        behaviourColl.cellPeekWidth = 4
        behaviourColl.cellSpacing = 4
        collvwStudents.configureForPeekingBehavior(behavior: behaviourColl)
        initialInit()
        getMessageData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: "NTQy")
    }
    func initialInit(){
        fpc.delegate = self
        fpc.contentMode = .fitToBounds
        fpc.layout = MyFloatingPanelLayoutMessage()
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let contentVC = storyBoard.instantiateViewController(withIdentifier: "MessageBottomSheetVC") as! MessageBottomSheetVC
        fpc.set(contentViewController: contentVC)
        fpc.addPanel(toParent: self)
        fpc.hide()
    }
    func getStudentData(){
        let studentData = UserStoreSingleton.shared.userChildern
        self.studentArr = studentData!
    }
    func getMessageData(auth_token : String ,id : String){
        activityIndicator.startAnimating()
        tblVwMessage.isHidden = true
        lblNoMessages.isHidden = true
       // NTQw
        let url = URL(string: Urls.BASE_URL_API + Urls.message_Data + id)
        let parameters : Parameters = [:]
        let header: HTTPHeaders = ["Authorization": auth_token]
        //     print(auth_token)
        AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { [self] (json) in
           //  print(json)
            let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
            do {
                let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                let status = jsonObject.value(forKey: "status") as! String
                if status == Constants.OK{
                    let data = jsonObject.value(forKey: "data") as! NSDictionary
                    let jsonArr = data.value(forKey: "messages") as! NSArray
                    
                    // doing this think
                    if jsonArr.count == 0{
                        tblVwMessage.isHidden = true
                        lblNoMessages.isHidden = false
                        NotificationCenter.default.post(name: .hideData, object: nil,userInfo: nil)
                    }else{
                        tblVwMessage.isHidden = false
                        NotificationCenter.default.post(name: .ShowData, object: nil,userInfo: nil)
                    }
                    self.messageArr = jsonArr as NSArray
                    self.tblVwMessage.reloadData()
                    self.activityIndicator.stopAnimating()
                }
            } catch{
                print("catch")
            }
        })
    }
    
    @IBAction func actionBtnShowSheet(_ sender: Any) {
        fpc.show()
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        // fpc.layout = MyFloatingPanelLayoutMessage()
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
      //  print(behaviourColl.currentIndex)
        let indexPath = behaviourColl.currentIndex
        let currentIDD = studentArr[indexPath] as! NSObject
        let iddd = currentIDD.value(forKey:"id") as! String
        let classId = currentIDD.value(forKey:"nowIn") as! String
        // for firing a notification
        // firing id notification
        var dictCurrentIndex : Dictionary<String,String> = Dictionary()
        let currentIndexIdd = iddd as String
        let currentClass = classId as String
        dictCurrentIndex.updateValue(currentClass, forKey: "CurrentClass")
        dictCurrentIndex.updateValue(currentIndexIdd, forKey: "CurrentId")
        NotificationCenter.default.post(name : .currentIndexId ,object : nil,userInfo : dictCurrentIndex)
        
        self.getMessageData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: iddd)
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        behaviourColl.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return studentArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      //  print(indexPath.row)
        let cell = collvwStudents.dequeueReusableCell(withReuseIdentifier: "StudentCollectionViewCell", for: indexPath) as! StudentCollectionViewCell
        cell.activeStatusLbl.isHidden = true
        cell.lblInactiveStatus.isHidden = true
        let current = self.studentArr[indexPath.row] as! NSObject
        let sts = current.value(forKey: "sts") as! Int
        let gender = current.value(forKey: "gen") as? String
        if gender == "M" {
            cell.backgroundColor = UIColor(red: 0, green: 95, blue: 126, alpha: 0.8)
        }
        
        if sts == 1 {
            cell.activeStatusLbl.isHidden = false
            cell.lblInactiveStatus.isHidden = true
        }else{
            cell.activeStatusLbl.isHidden = true
            cell.lblInactiveStatus.isHidden = false
            
        }
     //   cell.backgroundColor = UIColor.blue
        if indexPath.row == 0 {
        // Making current index is 0 because we have to get first index value
        var zeroIndexDict : Dictionary<String,String> = Dictionary()  //Dictonary
        let currentIDD = studentArr[0] as! NSObject    // Array
        let iddd = currentIDD.value(forKey:"id") as! String // Current ID
        let classId = currentIDD.value(forKey:"nowIn") as! String // Current Class
    //    let gender =
            
            
        self.getMessageData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: iddd)
            //Notification Trigger
            let zeroClass = classId
            let zeroId = iddd
            zeroIndexDict.updateValue(zeroClass, forKey: "ZeroIndexClass")
            zeroIndexDict.updateValue(zeroId, forKey: "ZeroIndexId")
            NotificationCenter.default.post(name : .firstIndexData,object : nil ,userInfo : zeroIndexDict)
        }
        self.currentId = current.value(forKey: "id") as! String
        cell.nameLbl.text = current.value(forKey: "fullName") as? String
        cell.classLbl.text = current.value(forKey: "nowIn") as? String
        cell.studentIdLbl.text = current.value(forKey: "number") as? String
        //  cell.activeStatusLbl.text = current.value(forKey: "sts") as? String
        let imageUrl = current.value(forKey: "img") as? String
        let url = URL(string: imageUrl ?? "")
        cell.profileImgVw.kf.setImage(with: url, placeholder: UIImage(named: "placeholder"), options: nil, progressBlock: nil)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = view.frame.size.width - 15
        //   print("Setting Cell height and width:", width - 18)
        return CGSize(width: width , height: 89)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messageArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVwMessage.dequeueReusableCell(withIdentifier: "MessageTVCell", for: indexPath) as! MessageTVCell
        let current = messageArr[indexPath.row] as! NSObject
        cell.nameLbl.text = current.value(forKey: "title") as? String
        cell.languageLbl.text = current.value(forKey: "subTitle") as? String
        let imageUrl = current.value(forKey: "pImg") as? String
        let url = URL(string: imageUrl ?? "")
        cell.imgVwProfile.kf.setImage(with: url, placeholder: UIImage(named: "placeholder"), options: nil, progressBlock: nil)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let current = messageArr[indexPath.row] as! NSObject
     //   let imageUrl = current.value(forKey: "pImg") as? String
        let viewC = storyboard?.instantiateViewController(withIdentifier: "ChatVC") as! ChatVC
        viewC.name = (current.value(forKey: "title") as? String)!
        viewC.language = (current.value(forKey: "subTitle") as? String)!
        viewC.imageProfile = (current.value(forKey: "pImg") as? String)!
        viewC.tId = (current.value(forKey: "tId") as! String)
        viewC.teacherId = (current.value(forKey: "uId") as! String)
        self.navigationController?.pushViewController( viewC, animated: true)
    }
}

class MyFloatingPanelLayoutMessage: FloatingPanelLayout {
    let position: FloatingPanelPosition = .bottom
    let initialState: FloatingPanelState = .half
    var anchors: [FloatingPanelState: FloatingPanelLayoutAnchoring] {
        return [
            .full: FloatingPanelLayoutAnchor(absoluteInset: 16.0, edge: .top, referenceGuide: .safeArea),
            .half: FloatingPanelLayoutAnchor(fractionalInset: 0.50, edge: .bottom, referenceGuide: .safeArea),
            .tip: FloatingPanelLayoutAnchor(absoluteInset: 0.0, edge: .bottom, referenceGuide: .safeArea),
        ]
    }
}

