import UIKit
import Alamofire
import NVActivityIndicatorView
class NotificationVC: UIViewController,UITableViewDelegate,UITableViewDataSource{
   
    var notificationArr = NSArray()
    
    @IBOutlet weak var activityIndicator: NVActivityIndicatorView!
    @IBOutlet weak var tblVwNotification: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        activityIndicator.color = Colors.right_gradient
        activityIndicator.type = .circleStrokeSpin
        getNotificationData(auth_token : UserStoreSingleton.shared.finalAuthToken)
    }
    

    func getNotificationData(auth_token : String){
        activityIndicator.startAnimating()
        //   tblVwMessage.isHidden = true
        //   lblNoMessages.isHidden = true
        //   print(currentYear,"InsideGetDataFuction",currentMonth)
        let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/notifications" )
        let parameters : Parameters = [:]
        let header: HTTPHeaders = ["Authorization": auth_token]
        //   print(auth_token)
        AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: {  (json) in
        //  print(json)
            let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
            do {
                let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                let status = jsonObject.value(forKey: "status") as! String
                if status == Constants.OK{
                    let data = jsonObject.value(forKey: "data") as! NSDictionary
                    let jsonArr = data.value(forKey: "notifications") as! NSArray
                    
                    self.notificationArr = jsonArr
                    print("Here i am",self.notificationArr)
//                    self.messageArr = jsonArr as NSArray
//
                  self.tblVwNotification.reloadData()
                    self.activityIndicator.stopAnimating()
                }
            } catch{
                print("catch")
                // print("Nothing")
            }
        })
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return notificationArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVwNotification.dequeueReusableCell(withIdentifier: "NotificationTVC") as! NotificationTVC
        let current = notificationArr[indexPath.row] as! NSObject
        cell.lblTitle.text = current.value(forKey: "title") as? String
        cell.lblTime.text = current.value(forKey: "time") as? String
        cell.lblSubtitle.text = current.value(forKey: "content") as? String
        let icon = current.value(forKey: "iconText") as! String
        HelperClass.setFontAwesomeIcon(iconCode: icon, lbl: cell.lblIcon)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 68
    }
}
