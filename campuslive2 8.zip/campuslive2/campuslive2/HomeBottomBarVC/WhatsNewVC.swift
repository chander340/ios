import UIKit
import MSPeekCollectionViewDelegateImplementation
import Alamofire
import Kingfisher
import NVActivityIndicatorView
class WhatsNewVC: BaseClass,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,UICollectionViewDelegate{
    var behavior: MSCollectionViewPeekingBehavior!
    var behavior1: MSCollectionViewPeekingBehavior!
    var behavior2: MSCollectionViewPeekingBehavior!
    var announcementsArr:NSArray? = nil
    var newsArr:NSArray?=nil
    var eventsArr:NSArray?=nil
    let layer = CAGradientLayer()
    
    @IBOutlet weak var activityAnnouncements: NVActivityIndicatorView!
    @IBOutlet weak var activityLatest: NVActivityIndicatorView!
    @IBOutlet weak var activityRecent: NVActivityIndicatorView!
    
    @IBOutlet weak var collVwAnnouncements: UICollectionView!
    @IBOutlet weak var announcementIcon: UILabel!
    @IBOutlet weak var latestNewsIcon: UILabel!
    @IBOutlet weak var recentEventsIcon: UILabel!
    @IBOutlet weak var collVwLatestNews: UICollectionView!
    @IBOutlet weak var CollVwRecentEvents: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("View Did Load")
        activityLatest.type = .circleStrokeSpin
        activityRecent.type = .circleStrokeSpin
        activityAnnouncements.type = .circleStrokeSpin
        activityLatest.color = .white
        activityRecent.color = .white
        activityAnnouncements.color = .white
        
        view.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        getData(auth_token: UserStoreSingleton.shared.finalAuthToken)
        behavior1 = MSCollectionViewPeekingBehavior()
        behavior1.cellPeekWidth = 8
        behavior1.cellSpacing = 8
        collVwLatestNews.configureForPeekingBehavior(behavior: behavior1)
        
        behavior = MSCollectionViewPeekingBehavior()
        behavior.cellPeekWidth = 8
        behavior.cellSpacing = 8
        collVwAnnouncements.configureForPeekingBehavior(behavior: behavior)
        
        behavior2 = MSCollectionViewPeekingBehavior()
        behavior2.cellPeekWidth = 8
        behavior2.cellSpacing = 8
        CollVwRecentEvents.configureForPeekingBehavior(behavior: behavior2)
        
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.bull_horn, lbl: announcementIcon)
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.news_paper, lbl: latestNewsIcon)
        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.star, lbl: recentEventsIcon)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // collVwAnnouncements.reloadData()
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
         layer.frame = view.layer.bounds
    }
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        behavior.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
        behavior1.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
        behavior2.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        var count = 0
        if collectionView == self.collVwAnnouncements {
            count =  self.announcementsArr?.count ?? 0
        } else if collectionView == self.collVwLatestNews{
            count = self.newsArr?.count ?? 0
        }else if collectionView == self.CollVwRecentEvents{
            count = self.eventsArr?.count ?? 0
        }
        return count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == collVwAnnouncements {
            
            let cellAnnouncements = collVwAnnouncements.dequeueReusableCell(withReuseIdentifier: "AnnouncemetsCVC", for: indexPath) as? AnnouncemetsCVC
            let current = self.announcementsArr![indexPath.row] as! NSObject
            cellAnnouncements?.dateLbl.text = current.value(forKey: "day") as? String
            cellAnnouncements?.descLbl.text = current.value(forKey: "desc") as? String
            let numChars = cellAnnouncements?.descLbl.text?.utf8CString.count ?? 0
            if numChars >= 300 {
                cellAnnouncements?.readMoreAnnouncement.isHidden = false
            }
            cellAnnouncements?.monthLbl.text = current.value(forKey: "month") as? String
            cellAnnouncements?.yearLbl.text = current.value(forKey: "year") as? String
            return cellAnnouncements!
            
        } else if collectionView == collVwLatestNews {
            let cellLatestNews = collVwLatestNews.dequeueReusableCell(withReuseIdentifier: "LatestNewsCVC", for: indexPath) as? LatestNewsCVC
            cellLatestNews?.newsReadMoreBtn.tag = indexPath.row
            let current = self.newsArr![indexPath.row] as! NSObject
            cellLatestNews?.monthLbl.text = current.value(forKey: "month") as? String
            cellLatestNews?.dateLbl.text = current.value(forKey: "day") as? String
            cellLatestNews?.descLbl.text = current.value(forKey: "desc") as? String
            cellLatestNews?.yearLbl.text = current.value(forKey: "year") as? String
            cellLatestNews?.titleLbl.text = current.value(forKey: "title") as? String
            cellLatestNews?.newsReadMoreBtn.addTarget(self, action: #selector(buttonTappedNews), for: .touchUpInside)
            return cellLatestNews!
        } else{
            let cellRecentEvent = CollVwRecentEvents.dequeueReusableCell(withReuseIdentifier: "RecentEventsCVC", for: indexPath) as? RecentEventsCVC
            let current = self.eventsArr![indexPath.row] as! NSObject
            cellRecentEvent?.dateLbl.text = current.value(forKey: "day") as? String
            cellRecentEvent?.monthLbl.text = current.value(forKey: "month") as? String
            cellRecentEvent?.descLbl.text = current.value(forKey: "desc") as? String
            cellRecentEvent?.yearLbl.text = current.value(forKey: "year") as? String
            cellRecentEvent?.titleLbl.text = current.value(forKey: "title") as? String
            cellRecentEvent?.eventsReadmoreBtn.addTarget(self, action: #selector(buttonTappedEvents), for: .touchUpInside)
            let imageUrl = current.value(forKey: "imgPath") as? String
            let url = URL(string: imageUrl ?? "")
            cellRecentEvent?.imgVwBanner.kf.setImage(with: url, placeholder: UIImage(named: "placeholder"), options: nil, progressBlock: nil)
            return cellRecentEvent!
        }
    }
    @objc func buttonTappedNews(sender : UIButton){
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "WebViewVC") as? WebViewVC
        let currenObj = newsArr![sender.tag] as! NSObject
        // print(sender.tag, ": \(currenObj)")
        vc?.screenTitle = "News"
        vc?.htmlContent = currenObj.value(forKey: "text") as! String
        navigationController?.pushViewController(vc! , animated: true)
    }
    
    @objc func buttonTappedEvents(sender : UIButton){
        let vc = storyboard?.instantiateViewController(withIdentifier: "WebViewVC") as? WebViewVC
        let currenObj = eventsArr![sender.tag] as! NSObject
        //print(sender.tag, ": \(currenObj)")
        vc?.screenTitle = "Events"
        vc?.htmlContent = currenObj.value(forKey: "text") as! String
        navigationController?.pushViewController(vc! , animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = view.frame.size.width
        if collectionView == collVwAnnouncements {
            return CGSize(width: width , height: 180)
        } else if collectionView == collVwLatestNews {
            return CGSize(width:width  , height: 180)
        }else {
            return CGSize(width:width, height: 290)
        }
    }
    
    func getData(auth_token : String){
        if isConnectedToNetwork() {
            activityRecent.startAnimating()
            activityLatest.startAnimating()
            activityAnnouncements.startAnimating()
            let url = URL(string:  "https://campusdemo.stellarshell.com/api/mobile2/home/"+ModuleIds.WHATS_NEW_MODULE_ID)
            let parameters : Parameters = [:]
            let header: HTTPHeaders = ["Authorization": auth_token]
                 print(auth_token)
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonObject.value(forKey: "status") as! String
                    if status == Constants.OK{
                        let data = jsonObject.value(forKey: Constants.DATA) as! NSObject
                        let annoucements = data.value(forKey: "announcements") as! NSArray
                        let news = data.value(forKey: "news") as! NSArray
                        let events = data.value(forKey: "events") as! NSArray
                        self.announcementsArr = annoucements
                        self.newsArr = news
                        self.eventsArr = events
                        self.collVwAnnouncements.reloadData()
                        self.collVwLatestNews.reloadData()
                        self.CollVwRecentEvents.reloadData()
                        
                        self.activityRecent.stopAnimating()
                        self.activityLatest.stopAnimating()
                        self.activityAnnouncements.stopAnimating()
                    }
                } catch{
                    print("catch")
                }
            })
            
        }else{
            print("error")
        }
    }
}



