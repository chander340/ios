import UIKit
class CalenderVC: UIViewController {

    @IBOutlet weak var secondItem: UITabBarItem!
    
//    override func viewWillAppear(_ animated: Bool) {
//        secondItem.title = "Calander"
//    }
    override func viewDidLoad() {
        super.viewDidLoad()
     //   let item = UITabBarItem()
//            secondItem.title = "Calander"
//        if #available(iOS 13.0, *) {
//            secondItem.image = UIImage(systemName: "plus")
//        } else {
//
//            print("error")
        
       // }
    }
}
