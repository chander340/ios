import UIKit
import Alamofire
import FloatingPanel
import FSCalendar
import NVActivityIndicatorView
class FloatingPanelVC: BaseClass,UITableViewDelegate,UITableViewDataSource{
    
    var dataArr = NSArray()
    var eventsArr = NSMutableArray()
    //var arr2 = NSArray()
    
    @IBOutlet weak var lblNoEvent: UILabel!
    @IBOutlet weak var activityIndicator: NVActivityIndicatorView!
    @IBOutlet weak var tableViewMain: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblNoEvent.isHidden = true
        
        
        activityIndicator.type = .ballPulseRise
        activityIndicator.color = Colors.right_gradient
        NotificationCenter.default.addObserver(self, selector: #selector(previousMonth(notification:)), name: .previousMonthYear , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(currentMonth(notification:)), name: .currentMonthYear , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(nextYear(notification:)), name: .nextYearMonth , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(scrollNotification(notification:)), name: .scrollNotification , object: nil)
        // self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
    }
    
    @objc func scrollNotification(notification: Notification){
        let userInfo = notification.userInfo as! Dictionary<String, String>
        let year = userInfo["scrollYear"]
        if let month = userInfo["scrollMonth"] {
            self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken, monthUrl: month , yearUrl: year!)
        }
    }
    
    
    
    
    @objc func nextYear(notification: Notification){
        let userInfo = notification.userInfo as! Dictionary<String, String>
        let year = userInfo["nextY"]
        if let month = userInfo["nextM"] {
            self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken, monthUrl: month , yearUrl: year!)
        }
    }
    @objc func previousMonth(notification: Notification){
        let userInfo = notification.userInfo as! Dictionary<String, String>
        let year = userInfo["previousY"]
        if let month = userInfo["previousM"] {
            print(month)
            print(year ?? "")
            self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken, monthUrl: month , yearUrl: year!)
        }
    }
    
    @objc func currentMonth(notification: Notification){
        let userInfo = notification.userInfo as! Dictionary<String, String>
        let year = userInfo["currentyear"]
        if let month = userInfo["currentmonth"] {
            self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken, monthUrl: month , yearUrl: year!)
        }
    }
    
    //    public func setBottomSheetData(arr : NSArray) {
    //    self.dataArr = arr2
    //      print("Set Bottom Sheet Data",dataArr.count)
    //    }
    func getDataCalanderVC(auth_token : String, monthUrl : String, yearUrl: String){
        lblNoEvent.isHidden = true
        tableViewMain.isHidden = true
        activityIndicator.startAnimating()
        // eventsArr.removeObject(at: 0)
        if isConnectedToNetwork() {
            showLoader()
            let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/homecalendar/" + "\(monthUrl)/" + yearUrl)
            let parameters : Parameters = [:]
            let header: HTTPHeaders = ["Authorization": auth_token]
            //     print(auth_token)
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
                //  print(json)
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonObject.value(forKey: "status") as! String
                    
                    if status == Constants.OK{
                        self.dataArr = jsonObject.value(forKey: "data") as! NSArray
                        
                        if self.dataArr.count == 0 {
                            self.tableViewMain.isHidden = true
                            self.lblNoEvent.isHidden = false
                            
                        }
                        
                        
                        self.activityIndicator.stopAnimating()
                        self.tableViewMain.reloadData()
                        self.tableViewMain.isHidden = false
                        //    NotificationCenter.default.post(name : .reloadTableInside ,object : nil)
                        //  self.eventsArr.removeObject(at: 0)
                    }
                    
                    
                } catch{
                    print("catch")
                }
            })
        }else{
            print("error")
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 100 {
            return dataArr.count
        } else{
            // print("returning",eventsArr)
            return eventsArr.count
        }
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView.tag == 100 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MainTableView", for: indexPath) as! MainTableView
            let current = dataArr[indexPath.row] as? NSObject
            self.eventsArr = current?.value(forKey: "data") as! NSMutableArray
            cell.InsideTableView.reloadData()
            print("Hi i am event arr in table view tag == 100",eventsArr)
            
            //print("Here i am event Arr in swift IOS",eventsArr)
            let date = current?.value(forKey: "title") as? String
            cell.tiitleLbl.text = HelperClass.changeDateFormat(date: date!.components(separatedBy: "T")[0], sourceFormation: "yyyy-MM-dd", destinationFormat: "EEEE dd, MMMM")
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "InsideTableView", for: indexPath) as! InsideTableView
            let current = eventsArr[indexPath.row] as? NSObject
            //  print("Hi there i am event Arr",eventsArr)
            cell.InnerLbl.text = current?.value(forKey: "descTitle") as? String
            return cell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView.tag == 100 {
            return 90
            
        }else{
            
            return 40
        }
        
        
    }
    
}
extension Notification.Name{
    static let previousMonthYear = Notification.Name("Facebook")
    static let currentMonthYear = Notification.Name("Twitter")
    static let nextYearMonth = Notification.Name("Year")
    static let scrollNotification = Notification.Name("ScrollNotify")
}

