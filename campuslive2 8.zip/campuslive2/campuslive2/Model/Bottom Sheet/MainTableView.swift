import UIKit
import Alamofire
import SwiftyJSON
class MainTableView: UITableViewCell {
    
    var dataArr = NSArray()
    var eventArr = NSArray()
    var jsonData = JSON()
    
    var modelViewArr = [ModelView]()
    var modelViewSectionArr = [ModelView]()
    
    @IBOutlet weak var tiitleLbl: UILabel!
    @IBOutlet weak var InsideTableView: UITableView!

    override func awakeFromNib() {
        super.awakeFromNib()
    
        NotificationCenter.default.addObserver(self, selector: #selector(getReload(notification:)), name: .reloadTableInside , object: nil)
       
//        getDataCalanderVC(auth_token : UserStoreSingleton.shared.finalAuthToken)
//        getMessageData(auth_token : UserStoreSingleton.shared.finalAuthToken)
//
        
    }
    
    @objc func getReload(notification: Notification){
     self.InsideTableView.reloadData()
//        
//        func setTableViewDataSourceDelegate < D : UITableViewDelegate & UITableViewDataSource>(_ dataSourceDelegate: D, forRow row : Int ) {
//            InsideTableView.dataSource = dataSourceDelegate
//            InsideTableView.delegate = dataSourceDelegate
//            InsideTableView.reloadData()
//        }
        print("Notification is Fired")
        
//        let userInfo = notification.userInfo as! Dictionary<String, String>
//        let currentClass = userInfo["CurrentClass"] as! String
//        if let curentId = userInfo["CurrentId"] {
//            self.currentId = curentId
//            getTeachersId(sId : currentId)
//
//            self.lblClass.text = currentClass
//            // collVwTeacher.reloadData()
//            print("Hi there is am current Class",currentClass)
//        }
    }
    
    
    
    
    
    
    
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return dataArr.count
//    }
    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = InsideTableView.dequeueReusableCell(withIdentifier: "InsideTableView", for: indexPath) as! InsideTableView
//        let current = dataArr[indexPath.row] as? NSObject
//        //  print(current as? NSObject)
//        // let date = current?.value(forKey: "title") as? String
//        //  let cellDict = modelViewArr[indexPath.section].friendModelObjArr[indexPath.row]
//        //print(cellDict)
//        //cell.InnerLbl.text = "hello"
//        // self.eventArr = current?.value(forKey: "data") as! NSArray
//        //  let currentEvent = eventArr[indexPath.row] as? NSObject
//        //  cell.InnerLbl.text = currentEvent?.value(forKey: "descTitle") as? String
//        return cell
//    }
   
    // MARK: New Functions
//    func getMessageData(auth_token : String){
//        //  print(currentYear,"InsideGetDataFuction",currentMonth)
//        let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/homecalendar/10/2020")
//        let parameters : Parameters = [:]
//        let header: HTTPHeaders = ["Authorization": auth_token]
//
//        AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
//            //  print(json)
//
//            if json.response != nil {
//                self.jsonData = JSON(json.data as Any)
//               // print("This is Json Data From Inner Table View",self.jsonData)
//
//                for i in 0...self.jsonData.count-1{
//                    let modelViewObj = ModelView()
//                    modelViewObj.handelData(self.jsonData[i])
//                    self.modelViewArr.append(modelViewObj)
//                }
//                self.InsideTableView.reloadData()
//             //   self.InsideTableView.reloadData()
//                   // print(self.jsonData)
//            } else{
//                print("Error is occured")
//            }
//            //let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
//        })
//    }
    
  // MARK: Work is Done Previously
//    func getDataCalanderVC(auth_token : String){
//            let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/homecalendar/10/2020")
//            let parameters : Parameters = [:]
//            let header: HTTPHeaders = ["Authorization": auth_token]
//            //     print(auth_token)
//            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
//                // print("from TAble View Cell",json)
//                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
//                do {
//                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
//                    let status = jsonObject.value(forKey: "status") as! String
//
//                    if status == Constants.OK{
//                      //  print("Status is Ok")
//                        self.dataArr = jsonObject.value(forKey: "data") as! NSArray
//
//                      //  let current = dataArr[indexPath.row] as? NSObject
//
//                     //   self.eventArr =
//
//                     //  self.InsideTableView.reloadData()
//                    }
//                } catch{
//                    print("catch")
//                }
//            })
//    }
//
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
}

extension MainTableView {
//    func setTableViewDataSourceDelegate < D : UITableViewDelegate & UITableViewDataSource>(_ dataSourceDelegate: D, forRow row : Int ) {
//        InsideTableView.dataSource = dataSourceDelegate
//        InsideTableView.delegate = dataSourceDelegate
//        InsideTableView.reloadData()
//    }
}
extension Notification.Name{
    static let reloadTableInside = Notification.Name("CurrentId")
    
}
