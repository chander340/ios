import UIKit
import NVActivityIndicatorView
import Kingfisher
import Alamofire
class ChatVC: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    
    let layer = CAGradientLayer()
    var imageProfile = String()
    var name = String()
    var language = String()
    var tId = String()
    var teacherId = String()
    var chatArr = NSMutableArray()
    //var chatArr : NSMutableArray = []
   // var chatArrString = [String]()
 
    var isOpen : Bool = false
    
    @IBOutlet weak var sentBtn: UIButton!
    @IBOutlet weak var sentImg: UIImageView!
    @IBOutlet weak var activityIndicatorSentBtn: NVActivityIndicatorView!
    @IBOutlet weak var activityIndicator: NVActivityIndicatorView!
    @IBOutlet var viewMain: UIView!
    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblLanguage: UILabel!
    @IBOutlet weak var tblVwChat: UITableView!
    @IBOutlet weak var viewTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var imgVwProfile: UIImageView!
    @IBOutlet weak var chatMessageTxtFld: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblVwChat.rowHeight = UITableView.automaticDimension
        tblVwChat.estimatedRowHeight = 600
        chatMessageTxtFld.delegate = self
        activityIndicatorSentBtn.color = .white
        activityIndicator.type = .squareSpin
        activityIndicator.color = Colors.right_gradient
        activityIndicator.type = .circleStrokeSpin
        getMessageData(auth_token : UserStoreSingleton.shared.finalAuthToken)
        imgVwProfile.layer.cornerRadius = 20
        self.lblName.text = name
        self.lblLanguage.text = language
        let url = URL(string: imageProfile)
        self.imgVwProfile.kf.setImage(with: url, placeholder: UIImage(named: "placeholder"), options: nil, progressBlock: nil)
        viewTop.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
 
        print(isOpen)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification , object: nil)
        // isOpen = true
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification , object: nil)
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("text field begin editing")
      //  self.isOpen = true
    }
    
    
    

    func getMessageData(auth_token : String){
        activityIndicator.startAnimating()
        let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/messages/conversation/" + tId)
        let parameters : Parameters = [:]
        let header: HTTPHeaders = ["Authorization": auth_token]
        AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { [self] (json) in
          print(json)
            let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
            do {
                let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                let status = jsonObject.value(forKey: "status") as! String
                if status == Constants.OK{
                    let data = jsonObject.value(forKey: "data") as! NSArray
                    self.chatArr = data as! NSMutableArray
                    self.tblVwChat.reloadData()
                    activityIndicator.stopAnimating()
                    self.scrollToBottom()
                }
            } catch{
                print("catch")
            }
        })
    }
    func sendMessage(message:String){
        self.sentBtn.isHidden = true
        self.sentImg.isHidden = true
        activityIndicatorSentBtn.startAnimating()
        let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/messages/send")
        let parameters : Parameters = ["threadId":tId, "body":message, "receiverId":teacherId, "studentId":UserStoreSingleton.shared.userId!]
        let header: HTTPHeaders = ["Authorization": UserStoreSingleton.shared.finalAuthToken!]
        AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
            print(json)
            let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
            do {
                let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                let status = jsonObject.value(forKey: "status") as! String
                if status == Constants.OK{
                    let data = jsonObject.value(forKey: "data") as! NSDictionary
                    print("early count",self.chatArr.count)
                    self.chatArr.add(data)
                    print("later count",self.chatArr.count)
                    self.tblVwChat.reloadData()
                    self.scrollToBottom()
                    self.activityIndicatorSentBtn.stopAnimating()
                    self.sentBtn.isHidden = false
                    self.sentImg.isHidden = false
                    self.chatMessageTxtFld.text = ""
                }
            } catch{
                print("catch")
            }
        })
    }
    
    @IBAction func actionBtnSendMsg(_ sender: Any) {
        if chatMessageTxtFld.text!.isEmpty == true {
            print("No messege Yet")
        }else{
            sendMessage(message: chatMessageTxtFld.text!)
        }
        
    //self.sendMessageData(auth_token : UserStoreSingleton.shared.finalAuthToken)
    }
    
    @IBAction func actionBtnBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    @objc func keyboardWillShow(notification: Notification){
    //    scrollToBottom()
        //self.isOpen = true
        if isOpen == false {
            DispatchQueue.main.async {
                if let keyboardFrame: NSValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue {
                    let keyboardRectangle = keyboardFrame.cgRectValue
                    let keyboardHeight = keyboardRectangle.height
                    self.viewTopConstraint.constant = self.viewTopConstraint.constant +  keyboardHeight
                    self.scrollToBottom()
                    print(keyboardHeight)
                    self.isOpen = true
                }
            }
            //  scrollToBottom()
        }
//        isOpen = true
//        print(isOpen)
//       print("Keyboard will show")
     }
    
    
    func tableView(_ tableView: UITableView, didBeginMultipleSelectionInteractionAt indexPath: IndexPath) {
    }
    
     @objc func keyboardWillHide(notification: Notification){
         print("Keyboard will hide")
        isOpen = false
        self.viewTopConstraint.constant = 0.0
     }
    
    //MARK:- DataSource and Delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chatArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let current = chatArr[indexPath.row] as! NSObject
        let isSender = current.value(forKey: "isSender") as! Bool
        if isSender == true{
            let cell = tblVwChat.dequeueReusableCell(withIdentifier: "SenderTVC") as! SentTVC
            cell.lblChat.text = current.value(forKey: "body") as? String
            cell.lblTime.text = current.value(forKey: "mTime") as? String
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "RecieverTVC") as! ReceivedTVC
            cell.lblChat.text = current.value(forKey: "body") as? String
            cell.lblTime.text = current.value(forKey: "mTime") as? String
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    }
    
    func scrollToBottom(){
        DispatchQueue.main.async {
            let indexPath = IndexPath(row: self.chatArr.count-1, section: 0)
            self.tblVwChat.scrollToRow(at: indexPath, at: .top, animated: false)
        }
    }
}
