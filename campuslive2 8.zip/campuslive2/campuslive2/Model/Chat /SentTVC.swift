import UIKit

class SentTVC: UITableViewCell {

    @IBOutlet weak var viewChatSender: UIView!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblChat: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        viewChatSender.layer.masksToBounds = true
        viewChatSender.layer.cornerRadius = 10
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }

}
