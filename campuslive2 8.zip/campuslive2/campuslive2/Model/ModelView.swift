import Foundation
import UIKit
import SwiftyJSON

class ModelView: NSObject{
    
    var nameStr = String()
    var friendModelObjArr = [FriendModel]()
    
    func handelData(_ dict : JSON) {
        
        nameStr = dict["data"].stringValue
       
        print("Name String is Here",nameStr)
        
            for j in 0..<dict["data"].count{
            let friendModelObj = FriendModel()
            friendModelObj.handelFriendData(dict["data"][j])
            self.friendModelObjArr.append(friendModelObj)
            
              // print(friendModelObj)
        }
        
    }
}
class FriendModel{
    var friendStr : String?
    func handelFriendData(_ dict : JSON){
        friendStr = dict["name"].stringValue
       print("Friends Arr",friendStr)
    }
}
