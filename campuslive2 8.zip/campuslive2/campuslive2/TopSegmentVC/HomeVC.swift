import UIKit
class HomeVC: UIViewController{
    
    @IBOutlet weak var containerVw: UIView!
   //@IBOutlet weak var whatsNewIcon: UILabel!
    @IBOutlet weak var module1Button: UIButton!
    @IBOutlet weak var module2Button: UIButton!
    @IBOutlet weak var module3Button: UIButton!
    @IBOutlet weak var module4Button: UIButton!
    @IBOutlet weak var module1IconRegular: UILabel!
    @IBOutlet weak var module1IconSolid: UILabel!
    @IBOutlet weak var module1Title: UILabel!
    @IBOutlet weak var module1TitleSolid: UILabel!
    @IBOutlet weak var module1NotificationIcon: UILabel!
    @IBOutlet weak var module3IconRegular: UILabel!
    @IBOutlet weak var module3IconSolid: UILabel!
    @IBOutlet weak var module3NotificationIcon: UILabel!
    @IBOutlet weak var module3Title: UILabel!
    @IBOutlet weak var module3TitleSolid: UILabel!
    @IBOutlet weak var module2Title: UILabel!
    @IBOutlet weak var module2titleSolid: UILabel!
    @IBOutlet weak var module2IconRegular: UILabel!
    @IBOutlet weak var module2IconSolid: UILabel!
    @IBOutlet weak var module2NotificationIcon: UILabel!
    @IBOutlet weak var module4Title: UILabel!
    @IBOutlet weak var module4TitleSolid: UILabel!
    @IBOutlet weak var module4IconRegular: UILabel!
    @IBOutlet weak var module4IconSolid: UILabel!
    
    var vc1:UIViewController?=nil
    var vc2:UIViewController?=nil
    var vc3:UIViewController?=nil
    var vc4:UIViewController?=nil
    @IBOutlet weak var module4NotificationIcon: UILabel!
    
    var arr = [String]()
    public var homeData = NSArray()
    override func viewWillAppear(_ animated: Bool) {
//        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.bull_horn, lbl: module1IconSolid)
//        HelperClass.setFontAwesomeIcon(iconCode: FaIcon.bull_horn, lbl: module1IconRegular)
   //     module1IconRegular.isHidden = false
//        module1Title.isHidden = true
//        module1TitleSolid.isHidden = false
//        module2titleSolid.isHidden = true
//        module3TitleSolid.isHidden = true
//        module4TitleSolid.isHidden = true
        // module1Title.isHidden = true
        // module1TitleSolid.isHidden = false
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    
        module1TitleSolid.isHidden = true
        module2titleSolid.isHidden = true
        module3TitleSolid.isHidden = true
        module4TitleSolid.isHidden = true
        
        for i in 0...self.homeData.count - 1{
           setBottomBarData(position: i)
        }
        setContainerView(position: 0)
    }
    
    @IBAction func actionShowVC(_ sender: Any) {
        setContainerView(position: 0)
    }
    
    
    @IBAction func actionShowCalenderVC(_ sender: Any) {
        setContainerView(position: 1)
    }
    
    
    @IBAction func actionShowMessagesVC(_ sender: Any) {
        setContainerView(position: 2)
    }
    
    @IBAction func actionShowNotificationVC(_ sender: Any) {
        setContainerView(position: 3)
    }
    
    override open var shouldAutorotate: Bool {
       return false
    }

    // Specify the orientation.
    override open var supportedInterfaceOrientations: UIInterfaceOrientationMask {
       return .portrait
    }
    
    private func setContainerView(position:Int){
        let current = self.homeData[position] as? NSObject
        makeFontAwesomeIconVisible(position: position)
        if current?.value(forKey: "id") as! String == ModuleIds.WHATS_NEW_MODULE_ID {
            if vc1 == nil {
                let vc = storyboard?.instantiateViewController(withIdentifier: "WhatsNewVC") as? WhatsNewVC
                self.addChild(vc!)
                vc!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc!.view)
                vc!.didMove(toParent: self)
                vc1 = vc
            }else{
                self.addChild(vc1!)
                vc1!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc1!.view)
                vc1!.didMove(toParent: self)
            }
            
            
            
        }else if current?.value(forKey: "id") as! String == ModuleIds.CALENDAR_MODULE_ID {
            if vc2 == nil {
                containerVw.subviews.forEach ({
                    $0.removeFromSuperview()
                })
                let vc = storyboard?.instantiateViewController(withIdentifier: "CalenderVC") as? CalenderVC
                self.addChild(vc!)
                vc!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc!.view)
                vc!.didMove(toParent: self)
                vc2 = vc
                
                
            }else{
                containerVw.subviews.forEach ({
                    $0.removeFromSuperview()
                })
                self.addChild(vc2!)
                vc2!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc2!.view)
                vc2!.didMove(toParent: self)
                
            }
            
            
        }else if current?.value(forKey: "id") as! String == ModuleIds.MESSAGES_MODULE_ID {
            if vc3 == nil{
                containerVw.subviews.forEach ({
                    $0.removeFromSuperview()
                })
                let vc = storyboard?.instantiateViewController(withIdentifier: "MessagesVC") as? MessagesVC
                self.addChild(vc!)
                vc!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc!.view)
                vc!.didMove(toParent: self)
                vc3 = vc
            }else{
                containerVw.subviews.forEach ({
                    $0.removeFromSuperview()
                })
                self.addChild(vc3!)
                vc3!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc3!.view)
                vc3!.didMove(toParent: self)
            }
            
            
        }else if current?.value(forKey: "id") as! String == ModuleIds.NOTIFICATIONS_MODULE_ID {
            if vc4 == nil {
                containerVw.subviews.forEach ({
                    $0.removeFromSuperview()
                })
                
                let vc = storyboard?.instantiateViewController(withIdentifier: "NotificationVC") as? NotificationVC
                self.addChild(vc!)
                vc!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc!.view)
                vc!.didMove(toParent: self)
                vc4 = vc
            }else{
                containerVw.subviews.forEach ({
                    $0.removeFromSuperview()
                })
                self.addChild(vc4!)
                vc4!.view.frame = CGRect(x: 0, y: 0, width: self.containerVw.frame.size.width, height: self.containerVw.frame.size.height);
                self.containerVw.addSubview(vc4!.view)
                vc4!.didMove(toParent: self)
            }
            
        }
    }
    
    private func setBottomBarData(position:Int){
        let current = self.homeData[position] as? NSObject
        switch position {
        case 0:
            module1Title.text = current?.value(forKey: "name") as? String
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module1IconSolid)
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module1IconRegular)
            if current?.value(forKey: "unreadCount") as! Int > 0 {
                //Show module notification icon
                let uCount = current?.value(forKey: "unreadCount") as! Int
                
                
            }else{
                //Hide Module notification icon
                
            }
        case 1:
            module2Title.text = current?.value(forKey: "name") as? String
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module2IconSolid)
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module2IconRegular)
            if current?.value(forKey: "unreadCount") as! Int > 0 {
                //Show module notification icon
                let uCount = current?.value(forKey: "unreadCount") as! Int
                
            }else{
                //Hide Module notification icon
                
            }
            
        case 2:
            module3Title.text = current?.value(forKey: "name") as? String
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module3IconSolid)
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module3IconRegular)
            if current?.value(forKey: "unreadCount") as! Int > 0 {
                //Show module notification icon
                let uCount = current?.value(forKey: "unreadCount") as! Int
                
            }else{
                //Hide Module notification icon
                
            }
            
        case 3:
            module4Title.text = current?.value(forKey: "name") as? String
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module4IconSolid)
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module4IconRegular)
            if current?.value(forKey: "unreadCount") as! Int > 0 {
                //Show module notification icon
                let uCount = current?.value(forKey: "unreadCount") as! Int
                
            }else{
                //Hide Module notification icon
                
            }
            
        default:
            //
            module1IconSolid.isHidden = false
         //   module1TitleSolid.isHidden = false
        }
    }
    
    private func makeFontAwesomeIconVisible(position:Int){
        switch position {
    
        case 0:
            module1IconSolid.isHidden = false
            module1IconRegular.isHidden = true
            module1Title.isHidden = true
            module1TitleSolid.isHidden = false

            module2IconSolid.isHidden = true
            module2IconRegular.isHidden = false
            module2Title.isHidden = false
            module2titleSolid.isHidden = true
            
            module3IconSolid.isHidden = true
            module3IconRegular.isHidden = false
            module3Title.isHidden = false
            module3TitleSolid.isHidden = true
            
            module4IconSolid.isHidden = true
            module4IconRegular.isHidden = false
            module4Title.isHidden = false
            module4TitleSolid.isHidden = true
            
        case 1:
            module1IconSolid.isHidden = true
            module1IconRegular.isHidden = false
            module1Title.isHidden = false
            module1TitleSolid.isHidden = true
    
            module2IconSolid.isHidden = false
            module2IconRegular.isHidden = true
            module2Title.isHidden = true
            module2titleSolid.isHidden = false
            
            module3IconSolid.isHidden = true
            module3IconRegular.isHidden = false
            module3Title.isHidden = false
            module3TitleSolid.isHidden = true
            
            module4IconSolid.isHidden = true
            module4IconRegular.isHidden = false
            module4Title.isHidden = false
            module4TitleSolid.isHidden = true
            
        case 2:
            module1IconSolid.isHidden = true
            module1IconRegular.isHidden = false
            module1Title.isHidden = false
            module1TitleSolid.isHidden = true
            
            module2IconSolid.isHidden = true
            module2IconRegular.isHidden = false
            module2Title.isHidden = false
            module2titleSolid.isHidden = true
            
            module3IconSolid.isHidden = false
            module3IconRegular.isHidden = true
            module3Title.isHidden = true
            module3TitleSolid.isHidden = false
            
            module4IconSolid.isHidden = true
            module4IconRegular.isHidden = false
            module4Title.isHidden = false
            module4TitleSolid.isHidden = true
            
        case 3:
            module1IconSolid.isHidden = true
            module1IconRegular.isHidden = false
            module1Title.isHidden = false
            module1TitleSolid.isHidden = true
            
            module2IconSolid.isHidden = true
            module2IconRegular.isHidden = false
            module2Title.isHidden = false
            module2titleSolid.isHidden = true
            
            module3IconSolid.isHidden = true
            module3IconRegular.isHidden = false
            module3Title.isHidden = false
            module3TitleSolid.isHidden = true
            
            module4IconSolid.isHidden = false
            module4IconRegular.isHidden = true
            module4Title.isHidden = true
            module4TitleSolid.isHidden = false
            
        default:
            //
            module1IconSolid.isHidden = false
        }
    }
}




