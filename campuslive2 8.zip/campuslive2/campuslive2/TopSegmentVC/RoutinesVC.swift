import UIKit
class RoutinesVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
