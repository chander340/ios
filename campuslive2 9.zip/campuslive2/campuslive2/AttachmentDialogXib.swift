import UIKit
protocol PopUpProtocol {
    func handleAction(action: Bool)
}
class AttachmentDialogXib: UIViewController,MyDataSendingDelegate {
    @IBOutlet weak var tblVwAttachments: UITableView!
    @IBOutlet weak var viewTitleAttachment: UIView!
    let layer = CAGradientLayer()
    let arr = ["1","2","3"]
    static let identifier = "AttachmentDialogXib"
    var delegate: PopUpProtocol?
    var dialogArr = NSArray()
    @IBOutlet weak var viewDialogBox: UIView!
    
    //MARK:- outlets for the view controller
    //    @IBOutlet weak var gotoStoreButton: UIButton!
    //    @IBOutlet weak var laterButton: UIButton!
    //
    //MARK:- lifecyle methods for the view controller
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // AttachmentDialogXib.loadArr(arr: dialogArr)
        NotificationCenter.default.addObserver(self, selector: #selector(postNotification(notification:)), name: .attachmentData, object: nil)
        viewDialogBox.layer.masksToBounds = true
        viewDialogBox.layer.cornerRadius = 10
        viewTitleAttachment.layer.masksToBounds = true
        viewTitleAttachment.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        //adding an overlay to the view to give focus to the dialog box
        view.backgroundColor = UIColor.black.withAlphaComponent(0.50)
        print("dialog Array",dialogArr)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            self.tblVwAttachments.reloadData()
            print("reload data")
        }
        // reloadData()
        //customizing the dialog box view
        //dialogBoxView.layer.cornerRadius = 6.0
        // dialogBoxView.layer.borderWidth = 1.2
        //        dialogBoxView.layer.borderColor = UIColor(named: "dialogBoxGray")?.cgColor
        
        //customizing the go to app store button
        //        gotoStoreButton.backgroundColor = UIColor(named: "primaryBackground")?.withAlphaComponent(0.85)
        //        gotoStoreButton.setTitleColor(UIColor.white, for: .normal)
        //        gotoStoreButton.layer.borderWidth = 1.2
        //        gotoStoreButton.layer.cornerRadius = 4.0
        //        gotoStoreButton.layer.borderColor = UIColor(named: "primaryBackground")?.cgColor
    }
    
    //MARK:- outlet functions for the viewController
    //    @IBAction func goToStorePressed(_ sender: Any) {
    //        self.delegate?.handleAction(action: true)
    //        self.dismiss(animated: true, completion: nil)
    //    }
    //
    //    @IBAction func laterButtonPressed(_ sender: Any) {
    //        self.dismiss(animated: true, completion: nil)
    //    }
    
    
    @objc func postNotification(notification: Notification) {
        //   guard let yourPassedObject = notification.object as? YourCustomObject else {return}
        print("Notification is working")
    }
    
    func sendDataToFirstViewController(myData: NSArray) {
        self.dialogArr = myData
        print("Dialog Array func",dialogArr)
    }
    
    @IBAction func actionBtnDismiss(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func actionBtnPreview(_ sender: Any) {
        // print("array",self.dialogArr)
        let popupViewController = UIStoryboard(name: "ChatVC", bundle: nil).instantiateViewController(withIdentifier: "Chat") as? ChatVC
        navigationController?.pushViewController(popupViewController!, animated: true)
        print("button Clicked")
    }
    
    @IBAction func actionBtnDownload(_ sender: Any) {
        
    }
    
    //    static func loadArr(arr : NSArray){
    //
    //         let vc = UIStoryboard(name: "AttachmentDialogXib", bundle: nil).instantiateViewController(withIdentifier: "AttachmentDialogXib") as? AttachmentDialogXib
    ////        print("Previous Dialog",vc?.dialogArr)
    //        vc?.dialogArr = arr
    //
    //        vc?.tblVwAttachments.reloadData()
    //        //vc!.tblVwAttachments.reloadData()
    //        //vc?.tblVwAttachments.reloadData()
    //        print("After Dialog",vc?.dialogArr as! NSArray)
    //    }
    
    
    func reloadData(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            if self.dialogArr.count != 0{
                self.tblVwAttachments.reloadData()
            }
        }
    }
    
    //MARK:- functions for the viewController
    static func showPopup(parentVC: UIViewController,arr : NSArray){
        //creating a reference for the dialogView controller
        if let popupViewController = UIStoryboard(name: "AttachmentDialogXib", bundle: nil).instantiateViewController(withIdentifier: "AttachmentDialogXib") as? AttachmentDialogXib {
            popupViewController.modalPresentationStyle = .custom
            popupViewController.modalTransitionStyle = .crossDissolve
            popupViewController.dialogArr = arr
            print("i am after dialog",popupViewController.dialogArr)
          //  popupViewController.tblVwAttachments.reloadData()
            //setting the delegate of the dialog box to the parent viewController
            popupViewController.delegate = parentVC as? PopUpProtocol 
            //            popupViewController.dialogArr =
            //presenting the pop up viewController from the parent viewController
            parentVC.present(popupViewController, animated: true)
        }
    }
}

extension AttachmentDialogXib : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dialogArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVwAttachments.dequeueReusableCell(withIdentifier:"AttachmentDialogXibTVC" ) as! AttachmentDialogXibTVC
        
        cell.lblPdf.text = "Abcd"
        return cell
    }
}
extension Notification.Name{
    static let attachmentData = Notification.Name("AttachmentData")
}

