import UIKit
class AttachmentDialogXibTVC: UITableViewCell {
    @IBOutlet weak var viewCell: UIView!
    @IBOutlet weak var viewPreview: UIView!
    @IBOutlet weak var viewDownload: UIView!
    @IBOutlet weak var previewButton: UIButton!
    @IBOutlet weak var downloadButton: UIButton!
    @IBOutlet weak var lblFileName: UILabel!
    @IBOutlet weak var lblPdf: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        viewCell.layer.masksToBounds = true
        viewCell.layer.cornerRadius = 12
        viewPreview.layer.masksToBounds = true
        viewPreview.layer.cornerRadius = 5
        viewDownload.layer.masksToBounds = true
        viewDownload.layer.cornerRadius = 5
        // Configure the view for the selected state
    }
    
}
