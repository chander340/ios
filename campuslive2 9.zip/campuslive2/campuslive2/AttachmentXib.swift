import UIKit
class AttachmentXib: UIView {
    
    
    @IBOutlet var containerView: UIView!
    let layerContent = CAGradientLayer()

    @IBOutlet weak var viewAttachmentSubView: UIView!
    @IBOutlet weak var viewAttachment: UIView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialInit()
        commitInit()
    }
    
    required init?(coder aDecoder : NSCoder) {
        super.init(coder: aDecoder)
        initialInit()
        commitInit()
    }
    
    func initialInit(){
   
    }
    
    private func commitInit(){
        Bundle.main.loadNibNamed("AttachmentXib", owner: self, options: nil)
        addSubview(containerView)
        
        viewAttachmentSubView.layer.masksToBounds = true
        viewAttachmentSubView.layer.cornerRadius = 10
      //  viewAttachmentSubView.setGradientBackground(gradientLayer: layerContent, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        containerView.frame = self.bounds
        containerView.autoresizingMask = [.flexibleHeight,.flexibleWidth]
    }
    @IBAction func actionBtnBack(_ sender: UIButton) {
        print("back button is pressed")
        self.removeFromSuperview()
    }
    
}
