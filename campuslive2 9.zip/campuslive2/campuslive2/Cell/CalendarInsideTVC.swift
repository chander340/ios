import UIKit

class CalendarInsideTVC: UITableViewCell {
    
    @IBOutlet weak var InnerLbl: UILabel!
    @IBOutlet weak var ViewGreenDot: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        ViewGreenDot.layer.masksToBounds = true
        ViewGreenDot.layer.cornerRadius = 4
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
