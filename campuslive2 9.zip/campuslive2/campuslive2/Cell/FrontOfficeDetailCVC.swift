import UIKit
class FrontOfficeDetailCVC: UICollectionViewCell {
    
    @IBOutlet weak var imgVwProfile: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblStudentId: UILabel!
    @IBOutlet weak var lblClass: UILabel!
    @IBOutlet weak var lblActive: UILabel!
    @IBOutlet weak var lblInActive: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.lblInActive.layer.masksToBounds = true
        self.lblInActive.layer.cornerRadius = 3
        
        self.lblActive.layer.masksToBounds = true
        self.lblActive.layer.cornerRadius = 3
        self.contentView.layer.masksToBounds = true
        self.layer.masksToBounds = true
        self.contentView.layer.cornerRadius = 10
        self.layer.shadowColor =  UIColor.black.cgColor
        
        
        imgVwProfile.layer.masksToBounds = true
        imgVwProfile.layer.cornerRadius = 5
       
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true

        
    
    }
}
