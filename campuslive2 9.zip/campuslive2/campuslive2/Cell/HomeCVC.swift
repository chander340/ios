//
//  HomeCVC.swift
//  campuslive2
//
//  Created by Appcrunk Mac Mini on 25/09/20.
//  Copyright © 2020 Appcrunk Mac Mini. All rights reserved.
//

import UIKit

class HomeCVC: UICollectionViewCell {
    
    @IBOutlet weak var btnTab: UIButton!
    
    
}
