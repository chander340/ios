import UIKit
class InSegmentTVC: UITableViewCell {
    
    @IBOutlet weak var lblStudentName: UILabel!

    @IBOutlet weak var lblPurpose: UILabel!
    @IBOutlet weak var lblGatePassNo: UILabel!
    
    @IBOutlet weak var lblIn: UILabel!
    @IBOutlet weak var lblInMinute: UILabel!
    
    @IBOutlet weak var lblOut: UILabel!
    @IBOutlet weak var lblOutMinute: UILabel!
    
    @IBOutlet weak var lblVisitorId: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
//
//    date = "Aug 06, 2020";
//    gatePasType = 0;
//    gatePass = IN;
//    gatePassNo = 0000022406;
//    grade = "B.SC 3rd (N.M)-A";
//    inTime = "12:57";
//    outTime = "12:58";
//    purpose = "Administer Medicine";
//    status = 0;
//    studentId = 0;
//    studentName = "Hardeep ";
//    text = "<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'><link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' integrity='sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T' crossorigin='anonymous'></head><body style='user-select:none;'><div class='container-fluid'><div class='card mt-3'><h5 class='card-header bg-success text-white'>GATE PASS-IN <span class='float-right'>#0000022406</span></h5><div class='card-body pb-0 px-0'><div class='row bg-white p-0 m-0'><div class='col-sm-8'><h5 class='card-title'><small>STUDENT</small><br />Hardeep </h5><h5 class='card-title'><small>GRADE</small><br />B.SC 3rd (N.M)-A</h5></div><div class='col-sm-4'><h5 class='card-title'><small>DATE</small><br />Aug 06, 2020</h5><h5 class='card-title'><small>TIME IN-OUT</small><br />12:57 - 12:58</h5></div></div></div><div class='card-body pt-1 m-0'><small>PURPOSE</small><p class='m-0 mb-3'>Administer Medicine</p> <div class='row bg-white'><div class='col-sm-8'><h6 class='card-title'><small>VISITOR</small><br />Ravinder Singh</h6></div><div class='col-sm-4'><h6 class='card-title'><small>QID</small><br />120201928348</h6></div></div></div><div class='card-footer text-muted text-center p-2'>1 minutes</ div ></div></div></body></html>";
//    vechileNo = "<null>";
//    visitorQID = 120201928348;
//    visitorToSchool = "Ravinder Singh";
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
