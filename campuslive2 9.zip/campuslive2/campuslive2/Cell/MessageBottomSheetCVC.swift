import UIKit
class MessageBottomSheetCVC: UICollectionViewCell {
    @IBOutlet weak var imgVwTeacher: UIImageView!
    @IBOutlet weak var lblTeacherName: UILabel!
    @IBOutlet weak var lblSubject: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = 10
             self.layer.masksToBounds = true
        
    
    }
}
