import UIKit
class MessageTVCell: UITableViewCell {
    
    @IBOutlet weak var imgVwProfile: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var languageLbl: UILabel!
  
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgVwProfile.layer.masksToBounds = true
        imgVwProfile.layer.cornerRadius = 5 
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
