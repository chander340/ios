import UIKit

class NotificationTVC: UITableViewCell {

   // MARK:- Oulets
    @IBOutlet weak var lblIcon: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubtitle: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    
   //MARK:- Override func
    override func awakeFromNib() {
        super.awakeFromNib()
        
        lblIcon.layer.masksToBounds = true
        lblIcon.layer.cornerRadius = 22.5
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
