//
//  RecieverTVC.swift
//  campuslive2
//
//  Created by Appcrunk Mac Mini on 20/10/20.
//  Copyright © 2020 Appcrunk Mac Mini. All rights reserved.
//

import UIKit

class ReceivedTVC: UITableViewCell {

    @IBOutlet weak var viewChatReciver: UIView!
    @IBOutlet weak var lblChat: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewChatReciver.layer.masksToBounds = true
        viewChatReciver.layer.cornerRadius = 10

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }

}
