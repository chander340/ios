import UIKit
class StudentCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var profileImgVw: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var studentIdLbl: UILabel!
    @IBOutlet weak var activeStatusLbl: UILabel!
    @IBOutlet weak var classLbl: UILabel!
    @IBOutlet weak var lblInactiveStatus: UILabel!
    override func awakeFromNib() {
           super.awakeFromNib()
           // Initialization code
        self.lblInactiveStatus.layer.masksToBounds = true
        self.lblInactiveStatus.layer.cornerRadius = 3
        
        self.activeStatusLbl.layer.masksToBounds = true
        self.activeStatusLbl.layer.cornerRadius = 3
        self.contentView.layer.masksToBounds = true
        self.layer.masksToBounds = true
        self.contentView.layer.cornerRadius = 10
        self.layer.shadowColor =  UIColor.black.cgColor
        
        
        profileImgVw.layer.masksToBounds = true
        profileImgVw.layer.cornerRadius = 5
       
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
       }
    
    
    
}
