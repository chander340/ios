import UIKit
import Alamofire
import MSPeekCollectionViewDelegateImplementation

class FrontOfficeDetailVC: BaseClass {
    
    @IBOutlet weak var viewSegmentNoData: UIView!
    @IBOutlet weak var tblVwIn: UITableView!
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var viewSegment: UIView!
    @IBOutlet var viewContent: UIView!
    @IBOutlet weak var viewTitle: UIView!
    @IBOutlet weak var collVwStudents: UICollectionView!
    @IBOutlet weak var tblVwEvents: UITableView!
    @IBOutlet weak var viewEvent: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblEvent: UILabel!
    //MARK:- Image View Outlets
    @IBOutlet weak var viewModule1: UIView!
    @IBOutlet weak var viewModule2: UIView!
    @IBOutlet weak var viewModule3: UIView!
    @IBOutlet weak var viewModule4: UIView!
    @IBOutlet weak var viewModule5: UIView!
    @IBOutlet weak var imgVwModule1: UIImageView!
    @IBOutlet weak var imgVwModule2: UIImageView!
    @IBOutlet weak var imgVwModule3: UIImageView!
    @IBOutlet weak var imgVwModule4: UIImageView!
    @IBOutlet weak var imgVwModule5: UIImageView!
    //MARK:- Bottom Bar Buttons
    @IBOutlet weak var module1Icon: UILabel!
    @IBOutlet weak var module2Icon: UILabel!
    @IBOutlet weak var module3Icon: UILabel!
    @IBOutlet weak var module4Icon: UILabel!
    @IBOutlet weak var module5Icon: UILabel!
    var arrAttachment = NSArray()
    var studentArr = NSArray()
    var arrData = NSArray()
    var arrItem = NSArray()
    var currentId = String()
    var currentTitle = String()
    var currentEvent = String()
    var color = String()
    var id = String()
    var arrBottomData = NSArray()
    var behaviourColl : MSCollectionViewPeekingBehavior!
    let arr = ["1","2","3","4"]
    var gateSecurityData = NSArray()
    var index = Int()
    var arrIn = NSArray()
    var arrOut = NSArray()
    
    //MARK:- Segement Controller
    @IBOutlet weak var backgroundView: UIView!
    var currentViewController: UIViewController?
    //MARK:- Life cycle
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print(" Hi view will Appear Ftb")
        
      
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
   //MARK:- View Will appear Data
        DispatchQueue.main.async {
            self.ShowArray()
        }
        viewSegment.isHidden = true
        viewNoData.isHidden = true
        UISegmentedControl.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .selected)
        self.lblTitle.text = currentTitle
        self.lblEvent.text = currentEvent
        view.backgroundColor = UIColor(hexString: color)
        viewTitle.backgroundColor = UIColor(hexString: color)
       
        for i in 0...self.arrBottomData.count - 1{
            setSchoolBottomBar(position: i)
        }
        
      //////
        self.viewEvent.layer.cornerRadius = 6
//        self.lblTitle.text = currentTitle
//        self.lblEvent.text = currentEvent
        getStudentData()
        initialInit()
        behaviourColl = MSCollectionViewPeekingBehavior()
        behaviourColl.cellPeekWidth = 4
        behaviourColl.cellSpacing = 4
        collVwStudents.configureForPeekingBehavior(behavior: behaviourColl)
        //Tag to check which view is scrolled and apply checks in scrollViewDidEndDecelerating()
        collVwStudents.tag = 27
        tblVwEvents.tag = 28
        tblVwIn.tag = 6
      //  print("Hi i am view did load")
    }
    
    //MARK:- Functions
    
    func ShowArray(){
        imgVwModule1.isHidden = true
        imgVwModule2.isHidden = true
        imgVwModule3.isHidden = true
        imgVwModule4.isHidden = true
        imgVwModule5.isHidden = true
        viewTitle.backgroundColor = UIColor(hexString: color)
        switch index {
        case 0:
            imgVwModule1.isHidden = false
            getEventData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: id)
        case 1 :
            imgVwModule2.isHidden = false
            getEventData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: id)
        case 2 :
            imgVwModule3.isHidden = false
            getEventData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: id)
            
        case 3 :
            imgVwModule4.isHidden = false
            getEventData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: id)
            
        case 4 :
            viewSegment.isHidden = false
            imgVwModule5.isHidden = false
            getGateSecurityData(auth_token : UserStoreSingleton.shared.finalAuthToken)
            
        default:
            print("I am default")
        }
    }

    @IBAction func segmentAction(_ sender: UISegmentedControl) {
        if segmentControl.selectedSegmentIndex == 0 {
            tblVwIn.reloadData()
        } else{
            tblVwIn.reloadData()
        }
    }
    
    @IBAction func actionButtonModule1(_ sender: Any) {
        viewSegment.isHidden = true
        setSchoolBottomBar(position:0)
        let current = self.arrBottomData[0] as? NSObject
        let id = current?.value(forKey:"id") as! String
        let colorB = current?.value(forKey: "color") as? String
        let unreadCount = "\(current?.value(forKey: "unreadCount") as? Int ?? 0)"
        let title = current?.value(forKey: "name") as! String
        view.backgroundColor = UIColor(hexString: colorB!)
        lblTitle.text = title
        lblEvent.text = unreadCount
        viewTitle.backgroundColor = UIColor(hexString: colorB!)
        getEventData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: id)
      
    }
    
    @IBAction func actionBtnModule2(_ sender: Any) {
        viewSegment.isHidden = true
        setSchoolBottomBar(position:1)
        let current = self.arrBottomData[1] as? NSObject
        let id = current?.value(forKey:"id") as! String
        let colorB = current?.value(forKey: "color") as? String
        let unreadCount = "\(current?.value(forKey: "unreadCount") as? Int ?? 0)"
        let title = current?.value(forKey: "name") as! String
        lblTitle.text = title
        lblEvent.text = unreadCount
        view.backgroundColor = UIColor(hexString: colorB!)
        viewTitle.backgroundColor = UIColor(hexString: colorB!)
        getEventData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: id)
        
    }
    
    @IBAction func actionBtnModule3(_ sender: Any) {
        viewSegment.isHidden = true
        setSchoolBottomBar(position:2)
        let current = self.arrBottomData[2] as? NSObject
        let unreadCount = "\(current?.value(forKey: "unreadCount") as? Int ?? 0)"
        let title = current?.value(forKey: "name") as! String
        lblTitle.text = title
        lblEvent.text = unreadCount
        let colorB = current?.value(forKey: "color") as? String
        viewTitle.backgroundColor = UIColor(hexString: colorB!)
        view.backgroundColor = UIColor(hexString: colorB!)
        let id = current?.value(forKey:"id") as! String
        getEventData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: id)
        
    }
    @IBAction func actionBtnModule4(_ sender: Any) {
        viewSegment.isHidden = true
        setSchoolBottomBar(position:3)
        let current = self.arrBottomData[3] as? NSObject
        let unreadCount = "\(current?.value(forKey: "unreadCount") as? Int ?? 0)"
        let title = current?.value(forKey: "name") as! String
        lblTitle.text = title
        lblEvent.text = unreadCount
        let colorB = current?.value(forKey: "color") as? String
        viewTitle.backgroundColor = UIColor(hexString: colorB!)
        view.backgroundColor = UIColor(hexString: colorB!)
        let id = current?.value(forKey:"id") as! String
        getEventData(auth_token: UserStoreSingleton.shared.finalAuthToken, id: id)
        
    }
    
    @IBAction func actionBtnModule5(_ sender: Any) {
        setSchoolBottomBar(position:4)
        viewSegment.isHidden = false
        let current = self.arrBottomData[4] as? NSObject
        let colorB = current?.value(forKey: "color") as? String
        let unreadCount = "\(current?.value(forKey: "unreadCount") as? Int ?? 0)"
        let title = current?.value(forKey: "name") as! String
        lblTitle.text = title
        lblEvent.text = unreadCount
        view.backgroundColor = UIColor(hexString: colorB!)
        viewTitle.backgroundColor = UIColor(hexString: colorB!)
        getGateSecurityData(auth_token : UserStoreSingleton.shared.finalAuthToken)
    }
    
    func initialInit(){
        // self.view.backgroundColor = .red
        viewEvent.layer.masksToBounds = true
        view.layer.cornerRadius = 6
    }
    
    @IBAction func actionBtnBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    // MARK:- Get Student Data
    private func setSchoolBottomBar(position:Int){
        let current = self.arrBottomData[position] as? NSObject
        let colorB = current?.value(forKey: "color") as? String
        makeFontAwesomeIconVisible(position: position)
        switch position {
        case 0:
            viewTitle.backgroundColor = UIColor(hexString: colorB!)
            imgVwModule1.tintColor = UIColor(hexString: colorB!)
            viewModule1.backgroundColor = UIColor(hexString: colorB!)
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module1Icon)
        case 1:
            viewTitle.backgroundColor = UIColor(hexString: colorB!)
            imgVwModule2.tintColor = UIColor(hexString: colorB!)
            viewModule2.backgroundColor = UIColor(hexString: colorB!)
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module2Icon)
        case 2:
            imgVwModule3.tintColor = UIColor(hexString: colorB!)
            viewModule3.backgroundColor = UIColor(hexString: colorB!)
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module3Icon)
        case 3:
            imgVwModule4.tintColor = UIColor(hexString: colorB!)
            viewModule4.backgroundColor = UIColor(hexString: colorB!)
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module4Icon)
        case 4:
            imgVwModule5.tintColor = UIColor(hexString: colorB!)
            viewModule5.backgroundColor = UIColor(hexString: colorB!)
            HelperClass.setFontAwesomeIcon(iconCode: current?.value(forKey: "iconText") as! String, lbl: module5Icon)
        default:
            print("default switch")
        }
    }
    //MARK:- Make Font Awesome Icon Visible
    private func makeFontAwesomeIconVisible(position:Int){
        switch position {
        
        case 0:
            imgVwModule1.isHidden = false
            imgVwModule2.isHidden = true
            imgVwModule3.isHidden = true
            imgVwModule4.isHidden = true
            imgVwModule5.isHidden = true
            
        case 1:
            
            imgVwModule1.isHidden = true
            imgVwModule2.isHidden = false
            imgVwModule3.isHidden = true
            imgVwModule4.isHidden = true
            imgVwModule5.isHidden = true
            
        case 2:
            
            imgVwModule1.isHidden = true
            imgVwModule2.isHidden = true
            imgVwModule3.isHidden = false
            imgVwModule4.isHidden = true
            imgVwModule5.isHidden = true
            
        case 3:
            imgVwModule1.isHidden = true
            imgVwModule2.isHidden = true
            imgVwModule3.isHidden = true
            imgVwModule4.isHidden = false
            imgVwModule5.isHidden = true
            
        case 4:
            
            imgVwModule1.isHidden = true
            imgVwModule2.isHidden = true
            imgVwModule3.isHidden = true
            imgVwModule4.isHidden = true
            imgVwModule5.isHidden = false
            
        default:
            
            imgVwModule1.isHidden = true
            imgVwModule2.isHidden = true
            imgVwModule3.isHidden = true
            imgVwModule4.isHidden = true
            imgVwModule5.isHidden = true
            
        }
    }
    
    //MARK:- Get top bar Student Data
    func getStudentData(){
        let studentData = UserStoreSingleton.shared.userChildern
        self.studentArr = studentData!
    }
    
    //MARK:- ScrollView Delegate
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        print("scrollViewDidEndDecelerating:-> ", behaviourColl.currentIndex)
        print("tag: ", scrollView.tag)
        if scrollView.tag == collVwStudents.tag {
            let indexPath = behaviourColl.currentIndex
            let currentIDD = studentArr[indexPath] as! NSObject
            let iddd = currentIDD.value(forKey:"id") as! String
            self.currentId = iddd
            getTeachersId(sId: iddd)
            setGateSecurityData()
            
        } else {
            print("tblViewTag is working fine in scroll view didEndDeclarating")
        }
    }
    // MARK:- Hit Api Event
    func getEventData(auth_token : String, id : String){
        Proxy.shared.showActivityIndicator()
        let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/school/" + id)
        let parameters : Parameters = [:]
        let header: HTTPHeaders = ["Authorization": auth_token]
        //  print(auth_token)
        AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { [self] (json) in
            //  print(json)
            if json.data != nil {
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonObject.value(forKey: "status") as! String
                    
                    if status == Constants.OK{
                        let data = jsonObject.value(forKey: "data") as! NSArray
                        print("Hi i am data")
                        self.arrData = data
                        getTeachersId(sId : self.currentId)
                        self.tblVwEvents.reloadData()
                        Proxy.shared.hideActivityIndicator()
                    }
                } catch{
                    print("catch")
                }
            }else{
              //  self.s
                debugPrint(Error.self)
            }
        })
    }
    
    // MARK:- Hit Gate Api
    func getGateSecurityData(auth_token : String){
        Proxy.shared.showActivityIndicator()
        let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/gatesecuritycontent")
        let parameters : Parameters = [:]
        let header: HTTPHeaders = ["Authorization": auth_token]
        //  print(auth_token)
        AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { [self] (json) in
            //              print(json)
            if json.data != nil {
                
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
                do {
                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonObject.value(forKey: "status") as! String
                    if status == Constants.OK{
                        let data = jsonObject.value(forKey: "data") as! NSArray
                        print("Hi i am data")
                        self.gateSecurityData = data
                        setGateSecurityData()
                    }
                } catch{
                    print("catch")
                }
            }else{
                
                debugPrint(Error.self)
                
            }
            Proxy.shared.hideActivityIndicator()
        })
    }
    
    //MARK:- Loop for Get Security Data
    func setGateSecurityData(){
        if self.gateSecurityData.count == 0 {
            print("No data")
        }else{
            
            for i in 0...self.gateSecurityData.count - 1 {
                let current = self.gateSecurityData[i] as! NSObject
                if self.currentId == current.value(forKey: "stId") as! String {
                    
                    let inArr = current.value(forKey: "In") as! NSArray
                    let outArr = current.value(forKey: "Out") as! NSArray
                    self.arrIn = inArr
                    self.arrOut = outArr
                    
                    // print("Gate Security Out Data",arrOut)
                    // print("Gate Security Out Data",arrOut)
                    
                    if arrIn.count == 0 || arrOut.count == 0 {
                        tblVwIn.isHidden = true
                        print("No data found")
                    } else {
                        tblVwIn.isHidden = false
                        tblVwIn.reloadData()
                    }
                }
            }
        }
    }
    
    //MARK:- For loop On ItemArr
    func getTeachersId(sId : String){
        if self.arrData.count == 0 {
            print("No data")
        }else{
            for i in 0...self.arrData.count-1 {
                let idDict = self.arrData[i] as! NSObject
                let id = idDict.value(forKey: "stId") as! String
                if id == sId {
                    let itemArr = idDict.value(forKey: "items") as! NSArray
                    // print("itemArr",itemArr)
                    self.arrItem = itemArr
                    
                    if self.arrItem.count > 0 {
                        viewNoData.isHidden = true
                        print("Hi i haveeeeee data data data data datad data data")
                        //There is data for the current student
                        self.tblVwEvents.isHidden = false
                        self.tblVwEvents.reloadData()
                        return
                    }else{
                        viewNoData.isHidden = false
                        self.tblVwEvents.isHidden = true
                    }
                    
                }
            }
        }
    }
    
}

//MARK:- TableViewDelegate & DataSource
extension FrontOfficeDetailVC : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView.tag == 6 {
            if segmentControl.selectedSegmentIndex == 0  {
                print("selected segment index == 0")
                return arrIn.count
            }else if segmentControl.selectedSegmentIndex == 1{
                print("selected segment index == 1")
                return arrOut.count
            }
        }
        return arrItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVwEvents.dequeueReusableCell(withIdentifier:"FrontOfficeDetailTVC" ) as! FrontOfficeDetailTVC
        if tableView.tag == 6 {
            let cell = tblVwIn.dequeueReusableCell(withIdentifier: "InSegmentTVC") as! InSegmentTVC
            let current = arrIn[indexPath.row] as? NSObject
            print("i am current Data",current)
            
            
            cell.lblStudentName.text = current?.value(forKey: "visitorToSchool") as? String
            cell.lblPurpose.text = current?.value(forKey: "purpose") as? String
            cell.lblGatePassNo.text = current?.value(forKey: "gatePassNo") as? String
            cell.lblVisitorId.text = "(\(current?.value(forKey: "visitorQID") as? String ?? ""))"
            
            return cell
        }
        cell.viewAttachment.isHidden = true
        let current = arrItem[indexPath.row] as? NSObject
        print("i am current Data",current)
        let hasAttachment = current?.value(forKey: "hasAttachment") as! Bool
        cell.lblCount.text = "\(current?.value(forKey: "attachmentCount") as? Int ?? 0)"
        if hasAttachment == true {
            cell.viewAttachment.isHidden = false
        }
        cell.lblDate.text = current?.value(forKey: "day") as? String ?? ""
        cell.lblTitle.text = current?.value(forKey: "title") as? String ?? ""
        cell.lblMonth.text = current?.value(forKey: "MMM") as? String ?? ""
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 84
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "WebViewVC") as? WebViewVC
        if tableView.tag == tblVwIn.tag {
            let current = arrIn[indexPath.row] as! NSObject
            vc?.htmlContent = current.value(forKey: "text") as! String
            vc?.screenTitle = "Gate Security"
            navigationController?.pushViewController(vc!, animated: true)
        }else{
            let currenObj = arrItem[indexPath.row] as! NSObject
            vc?.arrAttachment = currenObj.value(forKey: "attachments") as! NSArray
           // print("Current Object",arrAttachment)
            vc?.htmlContent = currenObj.value(forKey: "text") as! String
            vc?.screenTitle = lblTitle.text!
            vc?.htmlContent = currenObj.value(forKey: "text") as! String
            navigationController?.pushViewController(vc!, animated: true)
        }
    }
}
//MARK:- CollectionView Delegate and DataSource
extension FrontOfficeDetailVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        behaviourColl.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return studentArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collVwStudents.dequeueReusableCell(withReuseIdentifier: "FrontOfficeDetailCVC" , for: indexPath) as! FrontOfficeDetailCVC
        cell.lblActive.isHidden = true
        cell.lblInActive.isHidden = true
        let current = self.studentArr[indexPath.row] as! NSObject
        if indexPath.row == 0 {
            // Making current index is 0 because we have to get first index value
            let currentIDD = studentArr[0] as! NSObject    // Array
            let iddd = currentIDD.value(forKey:"id") as! String // Current ID
            self.currentId = iddd
        }
        let sts = current.value(forKey: "sts") as! Int
        let gender = current.value(forKey: "gen") as? String
        if gender == "M" {
            cell.backgroundColor = UIColor(red: 0, green: 95, blue: 126, alpha: 0.8)
        }
        if sts == 1 {
            cell.lblActive.isHidden = false
            cell.lblInActive.isHidden = true
        }else{
            cell.lblActive.isHidden = true
            cell.lblInActive.isHidden = false
        }
        
        cell.lblName.text = current.value(forKey: "fullName") as? String
        cell.lblClass.text = current.value(forKey: "nowIn") as? String
        cell.lblStudentId.text = current.value(forKey: "number") as? String
        //  cell.activeStatusLbl.text = current.value(forKey: "sts") as? String
        let imageUrl = current.value(forKey: "img") as? String
        let url = URL(string: imageUrl ?? "")
        cell.imgVwProfile.kf.setImage(with: url, placeholder: UIImage(named: "placeholder"), options: nil, progressBlock: nil)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = view.frame.size.width - 15
        return CGSize(width: width , height: 89)
    }
}
