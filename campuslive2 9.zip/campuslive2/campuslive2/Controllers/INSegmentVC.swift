import UIKit
class INSegmentVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tblVwIN: UITableView!
    
     var arrIn = NSArray()
     var arrOut = NSArray()
    
    let arr = ["1","2","3"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVwIN.dequeueReusableCell(withIdentifier: "InSegmentTVC") as! InSegmentTVC
        return cell
    }
    
    
}
