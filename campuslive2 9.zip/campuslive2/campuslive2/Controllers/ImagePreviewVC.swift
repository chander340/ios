import UIKit
import Kingfisher
import WebKit
class ImagePreviewVC: UIViewController {
    
    @IBOutlet weak var imgVw: UIImageView!
    @IBOutlet weak var webVw: WKWebView!
    var imgStr = String()
    var webViewStr = String()
    let xyz = ".PDF"
    let abc = ".JPG"
    //static let abc = ".JPG"
    override func viewDidLoad() {
        super.viewDidLoad()
        print(xyz)
        
        if imgStr.count == 0 {
            imgVw.isHidden = true
            let urlStr : URL! = URL(string: webViewStr)
            webVw.load(URLRequest(url: urlStr))
            print("Hi my count is exacty zero")
        }else if webViewStr.count == 0 {
            webVw.isHidden = true
            print("WebView count is exactly equal to zero")
            let url = URL(string: imgStr)
            imgVw.kf.setImage(with: url, placeholder: UIImage(named: "placeholder"), options: nil,  progressBlock: nil)
        }
    }
    @IBAction func actionBtnBacK(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        
    }
}
