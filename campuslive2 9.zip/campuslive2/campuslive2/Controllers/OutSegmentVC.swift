import UIKit
import Alamofire
class OutSegmentVC: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        //getEventData(auth_token: UserStoreSingleton.shared.finalAuthToken)
    }
    
//    func getEventData(auth_token : String){
//        Proxy.shared.showActivityIndicator()
//        let url = URL(string: "https://campusdemo.stellarshell.com/api/mobile2/school)
//        let parameters : Parameters = [:]
//        let header: HTTPHeaders = ["Authorization": auth_token]
//        //  print(auth_token)
//        AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { [self] (json) in
//            //  print(json)
////            if json.data != nil {
//////                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
//////                do {
//////                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
//////                    let status = jsonObject.value(forKey: "status") as! String
//////
//////                    if status == Constants.OK{
//////                        let data = jsonObject.value(forKey: "data") as! NSArray
//////                        print("Hi i am data")
//////                        self.arrData = data
//////                        getTeachersId(sId : self.currentId)
//////                        self.tblVwEvents.reloadData()
//////                        Proxy.shared.hideActivityIndicator()
//////                    }
//////                } catch{
//////                    print("catch")
//////                }
////            }else{
////              //  self.s
////                debugPrint(Error.self)
////            }
//        })
//    }
//
    
    
    
    
    
    
    
}
