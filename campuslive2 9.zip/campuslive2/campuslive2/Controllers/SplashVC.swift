import UIKit
import NVActivityIndicatorView
import Alamofire
class SplashVC: BaseClass {
    //MARK:- Variables and constants
    
    let layer = CAGradientLayer()
    
    //MARK:- Oulets
    @IBOutlet weak var activityIndicatorView: NVActivityIndicatorView!
    @IBOutlet weak var logoImgVw: UIImageView!
  
    //MARK:- View Life Cycle
    override func viewWillAppear(_ animated: Bool) {
        print("View will appear")
        view.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
    }
//MARK:- View Life Cycle 
    override func viewDidLoad() {
        super.viewDidLoad()
        print("ON view did load run")
        view.setGradientBackground(gradientLayer: self.layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        activityIndicatorView.type = .circleStrokeSpin
        activityIndicatorView.startAnimating()
        
        if #available(iOS 13.0, *) {
            startAnimation()
        } else {
            startAnimationIos12()
            print("ABCD")
        }
    }

  //MARK:- Override Functions
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        // loginBtn.frame = view.layer.bounds
        layer.frame = view.layer.bounds
    }
    
    //MARK:- Functions
    func welcomeParent(auth_token : String){
            print("API IS HITTING")
        if isConnectedToNetwork() {
            showLoader()
            
            
            // Internet available
            let url = URL(string:  "https://campusdemo.stellarshell.com/api/mobile2/welcome/parent")
            let parameters:Parameters = [:]
            let header: HTTPHeaders = ["Authorization" : auth_token]
            AF.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: header).responseJSON(completionHandler: { (json) in
               //   print(json)
                
        if json.data != nil {
                let data = try! JSONSerialization.data(withJSONObject:json.value as! NSDictionary)
               do {
                    let jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    let status = jsonResult.object(forKey: Constants.STATUS) as! NSString
                    if status as String == Constants.OK {
                        //Welcome parent data retrive successfully
                        let data = jsonResult.object(forKey: Constants.DATA) as! NSObject
                        let jsonData = try? JSONSerialization.data(withJSONObject: data, options: [])
                        UserStoreSingleton.shared.welcomeData = String(data: jsonData!, encoding: .utf8)
                        // print(UserStoreSingleton.shared.welcomeData!)
                    }
                }catch{
                    print(error)
                }
                
                }
            })
        } else {
            // No Internet Connection
            showTopAlert(message: Constants.no_internet)
        }
    }
    
  //MARK:- Hand Logo Animation for IOS 12
    func startAnimationIos12() {
        logoImgVw.transform = CGAffineTransform(scaleX: 0.0, y: 0.0)
        UIView.animateKeyframes(withDuration: 1.5, delay: 0, options: [], animations: {
            self.logoImgVw.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }) { (finished) in
            DispatchQueue.main.asyncAfter(deadline: .now()+0.5, execute: {
                if UserDefaults.standard.bool(forKey: "ISUSERLOGGEDIN") == true{
                    let paraObj : NSMutableDictionary = NSMutableDictionary()
                    paraObj.setValue("", forKey: "u")
                    paraObj.setValue( "", forKey: "p")
                    paraObj.setValue(UserStoreSingleton.shared.authToken, forKey: "t")
                    
                    let paraObj2 : NSMutableDictionary = NSMutableDictionary()
                    paraObj2.setValue(UserStoreSingleton.shared.userRole, forKey: "r")
                    paraObj2.setValue(UserStoreSingleton.shared.userId, forKey: "i")
                    // creating string form json object
                    let jsonData = try? JSONSerialization.data(withJSONObject: paraObj, options: [])
                    let jsonString = String(data: jsonData!, encoding: .utf8)
                    let jsonData2 = try? JSONSerialization.data(withJSONObject: paraObj2, options: [])
                    let jsonString2 = String(data: jsonData2!, encoding: .utf8)
                    self.welcomeParent(auth_token: Constants.BEARER + (jsonString?.toBase64())! + "." + (jsonString2?.toBase64())!)
                    
                    let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                    let nextViewController = storyBoard.instantiateViewController(withIdentifier: "CollVwVC") as! CollVwVC
                    self.navigationController?.pushViewController(nextViewController, animated: true)
                } else if UserDefaults.standard.bool(forKey: "ISUSERLOGGEDIN") == false  {
                    let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                    let nextViewController = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                    self.navigationController?.pushViewController(nextViewController, animated: true)
                    print("user defaults did not enter")
                }
            })
        }
    }
   //MARK:- Hand Logo Animation for IOS 13 or later
    //   @available(iOS 13.0, *)
    @available(iOS 13.0, *)
    func startAnimation(){
        logoImgVw.transform = CGAffineTransform(scaleX: 0.0, y: 0.0)
        UIView.animateKeyframes(withDuration: 1.5, delay: 0, options: [], animations: {
            self.logoImgVw.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }) { (finished) in
            
            DispatchQueue.main.asyncAfter(deadline: .now()+0.5, execute: {
                if UserDefaults.standard.bool(forKey: "ISUSERLOGGEDIN") == true{
                    let paraObj : NSMutableDictionary = NSMutableDictionary()
                  
                    paraObj.setValue("", forKey: "u")
                    paraObj.setValue( "", forKey: "p")
                    paraObj.setValue(UserStoreSingleton.shared.authToken, forKey: "t")
                    
                    let paraObj2 : NSMutableDictionary = NSMutableDictionary()
                    paraObj2.setValue(UserStoreSingleton.shared.userRole, forKey: "r")
                    paraObj2.setValue(UserStoreSingleton.shared.userId, forKey: "i")
                    // creating string form json object
                    let jsonData = try? JSONSerialization.data(withJSONObject: paraObj, options: [])
                    let jsonString = String(data: jsonData!, encoding: .utf8)
                    let jsonData2 = try? JSONSerialization.data(withJSONObject: paraObj2, options: [])
                    let jsonString2 = String(data: jsonData2!, encoding: .utf8)
                    
                    self.welcomeParent(auth_token: Constants.BEARER + (jsonString?.toBase64())! + "." + (jsonString2?.toBase64())!)
                    
                    let movetoNextVCObj = self.storyboard?.instantiateViewController(identifier: "CollVwVC") as! CollVwVC
                    self.navigationController?.pushViewController(movetoNextVCObj, animated: true)
                } else if UserDefaults.standard.bool(forKey: "ISUSERLOGGEDIN") == false{
                    let movetoNextVCObj = self.storyboard?.instantiateViewController(identifier: "LoginVC") as! LoginVC
                    self.navigationController?.pushViewController(movetoNextVCObj, animated: true)
                    print("user defaults did not enter")
                }
            })
        }
    }
}

