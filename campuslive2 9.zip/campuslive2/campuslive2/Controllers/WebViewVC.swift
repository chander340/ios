import UIKit
import WebKit

protocol MyDataSendingDelegate {
    func sendDataToFirstViewController(myData: NSArray)
}

class WebViewVC: UIViewController,PopUpProtocol {
    
    var delegateMyData : MyDataSendingDelegate? 
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var titleLbl: UILabel!
     
    var myRecomndView : AttachmentXib?
    var htmlContent = String()
    var screenTitle = String()
    var arrAttachment = NSArray()
    let layer = CAGradientLayer()
    @IBOutlet weak var webViewShow: WKWebView!
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        print("Array Attachment",arrAttachment)
        view.setGradientBackground(gradientLayer: self.layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        self.titleLbl.text = self.screenTitle
        self.webViewShow.loadHTMLString(htmlContent, baseURL: nil)
       
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        // loginBtn.frame = view.layer.bounds
        layer.frame = view.layer.bounds
    }
    @IBAction func actionBtnBack(_ sender: Any) {
     navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionBtnShowAttachment(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "AttachmentXibb") as? AttachmentXibb
        vc?.modalPresentationStyle = .custom
        vc?.modalTransitionStyle = .crossDissolve
        vc?.arrAttachment = arrAttachment
        present(vc!, animated: true, completion: nil)
     }
    
    func loadRecomdView(){
        myRecomndView = AttachmentXib()
        myRecomndView?.frame = view.frame
        //  myRecomndView?.dataTextview.text = text
        //  myRecomndView?.calculateViewHeight()
        view.addSubview(myRecomndView!)
    }
    func handleAction(action: Bool) {
        print("Handle Action is working fine")
    }
    
    
}

