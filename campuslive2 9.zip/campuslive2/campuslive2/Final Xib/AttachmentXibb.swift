import UIKit
class AttachmentXibb: BaseClass,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var viewTitleAttachment: UIView!
    @IBOutlet weak var tblVw: UITableView!
    @IBOutlet weak var viewDialogBox: UIView!
    let arr = ["1","2","3"]
    let layer = CAGradientLayer()
    var arrAttachment = NSArray()
    var pdfUrl : URL?
    override func viewDidLoad() {
        super.viewDidLoad()
        print("hi i am array attachment",self.arrAttachment)
        viewDialogBox.layer.masksToBounds = true
        viewDialogBox.layer.cornerRadius = 10
        viewTitleAttachment.layer.masksToBounds = true
        viewTitleAttachment.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
    }
    
    
    @IBAction func actionBtnHide(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAttachment.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVw.dequeueReusableCell(withIdentifier:"AttachmentDialogXibTVC" ) as! AttachmentDialogXibTVC
        let current = arrAttachment[indexPath.row] as! NSObject
       // let fileType = current.value(forKey: "fileType") as! String
        cell.lblFileName.text = current.value(forKey: "fileName") as? String
        cell.previewButton.tag = indexPath.row
        cell.previewButton.addTarget(self, action: #selector(buttonTappedPreview), for: .touchUpInside)
        cell.downloadButton.addTarget(self, action: #selector(buttonTappedDownload) , for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        if let url = URL(string: "https://i.stack.imgur.com/xnZXF.jpg"),
//           let data = try? Data(contentsOf: url),
//           let image = UIImage(data: data) {
//            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
//        }
    }
    
    @objc func buttonTappedDownload(sender : UIButton){
       // Proxy.shared.showActivityIndicator()
        print("Its Sender tag",sender.tag)
        let currenObj = arrAttachment[sender.tag] as! NSObject
        print("Hi i am sender tag ",sender.tag)
        let fileType = currenObj.value(forKey: "fileType") as! String
        let filePath = currenObj.value(forKey: "filePath") as! String
        let fileName = currenObj.value(forKey: "fileName") as! String
        if fileType == ".PDF" {
            savePdf(urlString: filePath, fileName: fileName)
        //    Proxy.shared.hideActivityIndicator()
        }else{
            if let url = URL(string: filePath),
               let data = try? Data(contentsOf: url),
               let image = UIImage(data: data) {
                UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
            }
        }
    }
    
    func savePdf(urlString:String, fileName:String) {
           DispatchQueue.main.async {
            
               let url = URL(string: urlString)
               let pdfData = try? Data.init(contentsOf: url!)
               let resourceDocPath = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last! as URL
               let pdfNameFromUrl = "CampusLive-\(fileName).pdf"
               let actualPath = resourceDocPath.appendingPathComponent(pdfNameFromUrl)
               do {
                   try pdfData?.write(to: actualPath, options: .atomic)
                   print(actualPath)
                   print("pdf successfully saved!")
               // self.showTopAlert(message: "Pdf is sucessfully Downloaded")
            
                self.showAlert(message: "Pdf is downloaded in Files under campusLive folder", title: "Downloaded")
               } catch {
             
                   print("Pdf could not be saved")
               }
           }
       }

    @objc func buttonTappedPreview(sender : UIButton){
        print("button tapped")
        print("Its Sender tag",sender.tag)
        let vc = storyboard?.instantiateViewController(withIdentifier: "ImagePreviewVC") as? ImagePreviewVC
        let currenObj = arrAttachment[sender.tag] as! NSObject
        print("Hi i am sender tag ",sender.tag)
        let fileType = currenObj.value(forKey: "fileType") as! String
        vc?.modalTransitionStyle = .coverVertical
        vc?.modalPresentationStyle = .fullScreen
        
        if fileType == ".PDF" {
            print("Hi my file type is pdf")
            vc?.webViewStr = currenObj.value(forKey: "filePath") as! String
            present(vc!, animated: true, completion: nil)
            
        }else{
            vc?.imgStr = currenObj.value(forKey: "filePath") as! String
            present(vc!, animated: true, completion: nil)
        }
    }
}

//extension AttachmentXibb : URLSessionDownloadDelegate {
//    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
//      //  print("File Downloaded Location- ",  location)
//
//              guard let url = downloadTask.originalRequest?.url else {
//                  return
//              }
//              let docsPath = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
//              let destinationPath = docsPath.appendingPathComponent(url.lastPathComponent)
//
//              try? FileManager.default.removeItem(at: destinationPath)
//
//              do{
//                  try FileManager.default.copyItem(at: location, to: destinationPath)
//                  self.pdfUrl = destinationPath
//                  print("File Downloaded Location- ",  self.pdfUrl ?? "NOT")
//              }catch let error {
//                  print("Copy Error: \(error.localizedDescription)")
//              }
//    }
//}


//            let fileURL = URL(string: filePath)
//            let sessionConfig = URLSessionConfiguration.default
//            let session = URLSession(configuration: sessionConfig)
//            let request = URLRequest(url:fileURL!)
//            let task = session.downloadTask(with: request) { (tempLocalUrl, response, error) in
//                if let tempLocalUrl = tempLocalUrl, error == nil {
//                    // Success
//                    if let statusCode = (response as? HTTPURLResponse)?.statusCode {
//                        print("Successfully downloaded. Status code: \(statusCode)")
//                    }
//                    do {
//                        try FileManager.default.copyItem(at: tempLocalUrl, to: destinationFileUrl)
//                        do {
//                            //Show UIActivityViewController to save the downloaded file
//                            let contents  = try FileManager.default.contentsOfDirectory(at: documentsUrl, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
//                            for indexx in 0..<contents.count {
//                                if contents[indexx].lastPathComponent == destinationFileUrl.lastPathComponent {
//                                    let activityViewController = UIActivityViewController(activityItems: [contents[indexx]], applicationActivities: nil)
//                                    self.present(activityViewController, animated: true, completion: nil)
//                                }
//                            }
//                        }
//                        catch (let err) {
//                            print("error: \(err)")
//                        }
//                    } catch (let writeError) {
//                        print("Error creating a file \(destinationFileUrl) : \(writeError)")
//                    }
//                } else {
//                    print("Error took place while downloading a file. Error description: \(error?.localizedDescription ?? "")")
//                }
//            }
//            task.resume()
