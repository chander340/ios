import Foundation
import UIKit
extension UISegmentedControl{
    func removeBorder(){
        let backgroundImage = UIImage.getColoredRectImageWith(color: UIColor.white.cgColor, andSize: self.bounds.size)
        self.setBackgroundImage(backgroundImage, for: .normal, barMetrics: .default)
        self.setBackgroundImage(backgroundImage, for: .selected, barMetrics: .default)
        self.setBackgroundImage(backgroundImage, for: .highlighted, barMetrics: .default)

        let deviderImage = UIImage.getColoredRectImageWith(color: UIColor.white.cgColor, andSize: CGSize(width: 1.0, height: self.bounds.size.height))
        self.setDividerImage(deviderImage, forLeftSegmentState: .selected, rightSegmentState: .normal, barMetrics: .default)
        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for: .normal)
        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor(red: 67/255, green: 129/255, blue: 244/255, alpha: 1.0)], for: .selected)
    }

    func addUnderlineForSelectedSegment(){
        removeBorder()
        let underlineWidth: CGFloat = self.bounds.size.width / CGFloat(self.numberOfSegments)
        let underlineHeight: CGFloat = 2.0
        let underlineXPosition = CGFloat(selectedSegmentIndex * Int(underlineWidth)) + 50
        let underLineYPosition = self.bounds.size.height - 3.5
        let underlineFrame = CGRect(x: underlineXPosition   , y: underLineYPosition , width: underlineWidth, height: underlineHeight)
        let underline = UIView(frame: underlineFrame)
        underline.backgroundColor = UIColor.red
        underline.tag = 1
        self.addSubview(underline)
        
//        let underlineWidth: CGFloat = self.bounds.size.width / CGFloat(self.numberOfSegments)
//        let underlineHeight: CGFloat = 2.0
//        let underlineXPosition = CGFloat(selectedSegmentIndex * Int(underlineWidth))
//        let underLineYPosition = self.bounds.size.height - 1.0
//        let underlineFrame = CGRect(x: underlineXPosition, y: underLineYPosition, width: underlineWidth, height: underlineHeight)
//        let underline = UIView(frame: underlineFrame)
//        underline.backgroundColor = UIColor.blue
//        underline.tag = 1
//        self.addSubview(underline)
    }

    func changeUnderlinePosition(){
        guard let underline = self.viewWithTag(1) else {return}
        let underlineFinalXPosition = (self.bounds.width / CGFloat(self.numberOfSegments)) * CGFloat(selectedSegmentIndex)
        UIView.animate(withDuration: 0.1, animations: {
            underline.frame.origin.x = underlineFinalXPosition
        })
    }
}

extension UIImage{
    class func getColoredRectImageWith(color: CGColor, andSize size: CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        let graphicsContext = UIGraphicsGetCurrentContext()
        graphicsContext?.setFillColor(color)
        let rectangle = CGRect(x: 0.0, y: 0.0, width: size.width, height: size.height)
        graphicsContext?.fill(rectangle)
        let rectangleImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return rectangleImage!
    }
}

//class CustomSegmentedControl: UISegmentedControl {
//
//    func initUI(){
//        changeUnderlinePosition()
//        addUnderlineForSelectedSegment()
//    }
//
//    func addUnderlineForSelectedSegment(){
//        removeBorders()
//        let underlineWidth: CGFloat = self.bounds.size.width / CGFloat(self.numberOfSegments) + 10
//        let underlineHeight: CGFloat = 5.0
//        let underlineXPosition = CGFloat(selectedSegmentIndex * Int(underlineWidth)) - 10
//        let underLineYPosition = self.bounds.size.height - 3.5
//        let underlineFrame = CGRect(x: underlineXPosition , y: underLineYPosition , width: underlineWidth, height: underlineHeight)
//        let underline = UIView(frame: underlineFrame)
//        underline.backgroundColor = UIColor(hexFromString: "FFCC00")
//        underline.tag = 1
//        self.addSubview(underline)
//    }
//
//    func changeUnderlinePosition(){
//        guard let underline = self.viewWithTag(1) else {return}
//        let underlineFinalXPosition = (self.bounds.width / CGFloat(self.numberOfSegments)) * CGFloat(selectedSegmentIndex)
//        UIView.animate(withDuration: 0.1, animations: {
//            underline.frame.origin.x = underlineFinalXPosition
//        })
//    }
//
//
//    func removeBorders() {
//        setBackgroundImage(imageWithColor(color: .clear), for: .normal, barMetrics: .default)
//        setBackgroundImage(imageWithColor(color: .clear), for: .selected, barMetrics: .default)
//        setDividerImage(imageWithColor(color: UIColor.clear), forLeftSegmentState: .normal, rightSegmentState: .normal, barMetrics: .default)
//        let Bold_font = UIFont.systemFontSize(12)
//        let Normal_font = UIFont(name: "Montserrat-Bold", size: 14)


//        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white,NSAttributedString.Key.font: UIFont(name:"system" , size: 13) ?? ""], for: .normal)
//        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor(hexFromString: "FDC11C"),NSAttributedString.Key.font: UIFont(name: "system", size: 13) ?? ""], for: .selected)
 //   }
//
    // create a 1x1 image with this color
//    private func imageWithColor(color: UIColor) -> UIImage {
//        let rect = CGRect(x: 0.0, y: 0.0, width:  1.0, height: 1.0)
//        UIGraphicsBeginImageContext(rect.size)
//        let context = UIGraphicsGetCurrentContext()
//        context!.setFillColor(color.cgColor);
//        context!.fill(rect);
//        let image = UIGraphicsGetImageFromCurrentImageContext();
//        UIGraphicsEndImageContext();
//        return image!
//    }
//
//
//}
//
//extension UIImage{
//
//    class func getColoredRectImageWith(color: CGColor, andSize size: CGSize) -> UIImage{
//        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
//        let graphicsContext = UIGraphicsGetCurrentContext()
//        graphicsContext?.setFillColor(color)
//        let rectangle = CGRect(x: 0.0, y: 0.0, width: 0, height: 0)
//        graphicsContext?.fill(rectangle)
//        let rectangleImage = UIGraphicsGetImageFromCurrentImageContext()
//        UIGraphicsEndImageContext()
//
//        return rectangleImage!
//    }
//}
//
//extension UIColor {
//    convenience init(hexFromString:String, alpha:CGFloat = 1.0) {
//        var cString:String = hexFromString.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
//        var rgbValue:UInt32 = 10066329 //color #999999 if string has wrong format
//
//        if (cString.hasPrefix("#")) {
//            cString.remove(at: cString.startIndex)
//        }
//
//        if ((cString.count) == 6) {
//            Scanner(string: cString).scanHexInt32(&rgbValue)
//        }
//
//        self.init(
//            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
//            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
//            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
//            alpha: alpha
//        )
//    }
//}

