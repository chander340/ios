import UIKit
import NVActivityIndicatorView
import BRYXBanner

//let KAppDelegate = UIApplication.shared.delegate as! AppDelegate

class Proxy {
    static var shared: Proxy {
        return Proxy()
    }
    fileprivate init(){}
    
    //MARK:- Common Methods
    func accessTokenNil() -> String {
        if let accessToken = UserDefaults.standard.object(forKey: "access_token") as? String {
            return accessToken
        } else {
            return ""
        }
    }
    
    
    //MARK:- Get Device Token
    func deviceToken() -> String {
        var deviceTokken =  ""
        if UserDefaults.standard.object(forKey: "device_token") == nil {
            deviceTokken = "00000000055"
            
        } else {
            deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
        }
        return deviceTokken
    }
    //    func hitlogoutApi(_ completion:@escaping() -> Void){
    //        WebServiceProxy.shared.getData(urlStr: Apis.logout, showIndicator: true) { (ApiResponse) in
    //            if ApiResponse!.success {
    //                UserDefaults.standard.set("", forKey: "access_token")
    //                UserDefaults.standard.synchronize()
    //                completion()
    //            } else {
    //                Proxy.shared.displayStatusAlert(message: "", state: .error)
    //            }
    //        }
    //    }
    //MARK:- Latitude Method
    func getLatitude() -> String {
        if UserDefaults.standard.object(forKey: "lat") != nil {
            let currentLat =  UserDefaults.standard.object(forKey: "lat") as! String
            return currentLat
        }
        return ""
    }
    
    //MARK:- Longitude Method
    func getLongitude() -> String {
        if UserDefaults.standard.object(forKey: "long") != nil {
            let currentLong =  UserDefaults.standard.object(forKey: "long") as! String
            return currentLong
        }
        return ""
    }
    
    //MARK:- Display Toast
    func displayStatusAlert(title: String, message:String, image: String = "Icon", state: DropState) {
        
        var bgColor = UIColor()
        switch state {
        case .success :
            bgColor = UIColor.green
        case .error :
            bgColor = UIColor.red
        case .warning:
            bgColor = UIColor.yellow
        default:
            bgColor = UIColor.blue
        }
        let banner = Banner(title: title, subtitle: message, image: UIImage(named: image),
                            backgroundColor: bgColor)
        banner.dismissesOnTap = true
        banner.show(duration: 5.0)
        
        //Drop.down(message, state: state, duration: 3.0 )
    }
    
    
    //
    //    func openSettingApp() {
    //
    //        UIApplication.shared.keyWindow?.rootViewController?.showAlertControllerWithStyle(alertStyle: .alert,  title: "AlertMessages.connectionProblem",  message: "AlertMessages.checkInternetConn", customActions: ["AlertMessages.cancel", "AlertMessages.settings"], cancelTitle: "", needOK: false, completion: { (actionIndex) in
    //            if actionIndex == 1 {
    //                let url:URL = URL(string: UIApplication.openSettingsURLString)!
    //                if #available(iOS 10, *) {
    //                    UIApplication.shared.open(url, options: [:], completionHandler: {
    //                        (success) in })
    //                } else {
    //                    guard UIApplication.shared.openURL(url) else {
    ////                        Proxy.shared.displayStatusAlert(message: AlertMessages.reviewNetworkConn, state: .error)
    //                        return
    //                    }
    //                }
    //            }
    //        })
    //    }
    
    //MARK: - HANDLE ACTIVITY
    func showActivityIndicator() {
        let activityData = ActivityData()
        NVActivityIndicatorView.DEFAULT_TYPE = NVActivityIndicatorType.ballClipRotatePulse
        NVActivityIndicatorView.DEFAULT_BLOCKER_SIZE = CGSize(width: 50, height: 50)
        NVActivityIndicatorView.DEFAULT_PADDING = CGFloat(60.0)
        NVActivityIndicatorView.DEFAULT_BLOCKER_BACKGROUND_COLOR = UIColor(red: 0/255, green:0/255, blue: 0/255, alpha: 0.5)
        NVActivityIndicatorView.DEFAULT_COLOR =  UIColor.white
        NVActivityIndicatorView.DEFAULT_TEXT_COLOR =  UIColor.white
        NVActivityIndicatorView.DEFAULT_BLOCKER_MESSAGE = "loading..."
        NVActivityIndicatorPresenter.sharedInstance.startAnimating(activityData, nil)
    }
    
    func hideActivityIndicator()  {
        NVActivityIndicatorPresenter.sharedInstance.stopAnimating(nil)
    }
    
    func changeDateFormat(dateStr:String, oldFormat:String = "yyyy-MM-dd HH:mm:ss", newFormat:String) -> String {
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = oldFormat
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = newFormat
        let date: Date? = dateFormatterGet.date(from: dateStr)
        return dateFormatter.string(from: date!)
    }
    
   
    //MARK:- Logout Method
    //      func logout(){
    //        WebServiceProxy.shared.getData(urlStr: "Apis.logout", showIndicator: true) { (response) in
    //                  UserDefaults.standard.set("", forKey: "access_token")
    //                  UserDefaults.standard.synchronize()
    //                   Proxy.shared.hideActivityIndicator()
    //          }
    //      }
    //
}



enum  DropState {
    case success
    case error
    case warning
}
