import UIKit
import FSCalendar
import FloatingPanel
import Alamofire
class CalenderVC: BaseClass, FSCalendarDelegate, FSCalendarDataSource,FloatingPanelControllerDelegate{
    
    // MARK:- Variables
    var titleDateArr = [String]()
    var currentYear = Int()
    @IBOutlet var ContentView: UIView!
    var calendarScreenData = NSArray()
    var formatterMonth = DateFormatter()
    var formatterYear = DateFormatter()
    let layer = CAGradientLayer()
    let calanderLayer = CAGradientLayer()
    let fpc = FloatingPanelController()
    private var currentPage: Date?
    let fpc2 = FloatingPanelController()
    var formatter = DateFormatter()
    var arrDate = String()
    var datesWithEvent:[String] = []
    // MARK:- here is formatter
    //let formatter = DateFormatter()
    var dataArr = NSArray()
    var eventArr = NSArray()
    //let appearance = SurfaceAppearance()
    // MARK:- Outlets
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var previousButton: UIButton!
    @IBOutlet weak var nextbutton: UIButton!
    fileprivate weak var calendarTj: FSCalendar!

    //MARK:- Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.initialApiCall()
        }
       // self.getDataCalanderVC(auth_token: UserStoreSingleton.shared.finalAuthToken)
        initialInit()
        didselectInit()
        // Must
    }
    //  MARK:- Override functions
    // Functions of NotificationCentre
    func initialApiCall(){
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        var dictCurrentMonth : Dictionary<String,String> = Dictionary()
        dictCurrentMonth.updateValue(currentYear, forKey: "currentyear")
        dictCurrentMonth.updateValue(currentMonth , forKey: "currentmonth")
        NotificationCenter.default.post(name: .currentMonthYear, object: nil,userInfo: dictCurrentMonth)
        print(dictCurrentMonth)
    }
    func initialInit(){
        fpc.delegate = self
        fpc.contentMode = .fitToBounds
        fpc.layout = MyFloatingPanelLayout()
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let contentVC = storyBoard.instantiateViewController(withIdentifier: "FloatingPanelVC") as! FloatingPanelVC
        contentVC.calenderVc = self
        fpc.set(contentViewController: contentVC)
        fpc.addPanel(toParent: self)
        ContentView.clipsToBounds = true
        calendar.delegate = self
        calendar.dataSource = self
        calendar.scrollEnabled = true
        calendar.calendarHeaderView.scrollEnabled = true
        calendar.appearance.headerMinimumDissolvedAlpha = 0
      //  calendar.calendarHeaderView.backgroundColor = UIColor.init(named: "131114")
        calendar.scrollDirection = .horizontal
        view.setGradientBackground(gradientLayer: layer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        calendar.placeholderType =  FSCalendarPlaceholderType.none
        calendar.setGradientBackground(gradientLayer:calanderLayer, colorOne: Colors.left_gradient, colorTwo: Colors.right_gradient)
        self.calendarTj = calendar
    }
    
    func didselectInit(){
        fpc2.delegate = self
        fpc2.contentMode = .fitToBounds
        fpc2.layout = MyFloatingPanelLayoutt()
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let contentVC = storyBoard.instantiateViewController(withIdentifier: "FloatingPanelVC") as! FloatingPanelVC
        fpc2.set(contentViewController: contentVC)
        fpc2.addPanel(toParent: self)
        fpc2.hide()
        
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        fpc.layout = MyFloatingPanelLayout()
        // This is working Fine
        calendar.pagingEnabled = true
        calendar.appearance.headerMinimumDissolvedAlpha = 0
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let fpc = FloatingPanelController(delegate: self)
        fpc.layout = MyFloatingPanelLayout()
        calendar.appearance.headerMinimumDissolvedAlpha = 0
    }
    
    // MARK:- Delegates and Fuctions
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
       // print("Selected")
    }
    
    func calendarCurrentPageDidChange(_ calendar: FSCalendar) {
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        var dictmonthPreviouss : Dictionary<String,String> = Dictionary()
        dictmonthPreviouss.updateValue(currentYear, forKey: "scrollYear")
        dictmonthPreviouss.updateValue(currentMonth , forKey: "scrollMonth")
        NotificationCenter.default.post(name: .scrollNotification, object: nil,userInfo: dictmonthPreviouss)
        
    }
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        if cell.eventIndicator.numberOfEvents > 0 {
            cell.eventIndicator.isHidden = false
            cell.eventIndicator.color = UIColor.white
        } else {
            cell.eventIndicator.isHidden = true
            cell.eventIndicator.color = UIColor.clear
        }
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        
        formatter.dateFormat = "yyyy-MM-dd"
        
        if self.datesWithEvent.count > 0 {
            for i in 0...self.datesWithEvent.count-1{
                let currenDate = self.datesWithEvent[i]
                guard let eventDate = formatter.date(from: currenDate) else {
                    return 0
                }
                if date.compare(eventDate) == .orderedSame {
                    return 1
                }
            }
        }
        return 0
    }
    
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
        fpc.hide()
        fpc2.show()
        return true
    }
    
    public func helloTj(value:NSArray){
         for i in 0...value.count-1 {
            let current = value[i] as! NSObject
            let currentDate = current.value(forKey: "title") as! String
            self.datesWithEvent.append(currentDate.components(separatedBy: "T")[0])
        }
        DispatchQueue.main.asyncAfter(deadline: .now()+0.4, execute: {
            if self.calendarTj != nil{
                self.calendarTj.reloadData()
                
            }
        })
    }

    // MARK:- Action Buttons
    @IBAction func actionBtnPreviousMonth(_ sender: Any) {
        calendar.setCurrentPage(getPreviousMonth(date: calendar.currentPage), animated: true)

        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        
        var dictmonthPrevious : Dictionary<String,String> = Dictionary()
        dictmonthPrevious.updateValue(currentYear, forKey: "previousY")
        dictmonthPrevious.updateValue(currentMonth , forKey: "previousM")
        NotificationCenter.default.post(name: .previousMonthYear, object: nil,userInfo: dictmonthPrevious)
        
    }
    
    @IBAction func actionBtnNextMonth(_ sender: Any) {
        calendar.setCurrentPage(getNextMonth(date: calendar.currentPage), animated: true)
        let currentPageDate = calendar.currentPage
        formatterMonth.dateFormat = "MM"
        formatterYear.dateFormat = "yyy"
        let currentYear = formatterYear.string(from: currentPageDate)
        let currentMonth = formatterMonth.string(from: currentPageDate)
        
        var dictmonthNext : Dictionary<String,String> = Dictionary()
        dictmonthNext.updateValue(currentYear, forKey: "nextY")
        dictmonthNext.updateValue(currentMonth , forKey: "nextM")
        NotificationCenter.default.post(name:.nextYearMonth, object: nil,userInfo: dictmonthNext)
    }
    
    
    // MARK:- Functions
    func getNextMonth(date:Date)->Date {
        return  Calendar.current.date(byAdding: .month, value: 1, to:date)!
    }
    
    func getPreviousMonth(date:Date)->Date {
        return  Calendar.current.date(byAdding: .month, value: -1, to:date)!
    }

    //MARK:- HIT API
}

class MyFloatingPanelLayout: FloatingPanelLayout {
    let position: FloatingPanelPosition = .bottom
    let initialState: FloatingPanelState = .tip
    var anchors: [FloatingPanelState: FloatingPanelLayoutAnchoring] {
        return [
            .full: FloatingPanelLayoutAnchor(absoluteInset: 16.0, edge: .top, referenceGuide: .safeArea),
            .half: FloatingPanelLayoutAnchor(fractionalInset: 0.31, edge: .bottom, referenceGuide: .safeArea),
            .tip: FloatingPanelLayoutAnchor(absoluteInset: 28.0, edge: .bottom, referenceGuide: .safeArea),
        ]
    }
}

class MyFloatingPanelLayoutt: FloatingPanelLayout {
    let position: FloatingPanelPosition = .bottom
    let initialState: FloatingPanelState = .half
    var anchors: [FloatingPanelState: FloatingPanelLayoutAnchoring] {
        return [
            .full: FloatingPanelLayoutAnchor(absoluteInset: 16.0, edge: .top, referenceGuide: .safeArea),
            .half: FloatingPanelLayoutAnchor(fractionalInset: 0.31, edge: .bottom, referenceGuide: .safeArea),
            .tip: FloatingPanelLayoutAnchor(absoluteInset: 28.0, edge: .bottom, referenceGuide: .safeArea),
        ]
    }
}
