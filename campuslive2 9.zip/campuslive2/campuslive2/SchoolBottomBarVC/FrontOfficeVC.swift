import UIKit
import Alamofire
import MSPeekCollectionViewDelegateImplementation

class FrontOfficeVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var tblVwFrontOffice: UITableView!
    var arrChildren = NSArray()
    var arrFrontOffice = NSArray()
    let arr = ["1","2","3"]
    @IBOutlet weak var tblVw: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // print("Hi i am array Children",arrChildren)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrChildren.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVwFrontOffice.dequeueReusableCell(withIdentifier:"FrontOfficeTVC") as! FrontOfficeTVC
        let current = arrChildren[indexPath.row] as? NSObject
        
        cell.lblTitle.text = current?.value(forKey: "name") as? String
        let fontIcon = current?.value(forKey: "iconText") as! String
        
        //HelperClass.setFontAwesomeIcon(iconCode: fontIcon, lbl: cell.lblIcon)
        let count = (current?.value(forKey: "unreadCount") as! Int)
        let color = current?.value(forKey: "color") as! String
        let collor = UIColor(hexString: color)
        
        HelperClass.setFontAwesomeIconWithColor(iconCode: fontIcon, lbl: cell.lblIcon, color: collor)
        
        cell.ViewEvents.backgroundColor = UIColor(hexString: color)
        
        if count == 0 {
            cell.ViewEvents.isHidden = true
        }else{
            cell.lblEvents.text = "\(current?.value(forKey: "unreadCount") as! Int)"
        }
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 74
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let arrBottom = arrChildren
        let current = arrChildren[indexPath.row] as? NSObject
        let viewC = storyboard?.instantiateViewController(withIdentifier: "FrontOfficeDetailVC") as! FrontOfficeDetailVC
        
        if indexPath.row == 4 {
            let id = current?.value(forKey: "id") as! String
            let title = current?.value(forKey: "name") as! String
            let unreadCount = "\(current?.value(forKey: "unreadCount") as? Int ?? 0)"
            let colorr = current?.value(forKey: "color") as! String
            viewC.arrBottomData = arrBottom
           // viewC.id = id
            viewC.currentTitle = title
            viewC.currentEvent = unreadCount
            viewC.color = colorr
            viewC.index = indexPath.row
            self.navigationController?.pushViewController( viewC, animated: true)
         // self.navigationController?.pushViewController( viewC, animated: true)
        } else if indexPath.row == 6 {
            print("Hi i am row no 6 ")
           
        } else{
            let id = current?.value(forKey: "id") as! String
            let title = current?.value(forKey: "name") as! String
            let unreadCount = "\(current?.value(forKey: "unreadCount") as? Int ?? 0)"
            let colorr = current?.value(forKey: "color") as! String
            viewC.arrBottomData = arrBottom
            viewC.id = id
            viewC.currentTitle = title
            viewC.currentEvent = unreadCount
            viewC.color = colorr
            viewC.index = indexPath.row
            self.navigationController?.pushViewController( viewC, animated: true)
        }
    }
}

