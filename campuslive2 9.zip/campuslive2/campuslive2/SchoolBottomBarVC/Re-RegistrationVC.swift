//
//  Re-RegistrationVC.swift
//  campuslive2
//
//  Created by Appcrunk Mac Mini on 26/10/20.
//  Copyright © 2020 Appcrunk Mac Mini. All rights reserved.
//

import UIKit

class Re_RegistrationVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
